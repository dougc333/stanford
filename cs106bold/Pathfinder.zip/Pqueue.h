/*
 * File: pqueue.h
 * -----------------------------------------------------
 * Defines an abstraction for the priority queue ADT.  This version defines 
 * the highest priority to be the lowest value. Items placed in the queue
 * are represented by a void * (a pointer to the item),  and a double (the
 * priority of the item).  Note that some of the function names differ from
 * those used in the priority queue assignment, for compatibility with the
 * code in Chpater 16.
*/
 
   
#ifndef _pqueue_h
#define _pqueue_h

#include "genlib.h"

/*
 * Type: pqueueADT
 * ----------------------
 * This is the abstract type for a priority queue.  The type definition
 * below is "incomplete".  Clients know that pqueueADT is a pointer to
 * a struct tagged "pqueueCDT" but that's it.  No details of the size,
 * field names, and types of the structure are visible to the client since
 * we want to keep them on their side of the wall!
 */
typedef struct pqueueCDT *pqueueADT;

typedef struct
			{
				void *info;
				double value;
			}
		pqElementT;



/*
 * Function: NewPriorityQueue
 * Usage: queue = NewPriorityQueue();
 * ---------------------------------
 * Returns a new empty pqueueADT with no elements.  
 */
pqueueADT NewPriorityQueue(void);


/*
 * Function: FreeQueue
 * Usage: FreeQueue(queue);
 * ------------------------
 * Frees all the storage associated with the queue.
 */
void FreeQueue(pqueueADT queue);



/*
 * Function: IsEmpty
 * Usage: if (IsEmpty(queue)) . . .
 * --------------------------
 * Returns TRUE if queue has no entries.
 */
bool IsEmpty(pqueueADT queue);


/*
 * Function: IsFull
 * Usage: if (IsFull(queue)) . . .
 * --------------------------
 * Returns TRUE if queue has no more room for entries.  Clients can use
 * this to check if any further Insert operation will overflow the
 * ability of the queue to handle it. Some versions of the pqueue may 
 * never return TRUE if they can always accommodate more entries.
 */
bool IsFull(pqueueADT queue);


/*
 * Function: PriorityEnqueue
 * Usage: PriorityEnqueue(queue, arc, length);
 * --------------------------
 * Adds the specified double value to the queue. No effort is made to
 * avoid duplicates.  If the queue is full, this function raises an error.
 */
void PriorityEnqueue(pqueueADT queue, void *newInfo, double newValue);


/*
 * Function: PriorityDequeue
 * Usage: best = PriorityDequeue(queue);
 * -----------------------------------
 * Removes the smallest priority element from the queue and
 * returns its info.  If the queue is empty, this function
 * raises an error.
 */
void *PriorityDequeue(pqueueADT queue);


#endif
