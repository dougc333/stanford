/*
 * File: path.h
 * -------------
 * Defines a abstraction for paths, which are ordered lists of arcs.
 */
 
#ifndef _path_h
#define _path_h

#include "genlib.h"
#include "graph.h"		/* for definitions of graph, node, arc */

/*
 * Type: pathADT
 * ------------------
 * Provides an abstract data type for manipulating paths, which are lists of
 * arcs.  The type is a purely abstract type in this interface, defined
 * entirely in terms of the operations.  The client has no access to the
 * the record structure used to implement the actual type.
 */
typedef struct pathCDT *pathADT;


/*
 * Type: arcWeightFnT
 * --------------------
 * Defines the type space of functions that can be used to determine the
 * weight of a particular arc.  The function should take an arc and 
 * return a double value which represents the weight of this arc.
 */
typedef double (*arcWeightFnT)(arcADT arc);


/*
 * Type: arcMappingFnT
 * --------------------
 * Defines the type space of functions can be used to map over the list
 * of arcs in order from the first to the last.  Each function is called
 * with an arc and a client data pointer passed in from the caller.
 */
typedef void (*arcMappingFnT)(arcADT arc, void *clientData);



/* Operations */


/*
 * Function: NewPath
 * Usage: path = NewPath(Distance);
 * -------------------------------------------
 * Dynamically allocates enough memory for the path and initializes it to
 * to represent an empty path.  The weight function will be used to compute
 * the path sum as arcs are appended.
 */
pathADT NewPath(arcWeightFnT weightFn);


/*
 * Function: FreePath
 * Usage: FreePath(path);
 * ----------------------
 * Frees the storage associated with the path.
 */
void FreePath(pathADT path);


/*
 * Function: NewExtendedPath
 * Usage: newPath = NewExtendedPath(path, arc);
 * --------------------------------------------
 * Copies the path, then appends the arc to it.
 */
pathADT NewExtendedPath(pathADT path, arcADT arc);


/*
 * Function: AppendToPath
 * Usage: AppendToPath(path, arc);
 * --------------------------------
 * Appends a new arc to the end of the path.
 */
void AppendToPath(pathADT path, arcADT element);


/*
 * Function: StartOfPath
 * Usage: node = StartOfPath(path);
 * --------------------------
 * Returns the first node in the path.
 * If the path is empty, NULL is returned.
 */
nodeADT StartOfPath(pathADT path);


/*
 * Function: EndOfPath
 * Usage: node = EndOfPath(path);
 * --------------------------
 * Returns the last node in the path (ie the node that was appended most
 * recently).  If the path is empty, NULL is returned.
 */
nodeADT EndOfPath(pathADT path);


/*
 * Function: CopyPath
 * Usage: copy = CopyPath(path);
 * -----------------------------
 * Returns a newly allocated path which is a copy of the given path: same
 * arcs, same order, same weighting function.
 */
pathADT CopyPath(pathADT path);


/*
 * Function: TotalPathDistance
 * Usage: sum = TotalPathDistance(path);
 * --------------------------
 * Returns the sum of the arc weights of the path.  The weighting function
 * supplied when creating this path is used to determine the weight of each arc.
 * If the path is empty, 0 is returned.
 */
double TotalPathDistance(pathADT path);


/*
 * Function: MapPath
 * Usage: MapPath(path, fn, clientdata);
 * ---------------------------------------------
 * Iterates through the arcs in the path and calls the function fn for each arc.
 * The function is called with arguments of the current arc and the clientdata
 * pointer.  The clientdata value allows the client to pass extra state information 
 * to the client-supplied function, if necessary.  If no client data is required, 
 * this argument should be NULL. 
 */
void MapPath(pathADT path, arcMappingFnT mapFn, void *clientData);


#endif

	