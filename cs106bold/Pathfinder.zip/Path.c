/*
 * File: path.c
 * -------------
 * Implements the path.h abstraction.
 */

#include <stdio.h>

#include "genlib.h"
#include "path.h"
#include <assert.h>

/*
 * Type: cell
 * ----------
 * Defines a linked list cell for the path.
 */

typedef struct cell {
    arcADT element;
    struct cell *next;
} cell;

/*
 * Type: pathCDT
 * --------------
 * This type defines the concrete type that
 * corresponds to the abstract type pathADT.
 *
 * You may add new elements to the pathCDT
 * structure if they are necessary for implementing
 * the TotalPathDistance or MapPath functions.
 */

struct pathCDT {
	cell *head, *tail;
	int nElements;
        arcWeightFnT weightFn;
};


/* Public operations */

/* Note that your functions should contain more comments than
 * the functions we provided... */


pathADT NewPath(arcWeightFnT weightFn)
{
	pathADT path;
	
	path = New(pathADT);
	path->nElements = 0;
	path->weightFn = weightFn;	/* save weight fn to apply to arcs later */
	path->head = NULL;
	path->tail = NULL;
	return (path);
}

void FreePath(pathADT path)
{
    cell *oldcell, *next;

    assert(path);
    oldcell = path->head;
    while (oldcell != NULL) {
        next = oldcell->next;
        FreeBlock(oldcell);
        oldcell = next;
    }
    FreeBlock(path);
}

pathADT NewExtendedPath(pathADT path, arcADT arc)
{
	pathADT newPath;
	
	newPath = CopyPath(path);
	AppendToPath(newPath, arc);
	return (newPath);
}


void AppendToPath(pathADT path, arcADT arc)
{
    cell *newOne;
	
    newOne = New(cell *);
    newOne->element = arc;
    newOne->next = NULL;
    if (path->tail == NULL)		/*  adding the first arc in path */
    	path->head = newOne;
   	else
    	path->tail->next = newOne;
    path->tail = newOne;
	path->nElements++;
}


nodeADT StartOfPath(pathADT path)
{
	return (path->head != NULL ? StartOfArc(path->head->element) : NULL);
}

nodeADT EndOfPath(pathADT path)
{
	return (path->tail != NULL ? EndOfArc(path->tail->element) : NULL);
}

pathADT CopyPath(pathADT path)
{
    pathADT copy;
    cell *cur;
    
    copy = NewPath(path->weightFn);
	for (cur = path->head; cur != NULL; cur = cur->next)
		AppendToPath(copy, cur->element);
    return copy;
}

double TotalPathDistance(pathADT path)
{
    /* You must implement this function.
       Be sure to comment how your implementation works. */
}

void MapPath(pathADT path, arcMappingFnT mapFn, void *clientData)
{
   /* You must implement this function.
      Be sure to comment how your implementation works. */
}

