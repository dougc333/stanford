The handout mentioned that separate files would be provided
containing pictures of the campus and USA.  Instead, we have
provided a file called Pathfinder.res.  Include this in your
project just like a .c file.