typedef struct 
		{
			double x, y;
		} 
	    coord;
 
