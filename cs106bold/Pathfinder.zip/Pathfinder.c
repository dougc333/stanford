/*
 * File: Pathfinder.c
 */
 
#include <stdio.h>
#include <ctype.h>
#include <math.h>
#include <assert.h>
#include "genlib.h"
#include "strlib.h"
#include "simpio.h"
#include "extgraph.h"
#include "symtab.h"
#include "iterator.h"
#include "set.h"
#include "cmpfn.h"
#include "graph.h"
#include "path.h"
#include "pqueue.h"
#include "pathfinder.h"


#define MAX_STRING 256
#define CIRCLE_RADIUS .05

/*
	Here is the suggested scanf template that parses one edge description. 
	Note that it reads the means and destination into stack-allocated buffers.
	If you want to save one of those strings to persist after this function 
	exits, you must  copy it (using CopyString) in order to make a private 
	and persistent copy in the heap.
	
	string line;
	char meansBuffer[MAX_STRING], toBuffer[MAX_STRING], fromBuffer[MAX_STRING];
	double distance, time, cost, risk;

	line = ReadLine(f);
	sscanf(line, "\"%[^\"]\" from \"%[^\"]\" to \"%[^\"]\" distance: %lf time: %lf cost: %lf\n", 
		meansBuffer, fromBuffer, toBuffer, &distance, &time, &cost);
*/

static coord GetUserMouseClick(void);
static void FindRoutes(void);
static void Welcome(void);

main(void)
{
	InitGraphics();
	Welcome();
	FindRoutes();
}


static coord GetUserMouseClick(void)
{
	coord location;				/* coord is defined in pathfinder.h */
	
	WaitForMouseDown();
	WaitForMouseUp();
	location.x = GetMouseX();
	location.y = GetMouseY();
	return location;
}


static void Welcome(void)
{
	printf("This masterful piece of work is the key to all your travel needs.\n"
		"You need only choose your start and destination and this program\n"
		"will find the appropriate path between the two, optimized for such\n"
		"things as quickest travel time, fewest hops, and much more!\n"
		"With all the facts at hand, you can choose the preferred route \n"
		"and be on your way!\n");
	printf("Ready to begin? ");
	GetLine();
}

static void FindRoutes(void)
{
        /* Your code should start here */
}
