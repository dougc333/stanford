/*
 * Function: FindShortestPath
 * Usage: bestPath = FindShortestPath(startNode, finishNode, DistanceWeightFn);
 * --------------------------------------------------------
 * This function uses Dijkstra's Algorithm to find the optimal path between two nodes,
 * where "optimal" means lowest total according to the supplied arc weighting function.
 *
 * The following changes have been made from the the algorithm in the text:
 * (1) The function now takes an arcWeightFn as an argument.  This is  passed
 * to NewPath to indicate how to weight paths (distance, time, etc.).
 * (2) The "foreach" notation of the text has been expanded to the explicit
 * use of an iterator.
 *
 * You will need to write some of the funcitons referenced here yourself after you have
 * written your node data type because these functions may require specific knowledge
 * of this structure.  You will need to implement the following functions:
 *
 * IsDistanceFixed(nodeADT node) : returns TRUE if the distance to this node is "fixed",
 *      i.e. we have already found the shortest distance to this node.
 * FixNodeDistance(nodeADT node, double distance) : records the fact that we have just
 *      found the shortest distance to this node.
 * CleanUp(pqueueADT queue) : This function should deallocate any memory that is still
 *      in use by the priority queue before the function exits.  Note that there may 
 *      be other places in this function where you should free memory besides the 
 *      point where CleanUp is called.
 */

pathADT FindShortestPath(nodeADT start, nodeADT finish, arcWeightFnT weightFn)
 {
     pqueueADT queue;
     pathADT path, newPath;
     arcADT arc;
	 iteratorADT iterator;

     queue = NewPriorityQueue();
     path = NewPath(weightFn);
     while (start != finish) 
     {
         if (!IsDistanceFixed(start)) 
         {
             FixNodeDistance(start, TotalPathDistance(path));
             iterator = NewIterator(ArcsFrom(start));
             while (StepIterator(iterator, &arc))
             {
                 if (!IsDistanceFixed(EndOfArc(arc))) 
                 {
                     newPath = NewExtendedPath(path, arc);
                     PriorityEnqueue(queue, newPath,
                                     TotalPathDistance(newPath));
                 }
             }
         }
         if (IsEmpty(queue)) return (NULL);
         path = PriorityDequeue(queue);
         start = EndOfPath(path);
     }
     CleanUp(queue);
     return (path);
 }