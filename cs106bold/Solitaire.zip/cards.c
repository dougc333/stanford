/*
 * File: cards.c
 * -------------
 * This file implements the cards.h interface.  Most of
 * the functions are simple enough to require little
 * additional commentary beyond what is already in the
 * interface.
 */

#include <stdio.h>
#include "genlib.h"
#include "strlib.h"
#include "cards.h"
#include "gcards.h"

/*
 * Your code goes here ...
 *
 */