/*
 * File: solitaire.c
 * -----------------
 * This module provides the main program for the solitaire
 * assignment.  Everything specific to any particular type
 * of solitaire is separated out into a separate source file
 * that implements the InitGame function.
 */

#include <stdio.h>
#include "genlib.h"
#include "graphics.h"
#include "random.h"
#include "cards.h"
#include "gcards.h"
#include "solitaire.h"

/* Main program */

main()
{
    InitGraphics();
    InitCardDisplay("Light gray");
    Randomize();
    InitGame();

    printf("To quit, select File->Exit from the menu bar.\n");

    while (TRUE) WaitForCardAction();
}
