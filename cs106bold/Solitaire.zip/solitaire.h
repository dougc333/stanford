/*
 * File: solitaire.h
 * -----------------
 * This header file contains the prototypes for the InitGame
 * function, which is the only function called by the main
 * program that is specific to a particular solitaire game.
 */

#ifndef _solitaire_h
#define _solitaire_h

/*
 * Function: InitGame
 * Usage: InitGame();
 * ------------------
 * This function initializes the layout for a particular
 * solitaire game.  What it does is initialize a deck of
 * cards, deal the cards into the opening position, and
 * assign appropriate action functions to each card.
 *
 * This function, along with card actions that are called
 * in response to dragging cards, is implemented in a separate
 * module, presumably named to match a particular game.  For
 * the assignment, you need to write the file klondike.c,
 * which implements this function for the Klondike game.
 */

void InitGame(void);

#endif
