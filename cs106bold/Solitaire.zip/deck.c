/*
 * File: deck.c
 * ------------
 * This file implements the deck.h interface.
 */

#include <stdio.h>
#include "genlib.h"
#include "strlib.h"
#include "random.h"
#include "cards.h"
#include "deck.h"

/*
 * Type: deckCDT
 * -------------
 * This type defines the concrete structure underlying the
 * deck of cards.  It contains a dynamic array of cards, the
 * total size of the deck, and the index of the current card,
 * which is the next one to be dealt.
 */

struct deckCDT{
    cardADT *cards;
    int nCards;
    int current;
};

/* Exported entries */

/*
 * Implementation notes: NewDeck
 * -----------------------------
 * The NewDeck function iterates through the the number of
 * cards desired, sequencing through suits and ranks with
 * the suit varying most rapidly.  As discussed in the
 * interface, this design makes it possible to create partial
 * or multiple decks.
 */

deckADT NewDeck(int n)
{
    deckADT deck;
    rankT rank;
    suitT suit;
    int i;

    deck = New(deckADT);
    deck->cards = NewArray(n, cardADT);
    deck->nCards = n;
    deck->current = 0;
    rank = Ace;
    suit = Clubs;
    for (i = 0; i < n; i++) {
        deck->cards[i] = NewCard(rank, suit);
        if (suit == Spades) {
            rank = (rank == King) ? Ace : rank + 1;
            suit = Clubs;
        } else {
            suit++;
        }
    }
    return (deck);
}

deckADT ReadDeck(FILE *infile, int n)
{
    char buffer[4];
    string name;
    deckADT deck;
    rankT rank;
    suitT suit;
    bool legal;
    int i;

    deck = New(deckADT);
    deck->cards = NewArray(n, cardADT);
    deck->nCards = n;
    deck->current = 0;
    buffer[3] = '\0';
    for (i = 0; i < n; i++) {
        if (fscanf(infile, "%3s", buffer) != 1) {
            Error("Not enough cards in file");
        }
        name = ConvertToUpperCase(buffer);
        legal = FALSE;
        switch (StringLength(name)) {
          case 3:
            if (name[0] != '1' || name[1] != '0') break;
            rank = 10;
            suit = FindChar(name[2], "CDHS", 0);
            if (suit < 0) break;
            legal = TRUE;
            break;
          case 2:
            rank = FindChar(name[0], "XA23456789TJQK", 0);
            if (rank < 1) break;
            suit = FindChar(name[1], "CDHS", 0);
            if (suit < 0) break;
            legal = TRUE;
            break;
        }
        if (!legal) Error("Illegal card: %s", name);
        deck->cards[i] = NewCard(rank, suit);
    }
    return (deck);
}

/*
 * Implementation notes: ShuffleDeck
 * ---------------------------------
 * The ShuffleDeck function is similar in form to the
 * selection sort algorithm.  The difference is that this
 * function chooses the rh index randomly rather than
 * finding the smallest value.  In essence, the function
 * sorts the array on a random key.
 */

void ShuffleDeck(deckADT deck)
{
    int lh, rh, last;
    cardADT tmp;

    last = deck->nCards - 1;
    for (lh = 0; lh < last; lh++) {
        rh = RandomInteger(lh, last);
        tmp = deck->cards[rh];
        deck->cards[rh] = deck->cards[lh];
        deck->cards[lh] = tmp;
    }
}

/*
 * Implementation notes: DealNextCard
 * ----------------------------------
 * The DealNextCard just checks to see if the deck is exhausted
 * and, if not, returns the card at the current index.
 */

cardADT DealNextCard(deckADT deck)
{
    if (deck->current == deck->nCards) return (NULL);
    return (deck->cards[deck->current++]);
}
