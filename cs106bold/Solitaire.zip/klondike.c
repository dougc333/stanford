/*
 * File: klondike.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include "genlib.h"
#include "strlib.h"
#include "simpio.h"
#include "extgraph.h"
#include "cards.h"
#include "deck.h"
#include "gcards.h"
#include "random.h"
#include "solitaire.h"

/*
 * Display parameters
 * ------------------
 * These "constants" (some of which involve calculation)
 * define the geometry of the graphics screen.  The constants
 * ending in X and Y always represent the lower left coordinate
 * of their respective pile (for the layout and foundations,
 * these values are for the pile at index 0).  Other parameters
 * include:
 *
 * Margin             Space left at each side of the screen
 * LayoutSep          Separation between layout piles
 * LayoutOffset       Vertical offset between overlapping cards
 * FoundationSep      Separation between foundation piles
 */

#define Margin           0.1

#define LayoutX          1.5
#define LayoutY          (GetWindowHeight() - CardHeight - Margin)
#define LayoutSep        0.15
#define LayoutOffset     0.17

#define FoundationX      Margin
#define FoundationY      LayoutY
#define FoundationSep    ((GetWindowHeight() - 2 * Margin - 4 * CardHeight) / 3)

#define StockX           LayoutX
#define StockY           Margin

#define DiscardX         (StockX + CardWidth + LayoutSep)
#define DiscardY         Margin

/* Types */

typedef enum { Layout, Foundation, Stock, Discard } pileTypeT;
typedef enum { Red, Black } colorT;

/* 
 * Your code goes here...
 *
 */