//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SolitaireCards.rc
//
#define IDB_BITMAP2                     102
#define IDB_BITMAP3                     103
#define IDB_BITMAP4                     104
#define IDB_BITMAP5                     105
#define IDB_BITMAP6                     106
#define IDB_BITMAP7                     107
#define IDB_BITMAP8                     108
#define IDB_BITMAP14                    114
#define IDB_BITMAP15                    115
#define IDB_BITMAP16                    116
#define IDB_BITMAP17                    117
#define IDB_BITMAP18                    118
#define IDB_BITMAP19                    119
#define IDB_BITMAP20                    120
#define IDB_BITMAP21                    121
#define IDB_BITMAP22                    122
#define IDB_BITMAP23                    123
#define IDB_BITMAP24                    124
#define IDB_BITMAP25                    125
#define IDB_BITMAP26                    126
#define IDB_BITMAP27                    127
#define IDB_BITMAP28                    128
#define IDB_BITMAP29                    129
#define IDB_BITMAP30                    130
#define IDB_BITMAP31                    131
#define IDB_BITMAP32                    132
#define IDB_BITMAP33                    133
#define IDB_BITMAP34                    134
#define IDB_BITMAP35                    135
#define IDB_BITMAP36                    136
#define IDB_BITMAP37                    137
#define IDB_BITMAP38                    138
#define IDB_BITMAP39                    139
#define IDB_BITMAP40                    140
#define IDB_BITMAP45                    145
#define IDB_BITMAP46                    146
#define IDB_BITMAP47                    147
#define IDB_BITMAP48                    148
#define IDB_BITMAP49                    149
#define IDB_BITMAP50                    150
#define IDB_BITMAP51                    151
#define IDB_BITMAP52                    152
#define IDB_BITMAP54                    154
#define IDB_BITMAP55                    155
#define IDB_BITMAP56                    156
#define IDB_BITMAP57                    157
#define IDB_BITMAP58                    158

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        159
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
