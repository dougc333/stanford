/*
 * File: gcards.c
 * --------------
 * This file implements the gcards.h interface, which supports
 * the display of cards on the screen.
 */

#include <stdio.h>
#include "genlib.h"
#include "strlib.h"
#include "cards.h"
#include "gcards.h"
#include "extgraph.h"
#include "sound.h"

/*
 * Constants
 * ---------
 * MaxCards   -- Limit on cards, including virtual ones
 * XOffset    -- X displacement for PICT cards because of text margin
 * YOffset    -- Y displacement for PICT cards because of text margin
 */

#define MaxCards    200
#define XOffset    0		//(3.0 / 72.0)
#define YOffset    0		//(4.0 / 72.0)

/*
 * Type: registryEntryT
 * --------------------
 * This type is used to create a table of cards that have been
 * registered with the display.  These cards are stored so
 * that the system can keep track of their x, y position.
 * Because more than one card can occupy the same spot, the
 * registry array must be kept in time sequence, with the
 * most recently displayed cards closest to the end of the
 * array.  This discipline makes it easier for the function
 * FindCardAtPosition to determine what card is topmost and
 * to ensure that cards are redrawn in the correct sequence.
 * For virtual cards, this entry also keeps track of the
 * picture used to display them.
 */

typedef struct {
    cardADT card;
    bool visible;
    int time;
} registryEntryT;

/*
 * Private variables
 * -----------------
 * cardRegistry     -- Array of cards on the display
 * nCardsRegistered -- Effective size of cardRegistry
 * backgroundColor  -- Color used for the screen display
 * timeCounter      -- Counter used to determine latest event
 * initialized      -- Flag indicating package is initialized
 */

static registryEntryT cardRegistry[MaxCards];
static int nCardsRegistered;
static string backgroundColor;
static int timeCounter;
static bool initialized = FALSE;

/* Private function prototypes */

static int FindCard(cardADT card);
static int FindCardAtPosition(double x, double y);
static bool IsPointInsideCard(double x, double y, int index);
static bool IsInRange(double x, double start, double width);
static void ShiftCardToEnd(int index);
static void DrawCardImage(double x, double y, string image, bool offset);
static void DrawBox(double x, double y, double width, double height);
static void DrawSolidBox(double x, double y, double width, double height);

/* Exported entries */

void InitCardDisplay(string color)
{
    string oldColor;

    oldColor = GetPenColor();
    backgroundColor = CopyString(color);
    SetPenColor(backgroundColor);
    DrawSolidBox(0, 0, GetWindowWidth(), GetWindowHeight());
    SetPenColor(oldColor);
    nCardsRegistered = 0;
    timeCounter = 0;
    initialized = TRUE;
}

void DrawCard(cardADT card)
{
    int index;
    string image;
    bool offset;

    index = FindCard(card);
    if (index == -1) {
         if (nCardsRegistered == MaxCards) {
             Error("Too many cards on screen");
         }
        index = nCardsRegistered++;
        cardRegistry[index].card = card;
    } else {
        ShiftCardToEnd(index);
        index = nCardsRegistered - 1;
    }
    cardRegistry[index].visible = TRUE;
    cardRegistry[index].time = timeCounter++;
    if (GetCardOrientation(card) == FaceUp) {
        image = CardName(card);
        offset = (Rank(card) != SpecialCard);
    } else {
        image = "FaceDown";
        offset = FALSE;
    }
    DrawCardImage(GetCardX(card), GetCardY(card), image, offset);
}

void EraseCard(cardADT card)
{
    int index;

    index = FindCard(card);
    if (index == -1 || GetCardX(card) == OffScreen) return;
    ShiftCardToEnd(index);
    index = nCardsRegistered - 1;
    cardRegistry[index].visible = FALSE;
    cardRegistry[index].time = timeCounter++;
    DrawCardImage(GetCardX(card), GetCardY(card), NULL, FALSE);
}

void WaitForCardAction(void)
{
    cardADT src, dst;
    int index;
    cardActionFnT fn;

    while (TRUE) {
        WaitForMouseDown();
        index = FindCardAtPosition(GetMouseX(), GetMouseY());
        src = (index == -1) ? NULL : cardRegistry[index].card;
        WaitForMouseUp();
        index = FindCardAtPosition(GetMouseX(), GetMouseY());
        dst = (index == -1) ? NULL : cardRegistry[index].card;
        if (src != NULL && dst != NULL) break;
        PlayNamedSound ("chord");
    }
    fn = GetCardAction(src);
    fn(src, dst);
}

/* Private functions */

static int FindCard(cardADT card)
{
    int i;

    for (i = nCardsRegistered - 1; i >= 0; i--) {
        if (card == cardRegistry[i].card) return (i);
    }
    return (-1);
}

static int FindCardAtPosition(double x, double y)
{
    int i;

    for (i = nCardsRegistered - 1; i >= 0; i--) {
        if (cardRegistry[i].visible && IsPointInsideCard(x, y, i)) return (i);
    }
    return (-1);
}

static bool IsPointInsideCard(double x, double y, int index)
{
    return (IsInRange(x, GetCardX(cardRegistry[index].card), CardWidth)
            && IsInRange(y, GetCardY(cardRegistry[index].card), CardHeight));
}

static bool IsInRange(double x, double start, double width)
{
    return ((x >= start) && (x <= start + width));
}

static void ShiftCardToEnd(int index)
{
    registryEntryT entry;
    int i;

    entry = cardRegistry[index];
    for (i = index + 1; i < nCardsRegistered; i++) {
        cardRegistry[i - 1] = cardRegistry[i];
    }
    cardRegistry[nCardsRegistered - 1] = entry;
}

static void DrawCardImage(double x, double y, string image, bool offset)
{
    string oldColor;

    if (image == NULL) {
        oldColor = GetPenColor();
        SetPenColor(backgroundColor);
        DrawSolidBox(x, y, CardWidth, CardHeight);
        SetPenColor(oldColor);
    } else {
        if (offset) {
            x -= XOffset;
            y -= YOffset;
        }
        MovePen(x, y);
        DrawNamedPicture(image);
    }
}

/*
 * Function: DrawBox
 * Usage: DrawBox(x, y, width, height)
 * -----------------------------------
 * This function draws a rectangle of the given width and
 * height with its lower left corner at (x, y).
 */

static void DrawBox(double x, double y, double width, double height)
{
    MovePen(x, y);
    DrawLine(0, height);
    DrawLine(width, 0);
    DrawLine(0, -height);
    DrawLine(-width, 0);
}

/*
 * Function: DrawSolidBox
 * Usage: DrawSolidBox(x, y, width, height);
 * -----------------------------------------
 * This function draws a box like DrawBox but fills it in with
 * a solid color using the filled region mechanism in the
 * extended graphics library.  This implementation also draws
 * the outline to ensure that the filled box is the same size
 * as the DrawBox output.
 */

static void DrawSolidBox(double x, double y,
                  double width, double height)
{
    StartFilledRegion(1.0);
    DrawBox(x, y, width, height);
    EndFilledRegion();
    DrawBox(x, y, width, height);
}
