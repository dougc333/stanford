/*
 * File: gcards.h
 * --------------
 * This interface makes it possible to display cards on
 * the screen and to manage the operation of dragging
 * cards from one position to another.
 */

#ifndef _gcards_h
#define _gcards_h

#include "genlib.h"
#include "cards.h"

/*
 * Function: InitCardDisplay
 * Usage: InitCardDisplay(color);
 * ------------------------------
 * This call initializes the card display package and must be
 * called before using any of the other functions in this package,
 * but after a call to InitGraphics, which should still be the
 * first statement in the main program. The argument is a string
 * representing the background color, which is painted across
 * the entire display area.  Thereafter, cards that are erased
 * from the screen will be painted over using the background
 * color.
 */

void InitCardDisplay(string color);

/*
 * Function: DrawCard
 * Usage: DrawCard(card);
 * ----------------------
 * This function redraws the specified card at its current (x, y)
 * position.
 */

void DrawCard(cardADT card);

/*
 * Function: EraseCard
 * Usage: EraseCard(card);
 * -----------------------
 * This function erases the specified card by drawing a background
 * rectangle over its current (x, y) position.  The client is
 * responsible for redrawing any cards exposed by this action.
 */


void EraseCard(cardADT card);

/*
 * Function: WaitForCardAction
 * Usage: WaitForCardAction();
 * ---------------------------
 * This function waits for the user to enter a legal card action
 * using the mouse, which consists of a down-click on one card
 * called the "source" and an up-click on a second called the
 * "destination," which may be the same card.  When such an action
 * is completed, the card action function of the source card is
 * called with the source and destination cards as parameters.
 */

void WaitForCardAction(void);

#endif
