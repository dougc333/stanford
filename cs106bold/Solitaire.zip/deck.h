/*
 * File: deck.h
 * ------------
 * This interface creates a simple deck abstraction that allows
 * for creating, shuffling, and dealing cards from a deck.
 */

#ifndef _deck_h
#define _deck_h

#include "genlib.h"
#include "cards.h"

/*
 * Type: deckADT
 * -------------
 * This type is an ADT representing a deck of playing cards.
 */

typedef struct deckCDT *deckADT;

/*
 * Function: NewDeck
 * Usage: deck = NewDeck(n);
 * -------------------------
 * This function allocates a new deck and fills it with n cards.
 * The parameter n is usually 52; if it is not cards are added
 * to the deck in ascending order through the ranks: all four
 * aces, followed by all four twos, and so on, cycling back from
 * kings to aces, if necessary.  This design makes it easier to
 * create abridged and multiple decks.
 */

deckADT NewDeck(int n);

/*
 * Function: ReadDeck
 * Usage: deck = ReadDeck(infile, int n);
 * --------------------------------------
 * This function reads a new deck and fills it with n cards
 * read in from the file, which must be opened and closed by
 * the client.
 */

deckADT ReadDeck(FILE *infile, int n);

/*
 * Function: ShuffleDeck
 * Usage: ShuffleDeck(deck);
 * -------------------------
 * This function shuffles the deck so that the cards appear
 * in a random order.
 */

void ShuffleDeck(deckADT deck);

/*
 * Function: DealNextCard
 * Usage: card = DealNextCard(deck);
 * ---------------------------------
 * This function deals the next card from the deck, if any, and
 * returns it to the client, using NULL to signify the end.
 */

cardADT DealNextCard(deckADT deck);

#endif
