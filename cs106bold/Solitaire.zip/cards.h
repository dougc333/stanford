/*
 * File: cards.h
 * -------------
 * This file provides an abstraction for a cardADT which is
 * used to represents a playing card in a standard 52-card
 * deck.  The card is represented as an abstract type, which
 * means that all operations on the cards are provided by
 * function calls.
 */

#ifndef _cards_h
#define _cards_h

#include "genlib.h"

/*
 * Constants: CardWidth, CardHeight
 * --------------------------------
 * These constants give the width and height of the standard
 * card displays and can be used by the client to lay out the
 * display area.
 */

#define CardWidth  0.625
#define CardHeight 0.905

/*
 * Constant: OffScreen
 * -------------------
 * This constant is used to represent both the x- and y-coordinate
 * of a card that is not being displayed.
 */

#define OffScreen -1

/*
 * Overview
 * --------
 * This interface provides a cardADT abstraction that makes it
 * easier to write card games of various types.  Conceptually,
 * each card consists of a rank (Ace to King), a suit (Clubs,
 * Diamonds, Hearts, or Spades), and an orientation (FaceUp
 * or FaceDown).  Each card can also be attached to other
 * cards to form a linear chain.  From each card, you can
 * use the GetPredecessor and GetSuccessor functions
 * to move to adjacent cards in the sequence.
 */

/*
 * Type: rankT
 * Constants: Ace, Jack, Queen, King, SpecialCard
 * ----------------------------------------------
 * The rank of a card is represented by an integer, which
 * makes perfect sense when the card rank is numeric (2, 3,
 * and so forth, up to 10).  The constant names are included
 * for Ace, Jack, Queen, and King to make these ranks easier
 * to use in programs.  The SpecialCard constant is used to
 * identify cards created by NewSpecialCard, the details of
 * which are described with that procedure.
 */

typedef int rankT;

#define SpecialCard  0
#define Ace          1
#define Jack        11
#define Queen       12
#define King        13

/*
 * Type: suitT
 * -----------
 * The suit of a card is represented as an enumeration type.
 * The order of the suits is chosen to be consistent with
 * games like bridge, where clubs are lowest, followed by
 * diamonds, hearts, and spades.
 */

typedef enum {
    Clubs, Diamonds, Hearts, Spades
} suitT;

/*
 * Type: orientationT
 * ------------------
 * This enumerated type specifies the orientation of a card and
 * has only two values: FaceUp and FaceDown.
 */

typedef enum { FaceUp, FaceDown } orientationT;

/*
 * Type: cardADT
 * -------------
 * This type represents a single playing card.
 */

typedef struct cardCDT *cardADT;

/*
 * Type: cardActionFnT
 * -------------------
 * This type defines the space of functions that can be called
 * in response to a call to WaitForCardAction.
 */

typedef void (*cardActionFnT)(cardADT src, cardADT dst);

/*
 * Function: NewCard
 * Usage: card = NewCard(rank, suit);
 * ----------------------------------
 * This card combines the rank and suit value into a unit
 * and returns the result as a cardADT.  Cards are created
 * in the FaceUp orientation.
 */

cardADT NewCard(rankT rank, suitT suit);

/*
 * Function: NewSpecialCard
 * Usage: card = NewSpecialCard(name);
 * -----------------------------------
 * This function creates a card that is not part of the regular
 * 52-card deck but that may be useful in certain applications.
 * The most intuitive example is a Joker, which could be
 * created using a statement like this:
 *
 *      joker = NewSpecialCard("Joker");
 *
 * The name of this card is "Joker", its rank is SpecialCard,
 * and its suit is undefined.  In addition to this use,
 * the special card concept is especially useful in conjunction
 * with the gcards.h interface because it provides a way to
 * create slots for cards on the screen.  For example, if
 * you were to write
 *
 *      discardPile = NewSpecialCard("DiscardPile");
 *
 * you would have a "card" you could use to represent a
 * discard pile.  The graphics routines allow you to
 * move a real card onto this position.
 */

cardADT NewSpecialCard(string name);

/*
 * Functions: Rank, Suit
 * Usage: rank = Rank(card);
 *        suit = Suit(card);
 * -------------------------
 * These functions return the suit and rank of the specified
 * card, respectively.  Calling Rank of a special card returns
 * the constant SpecialCard; calling Suit on a special card
 * generates an error.
 */

rankT Rank(cardADT card);
suitT Suit(cardADT card);

/*
 * Function: CardName
 * Usage: name = CardName(card);
 * -----------------------------
 * This function returns a string that represents the card.
 * For standard cards, the string begins with a rank indicator
 * (which is one of A, 2, 3, 4, 5, 6, 7, 8, 9, 10, J, Q, or K)
 * followed by a one-character suit (C, D, H, or S).  Calling
 * CardName on a special card returns the name used to create
 * the card.
 */

string CardName(cardADT card);

/*
 * Functions: SetCardOrientation, GetCardOrientation
 * Usage: SetCardOrientation(card, orientation);
 *        orientation = GetCardOrientation(card);
 * ----------------------------------------------
 * The SetCardOrientation function sets the orientation of
 * the card as specified by the second parameter, which is
 * either FaceUp or FaceDown and then calls DrawCard to
 * redisplay it.  GetCardOrientation returns the current
 * orientation.
 */

void SetCardOrientation(cardADT card, orientationT orientation);
orientationT GetCardOrientation(cardADT card);

/*
 * Function: SetCardPosition
 * Usage: SetCardPosition(card, x, y);
 * -----------------------------------
 * This function sets the position on the screen and then
 * calls DrawCard to update the display.  The point (x, y)
 * specifies the coordinates of the lower-left corner.  You
 * can make a card disappear from the display by setting its
 * coordinates to (OffScreen, OffScreen).
 */

void SetCardPosition(cardADT card, double x, double y);

/*
 * Functions: GetCardX, GetCardY
 * Usage: x = GetCardX(card);
 *        y = GetCardY(card);
 * --------------------------
 * These functions return the coordinates at which the image
 * of the card is displayed.
 */

double GetCardX(cardADT card);
double GetCardY(cardADT card);

/*
 * Functions: SetCardAction, GetCardAction
 * Usage: SetCardAction(card, fn);
 *        fn = GetCardAction(card);
 * --------------------------------
 * These functions set and retrieve the function pointer
 * associated with a specific card.  This function is called
 * by the WaitForCardAction in the gcards.h interface.
 */

void SetCardAction(cardADT card, cardActionFnT fn);
cardActionFnT GetCardAction(cardADT card);

/*
 * Functions: SetCardData, GetCardData
 * Usage: SetCardData(card, data);
 *        data = GetCardData(card);
 * --------------------------------
 * These functions allow the client to associate an arbitrary
 * pointer value, which presumably points to a record containing
 * information that the client wants to associate with that card.
 * You need not use this feature in your implementation, but it
 * might come in handy both for Klondike and for other games.
 */

void SetCardData(cardADT card, void *data);
void *GetCardData(cardADT card);

/*
 * Function: Attach
 * Usage: Attach(src, dst, dx, dy);
 * --------------------------------
 * This function attaches the cards src and dst so that src
 * becomes the successor of dst and dst becomes the predecessor
 * of src.  If these cards were previously part of other chains,
 * those chains are broken at that point.  No changes are made
 * to the rest of the chains in which these cards appear.  The
 * dx and dy parameters indicate the new position of src
 * relative to the coordinates of dst.  For example, the call
 *
 *     Attach(src, dst, 0, 0);
 *
 * draws the src chain immediately on top of the dst one.
 * Calling Attach automatically makes the following graphics
 * calls:
 *
 * 1.  Calls EraseCard on src and every card in its successor
 *     chain to erase them from their old positions.
 * 2.  Calls SetCardPosition on src and every card in its successor
 *     chain to redisplay them in their new positions.
 * 3.  Calls DrawCard on the old predecessor of src to expose
 *     it to view.
 */

void Attach(cardADT src, cardADT dst, double dx, double dy);

/*
 * Functions: GetPredecessor, GetSuccessor
 * Usage: pred = GetPredecessor(card);
 *        succ = GetSuccessor(card);
 * ---------------------------------
 * These functions return the predecessor and successor of a
 * card as established by calls to Attach.  If the card is at
 * the end of a chain in the relevant direction, these functions
 * return NULL.
 */

cardADT GetPredecessor(cardADT card);
cardADT GetSuccessor(cardADT card);

/*
 * Functions: GetTopCard, GetBottomCard
 * Usage: top = GetTopCard(card);
 *        bottom = GetBottomCard(card);
 * ------------------------------------
 * These functions return the cards at the extreme ends of
 * the successor and predecessor chains, respectively.
 */

cardADT GetTopCard(cardADT card);
cardADT GetBottomCard(cardADT card);

#endif

