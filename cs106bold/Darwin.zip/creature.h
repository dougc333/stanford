/*
 * File: creature.h
 * ----------------
 * This interface defines the creature abstraction.
 */

#ifndef _creature_h
#define _creature_h

#include "genlib.h"
#include "geometry.h"
#include "species.h"
#include "world.h"

/*
 * Type: creatureADT
 * -----------------
 * This type is the abstract data type for a creature.
 */

typedef struct creatureCDT *creatureADT;

/*
 * Function: NewCreature
 * Usage: creature = NewCreature(species, world, pt, dir);
 * -------------------------------------------------------
 * This function creates a new creature of the indicated species
 * that lives in the specified world.  The creature is initially
 * positioned at position pt facing direction dir.
 */

creatureADT NewCreature(speciesADT species, worldADT world,
                        pointT pt, directionT dir);

/*
 * Function: GetSpecies
 * Usage: species = GetSpecies(creature);
 * --------------------------------------
 * This function returns the species to which this creature
 * belongs.
 */

speciesADT GetSpecies(creatureADT creature);

/*
 * Function: TakeOneTurn
 * Usage: TakeOneTurn(creature);
 * -----------------------------
 * This function executes one turn for this creature.
 */

void TakeOneTurn(creatureADT creature);

#endif
