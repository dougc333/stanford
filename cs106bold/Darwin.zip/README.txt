HW4 DARWIN
-----------

Due to the way the CS graphic libraries work, if you select File->Quit from the menu
in the Graphics Window, you will receive a debug error:
	Internal Error: Can't load brush.

Don't worry about this, it's not your fault.  If you want to avoid this nuisance error,
just close Darwin with the 'X' in the upper right-hand corner of the console window
instead.