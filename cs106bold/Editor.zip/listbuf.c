/*
 * File: listbuf.c
 * ---------------
 * This file implements the buffer.h abstraction using a linked
 * list to represent the buffer.
 *
 * You will need to write similar files for Double-Linked List
 * and ListBlock represenations.
 */

#include <stdio.h>
#include "genlib.h"
#include "strlib.h"
#include "buffer.h"

/* Prototypes */

static int GetBufferLength(bufferADT buffer);

/* Types */

typedef struct cellT {
    char ch;
    struct cellT *link;
} cellT;

struct bufferCDT {
    cellT *start;
    cellT *cursor;
};

/*
 * Implementation notes: NewBuffer
 * -------------------------------
 * This function allocates an empty editor buffer, represented
 * as a linked list.  To simplify the link list operation, this
 * implementation adopts the useful programming tactic of
 * keeping an extra "dummy" cell at the beginning of each list,
 * so that the empty buffer has the following representation:
 *
 *     +-------+          +------+
 *     |   o---+-----====>|      |
 *     +-------+    /     +------+
 *     |   o---+---/      | NULL |
 *     +-------+          +------+
 */

bufferADT NewBuffer(void)
{
    bufferADT buffer;

    buffer = New(bufferADT);
    buffer->start = buffer->cursor = New(cellT *);
    buffer->start->link = NULL;
    return (buffer);
}

/*
 * Implementation notes: FreeBuffer O(N)
 * -------------------------------------
 * This function must first iterate over the entire linked list 
 * chain to free every individual cellT.  After doing this, we can
 * free the memory occupied by bufferCDT itself.
 */

void FreeBuffer(bufferADT buffer)
{
    cellT *cp, *next;

    cp = buffer->start;
    while (cp != NULL) {
        next = cp->link;
        FreeBlock(cp);
        cp = next;
    }
    FreeBlock(buffer);
}

/*
 * Implementation notes: MoveCursorForward O(1)
 * --------------------------------------------
 * This function advances the cursor pointer down one cellT in our
 * linked list chain.  If we encounter a NULL, we are at the end
 * of the buffer and do nothing.
 */

void MoveCursorForward(bufferADT buffer)
{
    if (buffer->cursor->link != NULL) {
        buffer->cursor = buffer->cursor->link;
    }
}

/*
 * Implementation notes: MoveCursorBackward O(N)
 * ---------------------------------------------
 * Because this is a singlely linked list, the only way to move the
 * cursor back is to iterate over the link-list chain until we reach
 * cellT whose link pointer points to the same cellT that the cursor
 * points to, (the character logically preceding the cursor in the
 * buffer).  Once it is found, we set the cursor to that cellT.  
 *
 * If the cursor is pointing to the start, there is no place to move
 * and we do nothing.
 */

void MoveCursorBackward(bufferADT buffer)
{
    cellT *cp;

    if (buffer->cursor != buffer->start) {
        cp = buffer->start;
        while (cp->link != buffer->cursor) {
             cp = cp->link;
        }
        buffer->cursor = cp;
    }
}

/*
 * Implementation notes: MoveCursorToStart O(1)
 * --------------------------------------------
 * Utilizes the buffer's start pointer to reset the cursor.
 */
 
void MoveCursorToStart(bufferADT buffer)
{
    buffer->cursor = buffer->start;
}

/*
 * Implementation notes: MoveCursorToEnd O(N)
 * ------------------------------------------
 * Since we don't have an end pointer in the buffer, we must 
 * iterate down the list to find it.  Would it be better to
 * have such a pointer?  What affect would it have on our 
 * running time?
 */
 
void MoveCursorToEnd(bufferADT buffer)
{
    while (buffer->cursor->link != NULL) {
        MoveCursorForward(buffer);
    }
}

/* 
 * Implementation notes: InsertCharacter O(1)
 * ------------------------------------------
 * This function follows the typical paradigm for inserting 
 * a cell into a linked list.  The cell is placed following
 * the cursor, and the cursor pointer is reset to rest on
 * (or logically follow) that character.
 */
 
void InsertCharacter(bufferADT buffer, char ch)
{
    cellT *cp;

    cp = New(cellT *);
    cp->ch = ch;
    cp->link = buffer->cursor->link;
    buffer->cursor->link = cp;
    buffer->cursor = cp;
}

/* 
 * Implementation notes: DeleteCharacter O(1)
 * ------------------------------------------
 * This function follows a typical paradigm for removing 
 * a cell from a linked list.  The cell following the cursor
 * is removed (forward deletion).  What would the cost be 
 * for backward deletion using this singlely linked list 
 * data structure?
 */
 
void DeleteCharacter(bufferADT buffer)
{
    cellT *cp;

    if (buffer->cursor->link != NULL) {
        cp = buffer->cursor->link;
        buffer->cursor->link = cp->link;
        FreeBlock(cp);
    }
}

/* 
 * Implementation notes: DisplayBuffer O(N)
 * ----------------------------------------
 * This function iterates down the linked list, printing out 
 * the appropriate characters.  It then makes a second pass
 * to print out the cursor location, lined up underneath the
 * the target location on the line above.
 */

void DisplayBuffer(bufferADT buffer)
{
    cellT *cp;

    for (cp = buffer->start->link; cp != NULL; cp = cp->link) {
        printf(" %c", cp->ch);
    }
    printf("\n");
    for (cp = buffer->start; cp != buffer->cursor; cp = cp->link) {
        printf("  ");
    }
    printf("^\n");
}

/*
 * Implementation notes: GetBufferLength O(N)
 * ------------------------------------------
 * This function iterates down the entire linked list, counting
 * each cellT as it goes.  How could the data structure be 
 * improved to achieve constant time performance?
 */
static int GetBufferLength(bufferADT buffer)
{
    cellT *cp;
	int length;

	length = 0;
    for (cp = buffer->start->link; cp != NULL; cp = cp->link) {
        length++;
    }
	return(length);
}

/*
 * Implementation notes: BufferToString O(N)
 * -----------------------------------------
 * This function first creates enough space on the Heap for the
 * new string, then iterates down the entire linked list, adding 
 * the character from each cellT to the new string as it goes.
 */

char *BufferToString(bufferADT buffer)
{
    cellT *cp;
	int length, pos;
	char *str;
	
	length = GetBufferLength(buffer);
	str = NewArray(length+1, char);

	pos = 0;
    for (cp = buffer->start->link; cp != NULL; cp = cp->link) {
        str[pos++] = cp->ch;
    }
	str[length] = '\0';
	return(str);
}

/*
 * Implementation notes: ClearBuffer O(N)
 * --------------------------------------
 * This function iterates down the entire linked list, freeing each
 * cellT as it goes.  It then recreates the dummy cell at the start
 * of the list.
 */

void ClearBuffer(bufferADT buffer)
{
    cellT *ptr, *next;

    ptr = buffer->start;
    while (ptr != NULL) {
        next = ptr->link;
        FreeBlock(ptr);
        ptr = next;
    }

    buffer->start = buffer->cursor = New(cellT *);
    buffer->start->link = NULL;
}
