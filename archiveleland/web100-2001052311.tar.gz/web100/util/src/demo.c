
/*
 *  Copyrights
 *
 *   All documentation and programs in this release is copyright (c)
 *   Carnegie Mellon University, The Board of Trustees of the University of
 *   Illinois, and University Corporation for Atmospheric Research, 2001.
 *   This software comes with NO WARRANTY.
 *
 *   The kernel changes and additions are also covered by the GPL version 2.
 *
 *   Since our code is currently under active development we prefer that
 *   everyone gets the it directly from us.  This will permit us to
 *   collaborate with all of the users.  So for the time being, please refer
 *   potential users to us instead of redistributing web100.
 */

/*
 * Composite Instrument Set demo code
 */
#include <stdio.h>
#include <stdlib.h>
#include "web100.h"

/* NB: this sample code is for a prototype API that has not been finalized.
 * It has some serious limitation and may not appear in future releases.
 * If you wish to contribute suggestions, please send them to prog@web100.org.
 *
 * Problems:
 * Implicit snap management is risky
 * DEF_* macros use statics to cache web100_var's in a way that clashes with their scope rules.
 */

/* In the future these lines will appear in an automaticly generated file */
DEF_COUNTER(CurrTime, unsigned int);
DEF_COUNTER(DataBytesOut, unsigned int);

main(int argc, char *argv[]) {
  struct web100_agent *ag;
  struct web100_connection *co;

  if (argc < 2) {
    printf("Usage: demo ConnectionID\n");
    exit (2);
  }

  ag=web100_attach("localhost");
  co=web100_find_connection(ag, argv[1]);

  web100_get_snapshot(co, WEB100_DEFAULT);	/* Get first sample */
  while (1) {
    int val;
    sleep (1);
    web100_free_snap(0);			/* implicit snap handeling */
    web100_get_snapshot(co, WEB100_DEFAULT);
    val = web100_delta_DataBytesOut(0,0);	/* implicit snap handeling */
    printf("%d\n", val);
  }

}
