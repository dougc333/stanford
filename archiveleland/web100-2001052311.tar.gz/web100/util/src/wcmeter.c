
/*
 *  Copyrights
 *
 *   All documentation and programs in this release is copyright (c)
 *   Carnegie Mellon University, The Board of Trustees of the University of
 *   Illinois, and University Corporation for Atmospheric Research, 2001.
 *   This software comes with NO WARRANTY.
 *
 *   The kernel changes and additions are also covered by the GPL version 2.
 *
 *   Since our code is currently under active development we prefer that
 *   everyone gets the it directly from us.  This will permit us to
 *   collaborate with all of the users.  So for the time being, please refer
 *   potential users to us instead of redistributing web100.
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <gtk/gtk.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <math.h>

#include <gtk/gtkmain.h>
#include <gtk/gtksignal.h>

#include "wcmeter.h"

#define DEFAULT_SIZE 150


static void wc_meter_class_init(WcMeterClass *klass);
static void wc_meter_init(WcMeter *meter);
static void wc_meter_destroy(GtkObject *object);
static void wc_meter_realize(GtkWidget *widget);
static void wc_meter_size_request(GtkWidget *widget,
					GtkRequisition *requisition);
static void wc_meter_size_allocate(GtkWidget *widget,
					GtkAllocation *allocation);
static gint wc_meter_expose(GtkWidget *widget, GdkEventExpose *event);
static gint wc_meter_configure(GtkWidget *widget, GdkEventConfigure *event);
static gint wc_meter_button_press(GtkWidget *widget, GdkEventButton *event);
static gint wc_meter_button_release(GtkWidget *widget, GdkEventButton *event);
static gint wc_meter_motion_notify(GtkWidget *widget, GdkEventMotion *event);
static gint wc_meter_timer(WcMeter *meter); 
static void wc_meter_update_mouse(WcMeter *meter, gint x, gint y);
static void wc_meter_update(WcMeter *meter);
static void wc_meter_adjustment_changed(GtkAdjustment *adjustment,
					gpointer data);
static void wc_meter_adjustment_value_changed (GtkAdjustment *adjustment,
						gpointer data);

static GtkWidgetClass *parent_class = NULL;
static GdkPixmap *pixmap = NULL;
char temptext[60];

guint wc_meter_get_type ()
{
	static guint meter_type = 0;

	if (!meter_type){
		GtkTypeInfo meter_info = {
			"WcMeter",
			sizeof (WcMeter),
			sizeof (WcMeterClass),
			(GtkClassInitFunc) wc_meter_class_init,
			(GtkObjectInitFunc) wc_meter_init,
			(GtkArgSetFunc) NULL,
			(GtkArgGetFunc) NULL,
		};

		meter_type = gtk_type_unique (gtk_widget_get_type (),
						&meter_info);
	}
	return meter_type;
}

static void wc_meter_class_init (WcMeterClass *class)
{
	GtkObjectClass *object_class;
	GtkWidgetClass *widget_class;
	
	object_class = (GtkObjectClass*) class;
	widget_class = (GtkWidgetClass*) class;
	parent_class = gtk_type_class (gtk_widget_get_type ());
	object_class->destroy = wc_meter_destroy;
	widget_class->realize = wc_meter_realize;
	widget_class->expose_event = wc_meter_expose;
	widget_class->configure_event = wc_meter_configure;
	widget_class->size_request = wc_meter_size_request;
	widget_class->size_allocate = wc_meter_size_allocate;
}

static void wc_meter_init (WcMeter *meter)
{
	meter->button = 0;
	meter->policy = GTK_UPDATE_CONTINUOUS;
	meter->timer = 0;
	meter->radius = 0;
	meter->pointer_width = 0;
	meter->angle = 0.0;
	meter->old_value = 0.0;
	meter->old_lower = 0.0;
	meter->old_upper = 0.0;
	meter->adjustment = NULL;
}

GtkWidget* wc_meter_new(GtkAdjustment *adjustment)
{
	WcMeter *meter;
	GdkFont *fixed_font;

	fixed_font =
		gdk_font_load ("-miwc-fixed-medium-r-*-*-*-140-*-*-*-*-*-*");

	meter = gtk_type_new (wc_meter_get_type ());
	meter->font = fixed_font;

	if (!adjustment)
		adjustment = (GtkAdjustment*) gtk_adjustment_new (0.0, 0.0, 0.0, 0.0, 0.0, 0.0);

	wc_meter_set_adjustment (meter, adjustment);

	return GTK_WIDGET (meter);
}

static void wc_meter_destroy(GtkObject *object)
{
	WcMeter *meter;

	g_return_if_fail (object != NULL);
	g_return_if_fail (WC_IS_METER (object));

	meter = WC_METER (object);

	if (meter->adjustment)
		gtk_object_unref (GTK_OBJECT (meter->adjustment));

	if (GTK_OBJECT_CLASS (parent_class)->destroy)
		(* GTK_OBJECT_CLASS (parent_class)->destroy) (object);
}

GtkAdjustment* wc_meter_get_adjustment(WcMeter *meter)
{
	g_return_val_if_fail (meter != NULL, NULL);
	g_return_val_if_fail (WC_IS_METER (meter), NULL);

	return meter->adjustment;
}

void wc_meter_set_update_policy(WcMeter *meter,
				GtkUpdateType policy)
{
	g_return_if_fail (meter != NULL);
	g_return_if_fail (WC_IS_METER (meter));

	meter->policy = policy;
}

void wc_meter_set_adjustment(WcMeter *meter, GtkAdjustment *adjustment)
{
	g_return_if_fail (meter != NULL);
	g_return_if_fail (WC_IS_METER (meter));

	if (meter->adjustment)
	{
		gtk_signal_disconnect_by_data (GTK_OBJECT (meter->adjustment),
						(gpointer) meter);
		gtk_object_unref (GTK_OBJECT (meter->adjustment));
	}

	meter->adjustment = adjustment;
	gtk_object_ref (GTK_OBJECT (meter->adjustment));

	gtk_signal_connect (GTK_OBJECT (adjustment), "changed",
			(GtkSignalFunc) wc_meter_adjustment_changed,
			(gpointer) meter);
	gtk_signal_connect (GTK_OBJECT (adjustment), "value_changed",
			(GtkSignalFunc) wc_meter_adjustment_value_changed,
			(gpointer) meter);

	meter->old_value = adjustment->value;
	meter->old_lower = adjustment->lower;
	meter->old_upper = adjustment->upper;

	wc_meter_update (meter);
}

static void wc_meter_realize(GtkWidget *widget)
{ 
	WcMeter *meter;
	GdkWindowAttr attributes;
	gint attributes_mask;

	g_return_if_fail (widget != NULL);
	g_return_if_fail (WC_IS_METER (widget));

	GTK_WIDGET_SET_FLAGS (widget, GTK_REALIZED);
	meter = WC_METER (widget);

	attributes.x = widget->allocation.x;
	attributes.y = widget->allocation.y;
	attributes.width = widget->allocation.width;
	attributes.height = widget->allocation.height;
	attributes.wclass = GDK_INPUT_OUTPUT;
	attributes.window_type = GDK_WINDOW_CHILD;
	attributes.event_mask = gtk_widget_get_events (widget) | 
		/* TEST */
/* 		GDK_CONFIGURE_MASK | */
		GDK_EXPOSURE_MASK | GDK_BUTTON_PRESS_MASK | 
		GDK_BUTTON_RELEASE_MASK | GDK_POINTER_MOTION_MASK |
		GDK_POINTER_MOTION_HINT_MASK;
	attributes.visual = gtk_widget_get_visual (widget);
	attributes.colormap = gtk_widget_get_colormap (widget);

	attributes_mask = GDK_WA_X | GDK_WA_Y | GDK_WA_VISUAL | GDK_WA_COLORMAP;
	widget->window = gdk_window_new (widget->parent->window, &attributes, attributes_mask);

	widget->style = gtk_style_attach (widget->style, widget->window);

	gdk_window_set_user_data (widget->window, widget);

	gtk_style_set_background (widget->style, widget->window, GTK_STATE_NORMAL);
}

static void wc_meter_size_request(GtkWidget *widget,
				GtkRequisition *requisition)
{
	requisition->width = DEFAULT_SIZE;
	requisition->height = DEFAULT_SIZE;
}

static void wc_meter_size_allocate(GtkWidget *widget, GtkAllocation *allocation)
{
	WcMeter *meter;

	g_return_if_fail (widget != NULL);
	g_return_if_fail (WC_IS_METER (widget));
	g_return_if_fail (allocation != NULL);

	widget->allocation = *allocation;
	meter = WC_METER (widget);

	if (GTK_WIDGET_REALIZED (widget))
	{ 
		gdk_window_move_resize (widget->window,
				allocation->x, allocation->y,
				allocation->width, allocation->height);

	}
	meter->radius = MIN(allocation->width,allocation->height) * 0.45;
	meter->pointer_width = meter->radius / 5;
}

gint wc_meter_repaint(GtkWidget *widget)
{
  WcMeter *meter;
  GdkPoint points[6];
  gdouble s,c;
  gdouble theta, last, increment; 
  gint xc, yc;
  gint upper, lower;
  gint tick_length;
  gint i, inc;

  g_return_val_if_fail (widget != NULL, FALSE);
  g_return_val_if_fail (WC_IS_METER (widget), FALSE);

  meter = WC_METER (widget);

  if((meter->adjustment->upper)/1000000 > 1){
    sprintf(temptext, "%d", (int) (meter->adjustment->upper)/1000000);
    strcat(temptext, " M");
  } else if ((meter->adjustment->upper)/1000 > 1){
    sprintf(temptext, "%d", (int) (meter->adjustment->upper)/1000);
    strcat(temptext, " k");
  } else sprintf(temptext, "%d", (int) meter->adjustment->upper);

	/*  gdk_window_clear_area (widget->window,
	 *  0, 0,
	 *  widget->allocation.width,
	 *  widget->allocation.height); */

  gdk_draw_rectangle(pixmap,
      widget->style->base_gc[widget->state],
      TRUE, 0, 0,
      widget->allocation.width,
      widget->allocation.height);

  xc = widget->allocation.width/2;
  yc = widget->allocation.height/2;

  upper = meter->adjustment->upper;
  lower = meter->adjustment->lower; 
/*  We want to allow NULL adjustments initially */ 
  if ((upper - lower) == 0) return;

  if(meter->radius)
    increment = (100*M_PI)/(meter->radius*meter->radius);

/*   inc = (upper - lower); */
  inc = 100;

  while (inc < 100) inc *=10;
  while (inc >= 1000) inc /=10;
  last = -1;

  for (i=0; i<=inc; i++)
  {
    theta = ((gfloat)i*M_PI/(18*inc/24.) - M_PI/6.);

    if ((theta - last) < (increment))
      continue;     
    last = theta;

    s = sin(theta);
    c = cos(theta);

    tick_length = (i%(inc/10) == 0) ? meter->pointer_width : meter->pointer_width/2;

    gdk_draw_line (pixmap,
	widget->style->fg_gc[widget->state],
	xc + c*(meter->radius - tick_length),
	yc - s*(meter->radius - tick_length),
	xc + c*meter->radius,
	yc - s*meter->radius);
  }

  gdk_draw_text(pixmap, widget->style->font,
      widget->style->fg_gc[widget->state],
      xc + cos(-M_PI/6.)*meter->radius-40,
      yc - sin(-M_PI/6.)*meter->radius+15,
      temptext, strlen(temptext));

  s = sin(meter->angle);
  c = cos(meter->angle);
  meter->last_angle = meter->angle;

  points[0].x = xc + s*meter->pointer_width/2;
  points[0].y = yc + c*meter->pointer_width/2;
  points[1].x = xc + c*meter->radius;
  points[1].y = yc - s*meter->radius;
  points[2].x = xc - s*meter->pointer_width/2;
  points[2].y = yc - c*meter->pointer_width/2;
  points[3].x = xc - c*meter->radius/10;
  points[3].y = yc + s*meter->radius/10;
  points[4].x = points[0].x;
  points[4].y = points[0].y;

  gtk_draw_polygon (widget->style,
      pixmap,
      GTK_STATE_NORMAL,
      GTK_SHADOW_OUT,
      points, 5,
      TRUE);

  return FALSE;
}

static gint wc_meter_expose(GtkWidget *widget, GdkEventExpose *event)
{ 
 	wc_meter_configure(widget, NULL);  
	wc_meter_repaint(widget);

	gdk_draw_pixmap(widget->window,
			widget->style->bg_gc[GTK_WIDGET_STATE(widget)],//XXX
			pixmap,
			event->area.x, event->area.y,
			event->area.x, event->area.y,
			event->area.width, event->area.height);
}

static gint wc_meter_configure(GtkWidget *widget, GdkEventConfigure *event)
{ 
	if(pixmap){ 
		gdk_pixmap_unref(pixmap);
	}
	pixmap = gdk_pixmap_new(widget->window,
			widget->allocation.width,
			widget->allocation.height,
			-1); 
	return TRUE;
}

static gint wc_meter_timer(WcMeter *meter)
{
	g_return_val_if_fail (meter != NULL, FALSE);
	g_return_val_if_fail (WC_IS_METER (meter), FALSE);

	if (meter->policy == GTK_UPDATE_DELAYED)
		gtk_signal_emit_by_name (GTK_OBJECT (meter->adjustment), "value_changed");

	return FALSE;
}

static void wc_meter_update(WcMeter *meter)
{
	gfloat new_value;

	g_return_if_fail (meter != NULL);
	g_return_if_fail (WC_IS_METER (meter));

	new_value = meter->adjustment->value;

	if (new_value < meter->adjustment->lower)
		new_value = meter->adjustment->lower;

	if (new_value > meter->adjustment->upper)
		new_value = meter->adjustment->upper;

/*   if (new_value != meter->adjustment->value)
    {
      meter->adjustment->value = new_value;
      gtk_signal_emit_by_name (GTK_OBJECT (meter->adjustment), "value_changed");
    } */

	meter->angle = 7.*M_PI/6. - (new_value - meter->adjustment->lower) * 4.*M_PI/3. /
		(meter->adjustment->upper - meter->adjustment->lower);

	gtk_widget_draw (GTK_WIDGET(meter), NULL);
}

static void wc_meter_adjustment_changed(GtkAdjustment *adjustment,
					gpointer data)
{
	WcMeter *meter;

	g_return_if_fail (adjustment != NULL);
	g_return_if_fail (data != NULL);

	meter = WC_METER (data);

	if ((meter->old_value != adjustment->value) ||
			(meter->old_lower != adjustment->lower) ||
			(meter->old_upper != adjustment->upper))
	{
		wc_meter_update (meter);

		meter->old_value = adjustment->value;
		meter->old_lower = adjustment->lower;
		meter->old_upper = adjustment->upper;
	}
}

static void wc_meter_adjustment_value_changed(GtkAdjustment *adjustment,
						gpointer data)
{
	WcMeter *meter;

	g_return_if_fail (adjustment != NULL);
	g_return_if_fail (data != NULL);

	meter = WC_METER (data);

	if (meter->old_value != adjustment->value)
	{
		wc_meter_update (meter);

		meter->old_value = adjustment->value;
	}
} 
