
/*
 *  Copyrights
 *
 *   All documentation and programs in this release is copyright (c)
 *   Carnegie Mellon University, The Board of Trustees of the University of
 *   Illinois, and University Corporation for Atmospheric Research, 2001.
 *   This software comes with NO WARRANTY.
 *
 *   The kernel changes and additions are also covered by the GPL version 2.
 *
 *   Since our code is currently under active development we prefer that
 *   everyone gets the it directly from us.  This will permit us to
 *   collaborate with all of the users.  So for the time being, please refer
 *   potential users to us instead of redistributing web100.
 */

/*
 * Basic c routine for reading variable from a Kernel Instrument Set
 */

#define MAXNUMFILES 20
#define MAXCNAME 20

enum {
	TYPE_INTEGER=0,
	TYPE_INTEGER32,
	TYPE_IP_ADDRESS,
	TYPE_COUNTER32,
	TYPE_GAUGE32,
	TYPE_UNSIGNED32,
	TYPE_TIME_TICKS,
	TYPE_COUNTER64,
	TYPE_UNSIGNED16
};

struct web100_var {
  char *name;
  u_int32_t type;
  int offset;
  int length;

  struct web100_agent *agent;
  struct web100_file *file;
  struct web100_var *next;
};

struct web100_file {
  char *name;
  int size;
  struct web100_var *first_var;
  struct web100_agent *agent;  
};

struct web100_agent {
  /* future SNMP goop goes here */

  struct web100_file *fp[MAXNUMFILES];
};

struct web100_ftuple {
  u_int32_t localadd, remoteadd;
  u_int16_t localport, remoteport;
};

struct web100_connection {
  /* future fd cacheing goop goes here */
  struct web100_agent *agent;
  char *error;

  char cid[MAXCNAME];
  struct web100_ftuple *ftuple;
};

struct web100_snap {
  struct web100_connection *conn;
  struct web100_file *file;
  int size;
  char *buff;
};

struct web100_agent *web100_attach(char *);

struct web100_agent *web100_header(FILE *);
struct web100_var *web100_find_var(struct web100_connection *, char *);

struct web100_ftuple *web100_get_ftuple(struct web100_agent *, char *);
struct web100_connection *web100_find_connection(struct web100_agent *, char *);
int web100_verify_connection(struct web100_connection *);
int web100_is_errored(struct web100_connection *);
void web100_perror(struct web100_connection *);
void web100_free_connection(struct web100_connection *);

/* NB: for get_snapshot we provide two macros to hide web100_file from the applications.
 * All invocations of get_snapshot should use one of these as its argument. */
struct web100_snap *web100_get_snapshot(struct web100_connection *, struct web100_file *);
extern struct web100_file *web100_def_file, *web100_spec_file;
#define web100_default_group web100_def_file
#define web100_spec_group web100_spec_file
#define WEB100_DEFAULT web100_def_file	/* Do not use: deprecated */
#define web100_get_group(v) ((v)->file)
void web100_free_snap(struct web100_snap *);
/* snap history for implicit deltas */
extern struct web100_snap *lastsnap, *priorsnap;

/* Basic variable accesses */
int web100_get_any(struct web100_var *, struct web100_snap *, void *, int);
u_int16_t web100_get_any16(struct web100_var *, struct web100_snap *);
u_int32_t web100_get_any32(struct web100_var *, struct web100_snap *);
u_int64_t web100_get_any64(struct web100_var *, struct web100_snap *);
u_int32_t web100_delta_any32(struct web100_var *, struct web100_snap *, struct web100_snap *);

/*  properly typed variable access methods */
#define web100_get_integer(v,n)		((u_int32_t) web100_get_any32(v,n))
#define web100_get_integer32(v,n)	((u_int32_t) web100_get_any32(v,n))
#define web100_get_counter32(v,n)	((u_int32_t) web100_get_any32(v,n))
#define web100_get_gauge32(v,n)		((u_int32_t) web100_get_any32(v,n))
#define web100_get_unsigned32(v,n)	((u_int32_t) web100_get_any32(v,n))
#define web100_get_time_ticks(v,n)	((u_int32_t) web100_get_any32(v,n))
#define web100_get_unsigned16(v,n)	((u_int16_t) web100_get_any16(v,n))
#define web100_get_counter64(v,n)	((u_int64_t) web100_get_any64(v,n))	/* will fail */
#define web100_get_IPv4_address(v,n,a)	((u_int8_t) web100_get_any(v,n,a,4))
#define web100_delta_integer(v,n,o)	((u_int32_t) web100_delta_any32(v,n,o))
#define web100_delta_integer32(v,n,o)	((u_int32_t) web100_delta_any32(v,n,o))
#define web100_delta_counter32(v,n,o)	((u_int32_t) web100_delta_any32(v,n,o))
#define web100_delta_gauge32(v,n,o)	((u_int32_t) web100_delta_any32(v,n,o))
#define web100_delta_unsigned32(v,n,o)	((u_int32_t) web100_delta_any32(v,n,o))
#define web100_delta_time_ticks(v,n,o)	((u_int32_t) web100_delta_any32(v,n,o))
#define web100_delta_unsigned16(v,n,o)	((u_int16_t) web100_delta_any16(v,n,o))
#define web100_delta_counter64(v,n,o)	((u_int64_t) web100_delta_any64(v,n,o))	/* will fail */

/* Raw access is limited to special situations - not for general use */
int web100_raw_get_any(struct web100_connection *, struct web100_var *, void *, int);
u_int32_t web100_raw_get_any32(struct web100_connection *, struct web100_var *);
int web100_raw_put_any32(struct web100_connection *, struct web100_var *, u_int32_t);

/* Backward compatability for deprecated names - do not use */
#define web100_do_snap(a, b) web100_get_snapshot(a, b) /* deprecated */
#define web100_locate_connection(a, b) web100_find_connection(a, b) /* deprecated */

/* Prototype macros to generate functions to access variables.
 * XXX NB: these use static struct web100_var as an implicit cache 
 * which may prove to be unsuitable for many applications.
 *
 * THESE MAY NOT BE INCLUDED IN FUTURE RELEASES.
 * If you have suggestions please send mail to
 * discussion@web100.org
 */

#define DEF_GAUGE(name, type)\
type web100_get_##name(struct web100_snap *a) {\
 static struct web100_var *va;\
 if (!a) a = lastsnap;\
 if (!va) va=web100_find_var(a->conn, #name);\
 return (type) (web100_get_any32(va, a));\
}

#define DEF_COUNTER(name, type) DEF_GAUGE(name, type) \
type web100_delta_##name(struct web100_snap *a, struct web100_snap *b){\
 static struct web100_var *va;\
 if (!a) a = lastsnap;\
 if (!b) b = priorsnap;\
 if (!va) va=web100_find_var(a->conn, #name);\
 return (type) (web100_delta_any32(va, a, b));\
}

