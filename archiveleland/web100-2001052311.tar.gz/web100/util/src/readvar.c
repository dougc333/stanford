
/*
 *  Copyrights
 *
 *   All documentation and programs in this release is copyright (c)
 *   Carnegie Mellon University, The Board of Trustees of the University of
 *   Illinois, and University Corporation for Atmospheric Research, 2001.
 *   This software comes with NO WARRANTY.
 *
 *   The kernel changes and additions are also covered by the GPL version 2.
 *
 *   Since our code is currently under active development we prefer that
 *   everyone gets the it directly from us.  This will permit us to
 *   collaborate with all of the users.  So for the time being, please refer
 *   potential users to us instead of redistributing web100.
 */

/*
 * Web100 MIB read tool for scripts
 */
#include <stdio.h>
#include <sys/types.h>
#include "web100.h"

main (int argc, char *argv[]) {
  struct web100_agent *ag;
  struct web100_connection *conn;
  struct web100_var **wv;
  unsigned int value;
  int count, i;

  if (argc < 3) {
    printf("Usage: readvar ConnectionID VarName(s)\n");
    exit(2);
  }
  count=argc-2;
  wv=(struct web100_var **) malloc(count*sizeof(void*));

  ag=web100_attach("localhost");
  conn=web100_find_connection(ag, argv[1]);
  for (i=0; i < count; i++) {
    wv[i]=web100_find_var(conn, argv[i+2]);
  }

  for (i=0; i <count; i++) { 
    web100_raw_get_any(conn, wv[i], &value, wv[i]->length); 
    if(wv[i]->type == TYPE_IP_ADDRESS)
      printf("%d.%d.%d.%d",
	  ((u_int32_t) value) & 0xff,
	  ((u_int32_t) value >> 8) & 0xff,
	  ((u_int32_t) value >> 16) & 0xff,
	  ((u_int32_t) value >> 24) & 0xff);
    else
    if(wv[i]->length == 2) printf("%u ", (u_int16_t) value);
    else printf("%u ", (u_int32_t) value);
  }
  printf("\n");

  web100_free_connection(conn);

  exit (0);
}
