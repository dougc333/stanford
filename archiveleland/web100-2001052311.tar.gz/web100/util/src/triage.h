#define METER  0
#define GRAPH  1
#define PIE    2

#define SND 0 
#define CNG 1
#define RCV 2

struct pie_data{
	struct web100_var *var[3];
	unsigned int new_val[3], old_val[3], delta[3], old_delta[3];
	float new_ewma[3], old_ewma[3], total;
};

struct mib_win{
	int type;
/* 	char hostname[40]; */
	struct web100_connection *conn;
	struct web100_var *var;
	char ftuple[60];

	struct web100_snap *lastsnap, *priorsnap;

	unsigned int val, new_val, old_val, delta, old_delta;
	float new_ewma, old_ewma, total, max, oldmax; 
	float graphval[20];

	int sample_handlerid, current, interval;

	GtkWidget *topwin, *meter, *graph, *clist, *displaybox;
	struct pie_data *pd;

	int virgin;
	int display;
};

void launch_vd(struct web100_agent *agent, char *cid, char *ftuple,
		int interval, int mask, int display);
