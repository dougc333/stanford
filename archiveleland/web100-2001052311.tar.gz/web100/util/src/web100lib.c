
/*
 *  Copyrights
 *
 *   All documentation and programs in this release is copyright (c)
 *   Carnegie Mellon University, The Board of Trustees of the University of
 *   Illinois, and University Corporation for Atmospheric Research, 2001.
 *   This software comes with NO WARRANTY.
 *
 *   The kernel changes and additions are also covered by the GPL version 2.
 *
 *   Since our code is currently under active development we prefer that
 *   everyone gets the it directly from us.  This will permit us to
 *   collaborate with all of the users.  So for the time being, please refer
 *   potential users to us instead of redistributing web100.
 */

/*
 * Basic c routine for reading variable from a Kernel Instrument Set
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "web100.h"

#define WEB100_ROOT_DIR "/proc/web100/"
#define HEADER_FILE     WEB100_ROOT_DIR "header"

#define NOTNULL(v, m) {if (!(v)) {fprintf(stderr,"%s\n",m); abort();}}

char version[100];
int numfiles = -1; 

/* These must match the web100 type enum */
static int sizes[]={
	4,	/* TYPE_INTEGER */
	4,	/* TYPE_INTEGER32 */
	4,	/* TYPE_IP_ADDRESS */
	4,	/* TYPE_COUNTER32 */
	4,	/* TYPE_GAUGE32 */
	4,	/* TYPE_UNSIGNED32 */
	4,	/* TYPE_TIME_TICKS */
	8,	/* TYPE_COUNTER64 */
	2	/* TYPE_UNSIGNED16 */
};

/****************************************************************
 * Manage agents - (remote) data collection points
 *	NB: This assumes that all connections observed by an agent
 *	have the same instruments.  THIS MAY PROVE TO BE INCORRECT.
 ****************************************************************/
struct web100_file *web100_def_file=NULL, *web100_tune_file=NULL,
                   *web100_spec_group=NULL;

struct web100_agent *web100_attach(char *hostname) {
  FILE *file; 

  if (strcmp("localhost", hostname) != 0) {
    fprintf(stderr, "web100 attach: This library only supports local instrument sets\n");
    abort();
  }

  if ((file = fopen(HEADER_FILE, "r")) == NULL) {
    perror("web100: can not open /proc/web100/header");
    abort();
  }
  return(web100_header(file));
}

/****************************************************************
 * Build and search the runtime symbol table of variable names.
 ****************************************************************/
struct web100_agent *web100_header(FILE *file) {
  char *name, *label;
  int offset, filesize, size, type; 
  struct web100_var *vp;
  struct web100_agent *agent = malloc(sizeof(struct web100_agent));
  NOTNULL(agent, "web100 header: out of memory");
  bzero(agent, sizeof(struct web100_agent));

  fscanf(file, "%[^\n]\n", &version);

  while (!feof(file)) {
    name=malloc(MAXCNAME);
    NOTNULL(name, "web100 header: out of memory");
    if (fscanf(file, "%19s\n", name) != 1) {
      fprintf(stderr, "web100 header: parse error\n");
      break;
    }
		
    if (name[0] == '/') {
      agent->fp[++numfiles] = (struct web100_file *)malloc(sizeof (struct web100_file));
      NOTNULL(agent->fp[numfiles], "web100 header: out of memory");
      agent->fp[numfiles]->agent = agent;
      agent->fp[numfiles]->name = name;
      agent->fp[numfiles]->first_var = NULL;
      agent->fp[numfiles]->size = filesize = 0;
      if (strcmp("/spec", name) == 0) {
	if (web100_spec_file != NULL) {
	  web100_spec_file = (struct web100_file *) -1;	/* fatal later if used */
	} else {
	  web100_spec_file = agent->fp[numfiles];
	}
      } else if (strcmp("/read", name) == 0) {
	if (web100_def_file != NULL) {
	  web100_def_file = (struct web100_file *) -1;	
	} else {
	  web100_def_file = agent->fp[numfiles];
	}
      } else if (strcmp("/tune", name) == 0) {
	if (web100_tune_file != NULL) {
	  web100_tune_file = (struct web100_file *) -1;  
	} else {
	  web100_tune_file = agent->fp[numfiles];
	}
      } 
    } else {
      if (numfiles==-1) {
	fprintf(stderr, "web100 header: missing file names!\n");
	abort();
      }
      if (fscanf(file, "%d%d\n", &offset, &type) != 2) {
	fprintf(stderr, "web100 header: missing data!\n");
	abort();
      }
			
      vp = malloc(sizeof (struct web100_var));
      NOTNULL(vp, "web100 header: out of memory");
      vp->name = name;
      vp->type = type;
      vp->offset = offset;
      if ((type < 0) || (type>TYPE_UNSIGNED16)) {
	fprintf(stderr, "web100 header: unknown data type %d (%s) from kernel versions %s\n", type, name, version);
	abort();
      }
      vp->length = size = sizes[type];
      vp->agent = agent;
      vp->file = agent->fp[numfiles];
      vp->next = agent->fp[numfiles]->first_var;
      if ((offset+size) > filesize) {
	agent->fp[numfiles]->size = filesize = offset+size;
      }
      agent->fp[numfiles]->first_var = vp;
    }
  }
  fclose(file);
  return(agent);
}

struct web100_var *web100_find_var(struct web100_connection *conn, char *name) {
  int i;
  struct web100_agent *agent;
  struct web100_var *wv;

  if (conn==NULL || conn->error) return(0);
  agent = conn->agent;

  for (i=0; i <= numfiles; i++) {
    for (wv=agent->fp[i]->first_var; wv; wv = wv->next) {
      if (strcmp(wv->name, name) == 0) return(wv);
    }
  }
  fprintf(stderr, "web100 failed to find variable: %s, suspect mismatch with kernel version %s\n",
	  name, version);
  exit(2);
  abort();		/* XXX */
  return(0);
}

/****************************************************************
 * Manage observed TCP connections
 * 	These are only relevant in the context a specific agent
 ****************************************************************/

struct web100_ftuple *web100_get_ftuple(struct web100_agent *agent, char *cid) {  struct web100_ftuple *ft;
  struct web100_var *wv;
  char temp[100];
  int ii=0;
  int fd;

  strcpy(temp, WEB100_ROOT_DIR);
  strcat(temp, cid);
  strcat(temp, "/spec"); 

  if((fd=open(temp, O_RDONLY)) < 0) goto punt;

  if(((struct web100_ftuple *) ft = malloc(sizeof(struct web100_ftuple)))==NULL){
    fprintf(stderr, "Out of memory!\n");
    exit(1);
  } 
  /* Should search agent->fp[] for "/spec" rather than presuming it's fp[0] */ 
  wv=agent->fp[0]->first_var; 
  if (lseek(fd, wv->offset, SEEK_SET) < 0) goto punt; 
  if (read(fd, &(ft->localadd), wv->length) != wv->length) goto punt;
  wv=wv->next; 
  if (lseek(fd, wv->offset, SEEK_SET) < 0) goto punt; 
  if (read(fd, &(ft->localport), wv->length) != wv->length) goto punt;
  wv=wv->next; 
  if (lseek(fd, wv->offset, SEEK_SET) < 0) goto punt; 
  if (read(fd, &(ft->remoteadd), wv->length) != wv->length) goto punt;
  wv=wv->next; 
  if (lseek(fd, wv->offset, SEEK_SET) < 0) goto punt; 
  if (read(fd, &(ft->remoteport), wv->length) != wv->length) goto punt;
  goto out;

  punt:
   ft=0; 
  out:
  close(fd);
  return(ft);
}

/* This is particularly bone headed:
 * cid = connection ID is the ascii of the connection number
 */

struct web100_connection *web100_find_connection(struct web100_agent *agent, char *cid) {
  struct web100_connection *ch;

  /* check for valid CID here */

  ch=malloc(sizeof (struct web100_connection));
  NOTNULL(ch, "web100 find connection: out of memeory"); 
  (void) strncpy(ch->cid, cid, MAXCNAME);
  ch->ftuple = web100_get_ftuple(agent, cid);
  if(ch->ftuple != NULL) ch->error = 0;
  else ch->error = "web100 find connection: connection closed"; 
  ch->agent = agent;
  return (ch);
}

int web100_verify_connection(struct web100_connection *ch) {
  struct web100_ftuple *ft;
  int ii;

  ft = web100_get_ftuple(ch->agent, ch->cid);
  if((ch->ftuple->localadd != ft->localadd) || 
     (ch->ftuple->localport != ft->localport) || 
     (ch->ftuple->remoteadd != ft->remoteadd) || 
     (ch->ftuple->remoteport != ft->remoteport)) { 
    free(ft);
    return 0;
  } 
  free(ft);
  return 1;
}

int web100_is_errored(struct web100_connection *ch) {
  return (ch->error != NULL);
}

void web100_perror(struct web100_connection *ch) {
  if (ch->error) {
    fprintf(stderr, "%s\n",ch->error); 
  } else {
    fprintf(stderr, "No error");
  }
}

void web100_free_connection(struct web100_connection *ch) {
  free(ch);
}

/****************************************************************
 * Do the actual I/0, open, close and snapshot all variables
 ****************************************************************/
static int web100_open(struct web100_connection *c, char *name, int writable) {
  char temp[100];
  int fd;

  /* TODO: fd caching here */

  strcpy(temp, WEB100_ROOT_DIR);
  strcat(temp, c->cid);
  /*  strcat(temp, "/");  XXX */
  strcat(temp, name);

  /* Caller must check for errors */
  fd=open(temp, writable?O_RDWR:O_RDONLY);
  if (fd < 0) {				/* debugging code */
    printf("web100 open: %s\n", temp);	/* debugging code */
    perror("web100 open");		/* debugging code */
  }					/* debugging code */
  return(fd);
}

static void web100_close(int fd) {
  /* TODO: fd caching here */

  close(fd);
}

struct web100_snap *lastsnap=NULL, *priorsnap=NULL;

struct web100_snap *web100_get_snapshot(struct web100_connection *c, struct web100_file *fi){
  int fd, size;
  struct web100_snap *ret;

  if (c==NULL || c->error) goto punt;

  if ((fi == NULL) || (((int) fi) == -1)) {
    fprintf(stderr, "web100 snapshot: Invalid get argument 2 (web100_default_group?)\n");
    abort();
  }

  fd = web100_open(c, fi->name, 0);
  if (fd < 0) {
    c->error = "web100 snapshot: connection closed"; 
    goto punt;
  } 
  if(!web100_verify_connection(c)) { 
    c->error = "web100 snapshot: connection closed";
    goto punt;
  }
  ret = (struct web100_snap *)malloc(sizeof(struct web100_snap));
  if (ret == NULL) {
    c->error = "web100 snapshot: out of memeory";
    goto punt;
  }
  ret->conn = c;
  ret->file = fi;
  ret->size = size = fi->size;
  ret->buff = malloc(size);
  if (ret->buff == NULL) {
    c->error = "web100 snapshot: out of memory";
    goto punt1;
  }

  /* Do future IS playback here */

  if (read(fd, ret->buff, size) != size) {
    c->error = "web100 snapshot: short read";
    goto punt2;
  }
  web100_close(fd);

  /* Do future Instrument Set trace and logging here */
  goto out;

 punt2:
  free(ret->buff);
 punt1:
  free(ret);
 punt:
  ret=0;
 out:
  /* support implicit snap management */
  priorsnap=lastsnap;
  lastsnap=ret;
  return(ret);
};

void web100_free_snap(struct web100_snap *s){
  if (!s) s=priorsnap;	/* implicit snap management */
  if (!s) return;
  free(s->buff);
  free(s);
};

/****************************************************************
 * Access Instruments (variables) associated with a given agent
 * and get their value or delta value
 * 	These are only relevant in the context a specific agent
 ****************************************************************/

int web100_get_any(struct web100_var *wv, struct web100_snap *s1, void *ptr, int len){
  if ((wv==NULL) || (s1==NULL)) {
    return 0;
  }
  if (wv->file != s1->file) {
    fprintf(stderr, "web100 get any: file mismatch\n");
    abort();
  }
  if (wv->length != len) {
    fprintf(stderr, "web100 get any: length mismatch\n");
    abort();
  }

  memcpy(ptr, s1->buff+wv->offset, len);
  return 1;
};

u_int32_t web100_get_any32(struct web100_var *wv, struct web100_snap *s1){
  u_int32_t v1;
  web100_get_any(wv, s1, &v1, 4);
  return(v1);
};

u_int16_t web100_get_any16(struct web100_var *wv, struct web100_snap *s1){
  u_int16_t v1;
  web100_get_any(wv, s1, &v1, 2);
  return(v1);
};

u_int32_t web100_delta_any32(struct web100_var *wv,
			     struct web100_snap *s1, struct web100_snap *s2){
  u_int32_t v1, v2;
  web100_get_any(wv, s1, &v1, 4);
  web100_get_any(wv, s2, &v2, 4);
  return(v1 - v2);
};

u_int16_t web100_delta_any16(struct web100_var *wv,
			     struct web100_snap *s1, struct web100_snap *s2){
  u_int16_t v1, v2;
  web100_get_any(wv, s1, &v1, 2);
  web100_get_any(wv, s2, &v2, 2);
  return(v1 - v2);
};

/****************************************************************
 * Functions to access single variables w/o a snapshot
 *	These should only be used in special circumstances
 ****************************************************************/
int web100_raw_get_any(struct web100_connection *c, struct web100_var *wv, void *val, int len) {
  int fd;

  if (c==NULL || c->error) return(0);

  if (wv->length != len) {
    fprintf(stderr, "web100 size mismatch: %s is not %d bytes\n", wv->name, len);
    abort();
  }
  if ((fd=web100_open(c, wv->file->name, 0)) < 0) goto punt;
  if (lseek(fd, wv->offset, SEEK_SET) < 0) goto punt;
  if (read(fd, val, wv->length) != wv->length) goto punt;
  web100_close(fd);
  return (1);
 punt:
  c->error = "web100 raw get any: connection closed";
  web100_close(fd);
  return (0);
}

u_int32_t web100_raw_get_any32(struct web100_connection *c, struct web100_var *wv) {
  u_int32_t val;
  if (web100_raw_get_any(c, wv, &val, 4)) {
    return (val);
  } else {
    return (0);
  }
}

int web100_raw_put_any32(struct web100_connection *c, struct web100_var *wv, u_int32_t val) {
  int fd;

  if (c==NULL || c->error) return(0);

  if (wv->length != sizeof(u_int32_t)) {
    fprintf(stderr, "Web100 size mismatch: %s is not 32 bits\n", wv->name);
    abort();
  }
  if ((fd=web100_open(c, wv->file->name, 1)) < 0) goto punt;
  if (lseek(fd, wv->offset, SEEK_SET) < 0) goto punt;
  if (write(fd, &val, wv->length) != wv->length) goto punt;
  web100_close(fd);
  return(1);
 punt:
  c->error = "web100 raw put any32: connection closed";
  web100_close(fd);
  return (0);
}
