
/*
 *  Copyrights
 *
 *   All documentation and programs in this release is copyright (c)
 *   Carnegie Mellon University, The Board of Trustees of the University of
 *   Illinois, and University Corporation for Atmospheric Research, 2001.
 *   This software comes with NO WARRANTY.
 *
 *   The kernel changes and additions are also covered by the GPL version 2.
 *
 *   Since our code is currently under active development we prefer that
 *   everyone gets the it directly from us.  This will permit us to
 *   collaborate with all of the users.  So for the time being, please refer
 *   potential users to us instead of redistributing web100.
 */

/*
 * Web100 MIB read tool for scripts
 */
#include <stdio.h>
#include <sys/types.h>
#include "web100.h"

main (int argc, char *argv[]) {
  struct web100_agent *ag;
  struct web100_connection *conn;
  struct web100_snap *ns, *os=0;
  struct web100_var **wv;
  unsigned int value, delta;
  unsigned char addr[4];
  int count, i;

  if (argc < 3) {
    printf("Usage: deltavar ConnectionID VarName(s)\n");
    exit(2);
  }
  count=argc-2;
  wv=(struct web100_var **) malloc(count*sizeof(void*));

  /* Find the agent, connection and all pertinent variables */
  ag=web100_attach("localhost");
  conn=web100_find_connection(ag, argv[1]);
  for (i=0; i < count; i++) {
    wv[i]=web100_find_var(conn, argv[i+2]);
  }

  ns=web100_get_snapshot(conn, web100_get_group(wv[0]));
  if (ns == NULL) {
    web100_perror(conn);
    exit(2);
  }
  while (1) {
    sleep(1);
    if (os) web100_free_snap(os);
    os=ns;
    ns=web100_get_snapshot(conn, web100_get_group(wv[0]));
    if (ns == NULL) {
      web100_perror(conn);
      exit(2);
    }
    for (i=0; i <count; i++) {
      switch (wv[i]->type) {
      case TYPE_INTEGER:
	value=web100_get_integer(wv[i], ns);
	delta=web100_delta_integer(wv[i], ns, os);
	printf("%u %u ", value, delta);
	break;

      case TYPE_INTEGER32:
	value=web100_get_integer32(wv[i], ns);
	delta=web100_delta_integer32(wv[i], ns, os);
	printf("%u %u ", value, delta);
	break;

      case TYPE_COUNTER32:
	value=web100_get_counter32(wv[i], ns);
	delta=web100_delta_counter32(wv[i], ns, os);
	printf("%u %u ", value, delta);
	break;

      case TYPE_GAUGE32:
	value=web100_get_gauge32(wv[i], ns);
	delta=web100_delta_gauge32(wv[i], ns, os);
	printf("%u %u ", value, delta);
	break;

      case TYPE_UNSIGNED32:
	value=web100_get_unsigned32(wv[i], ns);
	delta=web100_delta_unsigned32(wv[i], ns, os);
	printf("%u %u ", value, delta);
	break;

      case TYPE_TIME_TICKS:
	value=web100_get_time_ticks(wv[i], ns);
	delta=web100_delta_time_ticks(wv[i], ns, os);
	printf("%u %u ", value, delta);
	break;

      case TYPE_IP_ADDRESS:
	web100_get_IPv4_address(wv[i], ns, addr);
	printf("%u.%u.%u.%u - ", addr[0], addr[1], addr[2], addr[3]);
	break;
	
      case TYPE_UNSIGNED16:
	value=web100_get_unsigned16(wv[i], ns);
	delta=web100_delta_unsigned16(wv[i], ns, os);
	printf("%u %u ", value, delta);
	break;

	/* XXX In general we can not handle 64 bits */
      case TYPE_COUNTER64:
      default:
	printf("??%s(%d) ", wv[i]->name, wv[i]->type);
      }
    }
    printf("\n");
  }

  web100_free_connection(conn);
}
