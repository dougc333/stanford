
/*
 *  Copyrights
 *
 *   All documentation and programs in this release is copyright (c)
 *   Carnegie Mellon University, The Board of Trustees of the University of
 *   Illinois, and University Corporation for Atmospheric Research, 2001.
 *   This software comes with NO WARRANTY.
 *
 *   The kernel changes and additions are also covered by the GPL version 2.
 *
 *   Since our code is currently under active development we prefer that
 *   everyone gets the it directly from us.  This will permit us to
 *   collaborate with all of the users.  So for the time being, please refer
 *   potential users to us instead of redistributing web100.
 */

/*
 * Web100 MIB write tool for scripts
 */
#include <stdio.h>
#include <sys/types.h>
#include "web100.h"

main (int argc, char *argv[]) {
  struct web100_agent *ag;
  struct web100_connection *conn;
  struct web100_var *wv;
  unsigned int value;

  if (argc != 4) {
    printf("Usage: writevar ConnectionID VarName Value\n");
    exit(2);
  }

  ag=web100_attach("localhost");
  conn=web100_find_connection(ag, argv[1]);
  wv=web100_find_var(conn, argv[2]);

  value=atoi(argv[3]);
  web100_raw_put_any32(conn, wv, value);
  if (web100_is_errored(conn)) {
    printf ("web100 put failed\n");
    web100_perror(conn);	/* debugging code */
    perror("web100");		/* debugging code */
    exit (1);
  }
  web100_free_connection(conn);

  exit (0);
}
