
/*
 *  Copyrights
 *
 *   All documentation and programs in this release is copyright (c)
 *   Carnegie Mellon University, The Board of Trustees of the University of
 *   Illinois, and University Corporation for Atmospheric Research, 2001.
 *   This software comes with NO WARRANTY.
 *
 *   The kernel changes and additions are also covered by the GPL version 2.
 *
 *   Since our code is currently under active development we prefer that
 *   everyone gets the it directly from us.  This will permit us to
 *   collaborate with all of the users.  So for the time being, please refer
 *   potential users to us instead of redistributing web100.
 */

#ifndef __WCMETER_H__
#define __WCMETER_H__


#include <gdk/gdk.h>
#include <gtk/gtkadjustment.h>
#include <gtk/gtkwidget.h>


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


#define WC_METER(obj)          GTK_CHECK_CAST (obj, wc_meter_get_type (), WcMeter)
#define WC_METER_CLASS(klass)  GTK_CHECK_CLASS_CAST (klass, wc_meter_get_type (), WcMeterClass)
#define WC_IS_METER(obj)       GTK_CHECK_TYPE (obj, wc_meter_get_type ())


typedef struct _WcMeter        WcMeter;
typedef struct _WcMeterClass   WcMeterClass;

struct _WcMeter
{
  GtkWidget widget;

  /* update policy (GTK_UPDATE_[CONTINUOUS/DELAYED/DIWCONTINUOUS]) */
  guint policy : 2;

  /* Button currently pressed or 0 if none */
  guint8 button;

  /* Dimensions of dial components */
  gint radius;
  gint pointer_width;

  /* ID of update timer, or 0 if none */
  guint32 timer;

  /* Current angle */
  gfloat angle;
  gfloat last_angle;

  /* Old values from adjustment stored so we know when something changes */
  gfloat old_value;
  gfloat old_lower;
  gfloat old_upper;

  /* The adjustment object that stores the data for this dial */
  GtkAdjustment *adjustment; 
  GdkFont *font;

};

struct _WcMeterClass
{
  GtkWidgetClass parent_class;
};


GtkWidget*     wc_meter_new                    (GtkAdjustment *adjustment);
guint          wc_meter_get_type               (void);
GtkAdjustment* wc_meter_get_adjustment         (WcMeter      *dial);
void           wc_meter_set_update_policy      (WcMeter      *dial,
						GtkUpdateType  policy);

void           wc_meter_set_adjustment         (WcMeter      *dial,
						GtkAdjustment *adjustment);
#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __WCMETER_H__ */
/* example-end */
