
/*
 *  Copyrights
 *
 *   All documentation and programs in this release is copyright (c)
 *   Carnegie Mellon University, The Board of Trustees of the University of
 *   Illinois, and University Corporation for Atmospheric Research, 2001.
 *   This software comes with NO WARRANTY.
 *
 *   The kernel changes and additions are also covered by the GPL version 2.
 *
 *   Since our code is currently under active development we prefer that
 *   everyone gets the it directly from us.  This will permit us to
 *   collaborate with all of the users.  So for the time being, please refer
 *   potential users to us instead of redistributing web100.
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <math.h> 
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include "web100.h" 
#include "wcmeter.h"
#include "wcgraph.h" 
#include "web100gui.h"

#include <gtk/gtk.h>

struct web100_agent *agent;
struct web100_connection *conn; 
struct web100_snap *snap;
struct web100_var *wv;
u_int32_t val;
u_int32_t delta;

float ewma, oldewma, max, oldmax;
float graphval[20];

char hostname[60];
char ftuple[60];

GtkWidget *topwin, *sessbox, *infobox, *updatescale, *radiobox,
		*entry0, *clist, *smoothbox, *sbutton, *mbutton, *boundbox,
		*displaybox[2], *meter, *graph, *clist; 
GtkAdjustment *adj;
GtkStyle *rcstyle;
GdkFont *font;
gint hsize, vsize;

#define METER 0
#define GRAPH 1
int mode = METER;
char *valtext;
int delta_on = 1, smoothing_on = 1;
int update_id;
float update_interval = 1.0; 
char text[4][20];

gint update_vdt(void);

void markup_vdtwin(void);

float get_ewma(float value, float oldewma, float weight)
{
  float ewma;

  ewma = weight*value + (1-weight)*oldewma;
  return(ewma);
}

#define CHECKMAX(s) {if (val <= (m=(s)*decade)) { return(m); }}

float newmax(float val, float oldmax)
{
  float m, decade;

  if (val > oldmax){
    decade = pow(10, floor(log10(val)));
    CHECKMAX(1.0); 
    CHECKMAX(2.0);
    CHECKMAX(5.0);
    CHECKMAX(10.0); // should be redundant
  }
  else return oldmax;
}

void new_vdt(char *cid, char *varname)
{
  char temp[60];
  wv = malloc(sizeof(struct web100_var));

  agent = web100_attach("localhost");
  conn = web100_find_connection(agent, cid); 
  snap = web100_get_snapshot(conn, web100_def_file);
  wv = web100_find_var(conn, varname);
  val = web100_get_any32(wv, snap);

  sprintftuple(ftuple, conn);

  markup_vdtwin();


  if(wv->type != 3 ){
    delta_on = smoothing_on = 0;
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON (sbutton), FALSE);
  }

  update_id = gtk_timeout_add(update_interval * 1000,
                              (GtkFunction) update_vdt, NULL); 
  update_vdt(); 

}

gint update_vdt(void)
{ 
  GtkAdjustment *adj[2]; 
  float result;
  int ii;

  free(priorsnap);
  snap = web100_get_snapshot(conn, web100_def_file);
  val = web100_get_any32(wv, snap);
 
  if(delta_on) {
    delta = web100_delta_any32(wv, lastsnap, priorsnap);
    result = (float) delta; 
  }
  else result = (float) val;
  if(smoothing_on) { 
    oldewma = ewma;
    result = ewma = get_ewma(result, oldewma, 0.4);
  } 
  if(result > oldmax)
  {

    max = newmax(result, oldmax);
    oldmax = max;

    /*
     * To re-set the upper bound, one needs re-define the gtk_adjustment;
     * the Gtk library takes care of unref'ing (destroying) the previous one.
     */

    adj[0] = GTK_ADJUSTMENT(gtk_adjustment_new(result, 0, max, 0.01, 0.1, 0));
    wc_meter_set_adjustment(WC_METER(meter), GTK_ADJUSTMENT(adj[0]));

    adj[1] = GTK_ADJUSTMENT(gtk_adjustment_new(result, 0, max, 0.01, 0.1, 0));
    wc_graph_set_adjustment(WC_GRAPH(graph), GTK_ADJUSTMENT(adj[1]));
  }

  gtk_adjustment_set_value(WC_METER(meter)->adjustment, result);
  gtk_widget_draw(meter, NULL);

  for(ii=0;ii<19;ii++){ graphval[ii] = graphval[ii+1];}
  graphval[19] = result;
  for(ii=0;ii<20;ii++){
    wc_graph_set_value(WC_GRAPH(graph), ii, graphval[ii]);
  } 
  gtk_widget_draw(graph, NULL);

  sprintf(valtext, "%u", val); 
  gtk_clist_set_text(GTK_CLIST(clist), 0, 1, valtext);
  if(delta_on) sprintf(valtext, "%u", delta);
  else strcpy(valtext, " ");
  gtk_clist_set_text(GTK_CLIST(clist), 1, 1, valtext); 
  if(smoothing_on) sprintf(valtext, "%.1f", result);
  else strcpy(valtext, " ");
  gtk_clist_set_text(GTK_CLIST(clist), 2, 1, valtext); 

  return TRUE;
}

void view_meter(GtkWidget *butt, gpointer data)
{ 
  gtk_widget_hide(displaybox[GRAPH]);
  gtk_widget_show(displaybox[METER]);
}

void view_graph(GtkWidget *butt, gpointer data)
{ 
  gtk_widget_hide(displaybox[METER]);
  gtk_widget_show(displaybox[GRAPH]);
}

gint toggle_smooth(GtkWidget *butt, gpointer data)
{ 
  smoothing_on = 1-smoothing_on;
}

gint lower_max(GtkWidget *butt, gpointer data)
{
  oldmax = 1.;
  gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(mbutton), TRUE); 
}

void markup_session(GtkWidget *hbox)
{
  GtkWidget *frame, *frame1, *entry0, *entry1, *hbox1;

  hbox1 = gtk_hbox_new(FALSE, 0);
  gtk_box_pack_start(GTK_BOX(hbox), hbox1, TRUE, FALSE, 0);
  gtk_widget_show(hbox1);

  frame = gtk_frame_new(NULL);
  gtk_frame_set_label(GTK_FRAME(frame), "TCP session name");
  gtk_frame_set_label_align(GTK_FRAME(frame), 0.5, 0.0); 
  gtk_box_pack_start(GTK_BOX(hbox1), frame, FALSE, FALSE, 0);
  gtk_widget_show(frame);

  entry0 = gtk_entry_new(); 
  gtk_entry_set_editable(GTK_ENTRY(entry0), FALSE); 
  hsize = gdk_string_width(font, ftuple);
  hsize += gdk_string_width(font, "w");
  vsize = gdk_string_height(font, ftuple);
  gtk_widget_set_usize(entry0, hsize, 1.6*vsize);
  gtk_entry_set_text(GTK_ENTRY(entry0), ftuple); 
  gtk_container_add(GTK_CONTAINER(frame), entry0);
  gtk_widget_show(entry0);

  frame = gtk_frame_new(NULL);
  gtk_frame_set_label(GTK_FRAME(frame), "CID");
  gtk_frame_set_label_align(GTK_FRAME(frame), 0.5, 0.0); 
  gtk_box_pack_start(GTK_BOX(hbox1), frame, FALSE, FALSE, 0);
  gtk_widget_show(frame);

  entry1 = gtk_entry_new(); 
  gtk_entry_set_editable(GTK_ENTRY(entry1), FALSE);
  hsize = gdk_string_width(font, conn->cid);
  hsize += gdk_string_width(font, "w"); 
  gtk_widget_set_usize(entry1, hsize, 1.6*vsize);
  gtk_entry_set_text(GTK_ENTRY(entry1), conn->cid); 
  gtk_container_add(GTK_CONTAINER(frame), entry1);
  gtk_widget_show(entry1);
}

void define_radio(GtkWidget *radiobox)
{
  GtkWidget *button;
  GSList *group;

  button = gtk_radio_button_new_with_label (NULL, "meter");
  if(mode == METER)
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON (button), TRUE); 
  gtk_signal_connect(GTK_OBJECT(button), "pressed",
      GTK_SIGNAL_FUNC(view_meter), NULL);
  gtk_box_pack_start (GTK_BOX (radiobox), button, FALSE, FALSE, 0);
  gtk_widget_show (button);

  group = gtk_radio_button_group (GTK_RADIO_BUTTON (button));
  button = gtk_radio_button_new_with_label(group, "graph"); 
  if(mode == GRAPH)
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON (button), TRUE);
  gtk_signal_connect(GTK_OBJECT(button), "pressed",
      GTK_SIGNAL_FUNC(view_graph), NULL);
  gtk_box_pack_start (GTK_BOX (radiobox), button, FALSE, FALSE, 0);
  gtk_widget_show (button); 
}

void define_smoothbutton(GtkWidget *smoothbox)
{ 
  sbutton = gtk_check_button_new_with_label("smooth");
  gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON (sbutton), TRUE);
  gtk_signal_connect(GTK_OBJECT(sbutton), "pressed",
      GTK_SIGNAL_FUNC(toggle_smooth), NULL);
  gtk_box_pack_start (GTK_BOX (smoothbox), sbutton, FALSE, FALSE, 0);
  gtk_widget_show (sbutton);
}

void new_interval(GtkAdjustment *adj, gpointer data)
{ 
  gtk_timeout_remove(update_id);
  update_interval = adj->value; 
  update_id = gtk_timeout_add( (update_interval) * 1000,
      (GtkFunction) update_vdt, NULL);
}

void define_updatescale(GtkAdjustment *adj)
{ 
  gtk_signal_connect(GTK_OBJECT(adj),"value_changed",
                     GTK_SIGNAL_FUNC(new_interval), NULL);
}

void define_infobox(GtkWidget *entry0)
{
  GtkWidget *vbox, *align, *frame, *entry;
/*   GtkWidget *button, *button2; */
/*   GSList *group; */ 
  char *itext[2] = {NULL, NULL}; 
  char *temp[1] = {NULL};
  int ii;

  vbox = gtk_vbox_new(TRUE, 0);
  gtk_box_pack_start(GTK_BOX(infobox), vbox, TRUE, TRUE, 10);
  gtk_widget_show(vbox);

  frame = gtk_frame_new(NULL);
  gtk_frame_set_label(GTK_FRAME(frame), "Variable name");
  gtk_frame_set_label_align(GTK_FRAME(frame), 0.5, 0.0); 
  gtk_box_pack_start(GTK_BOX(vbox), frame, FALSE, FALSE, 0);
  gtk_widget_show(frame);

  entry = gtk_entry_new();
  gtk_entry_set_editable(GTK_ENTRY(entry), FALSE); 
  hsize = gdk_string_width(font, wv->name);
  hsize += gdk_string_width(font, "w");
  vsize = gdk_string_height(font, wv->name);
  gtk_widget_set_usize(entry, hsize, 2*vsize);
  gtk_entry_set_text(GTK_ENTRY(entry), wv->name);
  gtk_container_add(GTK_CONTAINER(frame), entry);
  gtk_widget_show(entry);

  adj = GTK_ADJUSTMENT(gtk_adjustment_new(1.0, 0.1, 10.0, 0.1, 1, 2)); 
  updatescale=gtk_hscale_new((GtkAdjustment *) adj);
  define_updatescale(adj);
  gtk_box_pack_start(GTK_BOX(vbox), updatescale, FALSE, FALSE, 0);
  gtk_widget_show(updatescale);

  radiobox = gtk_hbox_new(FALSE, 0);
  define_radio(radiobox);
  gtk_box_pack_start(GTK_BOX(vbox), radiobox, FALSE, FALSE, 0);
  gtk_widget_show(radiobox);

  vbox = gtk_vbox_new(TRUE, 0);
  gtk_box_pack_end(GTK_BOX(infobox), vbox, TRUE, TRUE, 10);
  gtk_widget_show(vbox);

  align = gtk_alignment_new(0.5,0.5,1.0,0.0);
  gtk_box_pack_start(GTK_BOX(vbox), align, TRUE, FALSE, 5); 
  gtk_widget_show(align);

  clist = gtk_clist_new(2); 
  hsize = gdk_string_width(font, "smoothed");
  hsize += gdk_string_width(font, "w");
  gtk_clist_set_column_width(GTK_CLIST(clist), 0, hsize);
  hsize = gdk_string_width(font, "00000000");
  gtk_clist_set_column_width(GTK_CLIST(clist), 1, hsize);
  gtk_clist_set_column_justification(GTK_CLIST(clist), 0, GTK_JUSTIFY_RIGHT);
  gtk_clist_set_column_justification(GTK_CLIST(clist), 1, GTK_JUSTIFY_RIGHT);

  for(ii=0;ii<3;ii++)
    gtk_clist_append(GTK_CLIST(clist), itext);

  gtk_clist_set_text(GTK_CLIST(clist), 0, 0, "val");
  gtk_clist_set_text(GTK_CLIST(clist), 1, 0, "delta");
  gtk_clist_set_text(GTK_CLIST(clist), 2, 0, "smoothed");

  gtk_container_add(GTK_CONTAINER(align), clist);
  gtk_widget_show(clist);

  smoothbox = gtk_hbox_new(FALSE, 0);
  define_smoothbutton(smoothbox);
  gtk_box_pack_start(GTK_BOX(vbox), smoothbox, FALSE, FALSE, 2);	
  gtk_widget_show(smoothbox); 
}

void define_displaybox(GtkWidget *displaybox, int dtype)
{ 
  GtkWidget *align, *frame;
  GtkAdjustment *adjustment; 
  float what;

  frame = gtk_frame_new(NULL);   
  gtk_frame_set_shadow_type(GTK_FRAME(frame), GTK_SHADOW_IN); 
  gtk_container_add(GTK_CONTAINER(displaybox), frame);  
  gtk_widget_show(frame); 

  switch(dtype){

    case METER:
      adjustment = GTK_ADJUSTMENT(gtk_adjustment_new (0, 0.0, 1.0, 0.01, 0.1, 0));
      meter = wc_meter_new(GTK_ADJUSTMENT(adjustment)); 
      wc_meter_set_update_policy (WC_METER(meter), GTK_UPDATE_CONTINUOUS);
      gtk_container_add(GTK_CONTAINER(frame), meter);    
      gtk_widget_show(meter); 
      break;

    case GRAPH: 
      adjustment = GTK_ADJUSTMENT(gtk_adjustment_new (0, 0.0, 10.0, 0.01, 0.1, 0));
      graph = wc_graph_new(GTK_ADJUSTMENT(adjustment)); 
      wc_graph_set_update_policy (WC_GRAPH(graph), GTK_UPDATE_CONTINUOUS);
      gtk_container_add(GTK_CONTAINER(frame), graph);    
      gtk_widget_show(graph); 
      break;

    default:
      break; 
  } 
}

void markup_vdtwin(void)
{ 
  GtkWidget *vbox, *hbox, *button;
  int ii;
  char titlebar[65];


  strcpy(titlebar, "vdt@");
  strcat(titlebar, hostname);

  topwin = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_widget_ensure_style(topwin);
  if((rcstyle = gtk_rc_get_style(topwin))==NULL)
      rcstyle = gtk_widget_get_default_style();
  font = rcstyle->font;
  gtk_window_set_title (GTK_WINDOW (topwin), titlebar);
  gtk_signal_connect (GTK_OBJECT (topwin), "destroy",
                      GTK_SIGNAL_FUNC (gtk_main_quit), NULL); 
  gtk_window_set_policy(GTK_WINDOW(topwin), TRUE, TRUE, FALSE);

  vbox = gtk_vbox_new(FALSE, 0);
  gtk_container_add(GTK_CONTAINER(topwin), vbox);
  gtk_widget_show(vbox);

  sessbox = gtk_hbox_new(FALSE, 0);
  markup_session(sessbox);
  gtk_box_pack_start(GTK_BOX(vbox), sessbox, FALSE, FALSE, 5);
  gtk_widget_show(sessbox);

  infobox = gtk_hbox_new(FALSE, 0);
  define_infobox(entry0); 
  gtk_box_pack_start(GTK_BOX(vbox), infobox, FALSE, FALSE, 5);
  gtk_widget_show(infobox);

  for(ii=0;ii<2;ii++){
    displaybox[ii] = gtk_alignment_new(0.5,0.5,0.0,0.0);
    define_displaybox(displaybox[ii], ii);
    gtk_box_pack_start(GTK_BOX(vbox), displaybox[ii],
	FALSE, FALSE, 10);
  } 
  gtk_widget_show(displaybox[mode]); 

  hbox=gtk_hbox_new(FALSE, 0);
  gtk_box_pack_end(GTK_BOX(vbox), hbox, FALSE, FALSE, 5);
  gtk_widget_show(hbox);
  button = gtk_button_new_with_label(" Close ");
  gtk_box_pack_start(GTK_BOX(hbox), button, FALSE, FALSE, 3);
  gtk_widget_show(button);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(gtk_main_quit), NULL);
  mbutton = gtk_check_button_new_with_label("lower Maximum");
  gtk_signal_connect(GTK_OBJECT(mbutton), "pressed",
                     GTK_SIGNAL_FUNC(lower_max), NULL);
  gtk_box_pack_end(GTK_BOX(hbox), mbutton, FALSE, FALSE, 3);
  gtk_widget_show(mbutton);

  gtk_widget_show(topwin);
}

void data_init(void)
{
  int ii;

  val = 0; 
  ewma = oldewma = max = oldmax = 0.; 
  for(ii=0;ii<20;ii++) graphval[ii] = 0.;
}

int main(int argc, char *argv[])
{
  int option;
  valtext = malloc(40);

  gtk_init(&argc, &argv);

  if (argc < 3) {
    printf("Usage: vdt ConnectionID VarName(s) [-l(ocal)|-r(emote)]\n");
    exit(2);
  }

  option = getopt(argc, argv, "lr");

  switch(option)
  {
    case 'l':
      gtk_rc_parse("lcl.rc");
      break;
    case 'r':
      gtk_rc_parse("rmt.rc");
      break;
    default:
      gtk_rc_parse("web100.rc");
      break;
  }

   data_init();

   gethostname(hostname, (size_t) 60);

   new_vdt(argv[1], argv[2]);

   gtk_main();
}







