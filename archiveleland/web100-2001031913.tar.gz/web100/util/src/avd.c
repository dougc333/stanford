
/*
 *  Copyrights
 *
 *   All documentation and programs in this release is copyright (c)
 *   Carnegie Mellon University, The Board of Trustees of the University of
 *   Illinois, and University Corporation for Atmospheric Research, 2001.
 *   This software comes with NO WARRANTY.
 *
 *   The kernel changes and additions are also covered by the GPL version 2.
 *
 *   Since our code is currently under active development we prefer that
 *   everyone gets the it directly from us.  This will permit us to
 *   collaborate with all of the users.  So for the time being, please refer
 *   potential users to us instead of redistributing web100.
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <math.h>
#include <string.h>
#include <unistd.h>

#include <gtk/gtk.h>
#include "web100.h"
#include "web100gui.h"

#define MAXVARNAME 30

struct web100_agent *agent;
struct web100_connection *conn;
struct web100_snap *snap; 
char cid[20];
char ftuple[60];

u_int16_t val16;
u_int32_t val32;
u_int32_t del;

char varname[100][MAXVARNAME];
int varlistsize = 0;
char valtext[21];
char deltatext[21]; 
int  varnum = -1;
char optchar[3];
char hostname[60];

float update_interval = 1.0;
int update_id;

GtkWidget *defwin, *deflist, *scrollwin;
GtkObject *scrolladj;
float      scrollval=0;
GtkAdjustment *update_adj;
GtkStyle *rcstyle;
GdkFont *font;
gint hsize, vsize;

/* keep track of forked processes */
struct Plist{
  pid_t pid;
  struct Plist *next;
  struct Plist *previous;
} *pidlist = NULL;

gint update_avd(gpointer); 
void markup_defwin(void);
void markup_deflist(void);
void launch_tool(GtkWidget*, gpointer);
void close_all_windows(GtkWidget*, gpointer);

void new_avd(char *id)
{ 
  strcpy(cid, id);

  agent = web100_attach("localhost"); 
  conn = web100_find_connection(agent, cid); 
  snap = web100_get_snapshot(conn, web100_def_file); 

  markup_defwin(); 

  update_id = gtk_timeout_add(update_interval * 1000,
                              (GtkFunction) update_avd,
                              NULL); 
  update_avd(NULL); 
}

void list_vars(void)
{ 
  int ii=0;
  struct web100_var *wv;
  
  gtk_clist_freeze(GTK_CLIST(deflist)); 

  for(ii=0;ii<varlistsize;ii++) {
    wv = malloc(sizeof(struct web100_var));
    wv =  (struct web100_var *) gtk_clist_get_row_data(GTK_CLIST(deflist), ii); 

    val32 = web100_get_any32(wv, snap); 
    sprintval(valtext, wv, &val32); 

    gtk_clist_set_text(GTK_CLIST(deflist), ii, 1, valtext);

    if(wv->type == TYPE_COUNTER32) { 
      del = web100_delta_any32(wv, lastsnap, priorsnap);
      sprintval(deltatext, wv, &del);
      gtk_clist_set_text(GTK_CLIST(deflist), ii, 2, deltatext); 
    } 
  } 
  gtk_clist_thaw(GTK_CLIST(deflist));  
}

gint update_avd(gpointer data)
{
  free(priorsnap); 
  if((snap = web100_get_snapshot(conn, web100_def_file)) == NULL)
    return FALSE; 
  list_vars();  
  return TRUE; 
}

void free_avd(void)
{
  web100_free_connection(conn);
}

void *avd_quit(void)
{
  close_all_windows(NULL, NULL);
  gtk_main_quit();
}

void new_interval(GtkAdjustment *adj, gpointer data){ 

    gtk_timeout_remove(update_id);
    update_interval = update_adj->value; 
    update_id = gtk_timeout_add(update_interval*1000,
	                        (GtkFunction) update_avd, NULL);
}

void choose_var(GtkWidget *parentclist, gint row, gint column,
                GdkEventButton *event, gpointer data)
{
    varnum = row; 
}

gint signal_handler_start(GtkWidget *widget,
                          GdkEventButton *event, gpointer func_data)
{
  gchar *temp;
  struct web100_var *wv;

  if (GTK_IS_CLIST(widget) &&
      (event->type==GDK_2BUTTON_PRESS ||
       event->type==GDK_3BUTTON_PRESS) ) { 
   wv =  (struct web100_var *) gtk_clist_get_row_data(GTK_CLIST(widget), varnum); 
   launch_tool(NULL, wv->name); 
  } 
  return FALSE;
}

void row_destroy(gpointer data)
{
    free(data); 
}

void markup_session(GtkWidget *hbox)
{ 
  GtkWidget *hbox1, *frame, *entry; 
  void *val;
  int jj=0;

  if(conn->error){
    web100_perror(conn);
    return;
  }
  sprintftuple(ftuple, conn);

  hbox1 = gtk_hbox_new(FALSE, 0);
  gtk_box_pack_start(GTK_BOX(hbox), hbox1, TRUE, FALSE, 0);
  gtk_widget_show(hbox1);

  frame = gtk_frame_new(NULL);
  gtk_frame_set_label(GTK_FRAME(frame), "TCP session name");
  gtk_frame_set_label_align(GTK_FRAME(frame), 0.5, 0.0); 
  gtk_box_pack_start(GTK_BOX(hbox1), frame, FALSE, FALSE, 0);
  gtk_widget_show(frame);

  entry = gtk_entry_new(); 
  gtk_entry_set_editable(GTK_ENTRY(entry), FALSE); 
  hsize = gdk_string_width(font, ftuple);
  hsize += gdk_string_width(font, "w");
  vsize = gdk_string_height(font, ftuple);
  gtk_widget_set_usize(entry, hsize, 1.6*vsize);
  gtk_entry_set_text(GTK_ENTRY(entry), ftuple); 
  gtk_container_add(GTK_CONTAINER(frame), entry);
  gtk_widget_show(entry);

  frame = gtk_frame_new(NULL);
  gtk_frame_set_label(GTK_FRAME(frame), "CID");
  gtk_frame_set_label_align(GTK_FRAME(frame), 0.5, 0.0); 
  gtk_box_pack_start(GTK_BOX(hbox1), frame, FALSE, FALSE, 0);
  gtk_widget_show(frame);

  entry = gtk_entry_new(); 
  gtk_entry_set_editable(GTK_ENTRY(entry), FALSE);
  hsize = gdk_string_width(font, conn->cid);
  hsize += gdk_string_width(font, "w");
  gtk_widget_set_usize(entry, hsize, 1.6*vsize);
  gtk_entry_set_text(GTK_ENTRY(entry), cid); 
  gtk_container_add(GTK_CONTAINER(frame), entry);
  gtk_widget_show(entry);
}

int compar(const void *data1, const void *data2)
{ 
  while(data1 != '\0' && data2 != '\0'){ 
    return(strcmp((char *) data1++, (char *) data2++));
  }
}

void markup_deflist(void)
{ 
  struct web100_var *wv;
  gchar *titles[3] = { "Var name", "value", "delta" };
  gchar *ntext[3] = { NULL, NULL, NULL };
  gchar *temp;
  int ii=0, jj;

  deflist = gtk_clist_new_with_titles( 3, titles);
  gtk_clist_column_titles_passive(GTK_CLIST(deflist));
  gtk_clist_set_shadow_type(GTK_CLIST(deflist), GTK_SHADOW_OUT);
  gtk_clist_set_column_width(GTK_CLIST(deflist), 0, 90);
  gtk_clist_set_column_width(GTK_CLIST(deflist), 1, 80);
  gtk_clist_set_column_width(GTK_CLIST(deflist), 2, 20);

  /*
   * the next->... is a hack to avoid the first 4 vars of "/read";
   * bug in web100lib.c
   */

  for (wv=web100_def_file->first_var->next->next->next->next; wv; wv=wv->next) { 
    strcpy(varname[ii], wv->name); 
    ii++; 
  } 

  varlistsize = ii;
  qsort(varname, varlistsize, (size_t) MAXVARNAME, &compar);

  for(jj=0;jj<varlistsize;jj++) {
    wv = malloc(sizeof(struct web100_var));
    gtk_clist_insert(GTK_CLIST(deflist), jj, ntext); 
    gtk_clist_set_text(GTK_CLIST(deflist), jj, 0, varname[jj]); 
    wv = web100_find_var(conn, &varname[jj][0]);
    gtk_clist_set_row_data_full(GTK_CLIST(deflist), jj, wv,
                                (GtkDestroyNotify) row_destroy);
  }

  gtk_signal_connect(GTK_OBJECT(deflist), "select-row",
                     GTK_SIGNAL_FUNC(choose_var), NULL);
  gtk_signal_connect(GTK_OBJECT(deflist), "button_press_event",
                     GTK_SIGNAL_FUNC(signal_handler_start), NULL);

  gtk_container_add(GTK_CONTAINER(scrollwin), deflist); 

  gtk_widget_show(deflist);
}

void markup_defwin(void)
{
  GtkWidget *vbox, *hbox, *button, *updatescale;
  char titlebar[65];

  strcpy(titlebar, "avd@");
  strcat(titlebar, hostname);

  defwin = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_widget_ensure_style(defwin);
  if((rcstyle = gtk_rc_get_style(defwin))==NULL)
    rcstyle = gtk_widget_get_default_style();
  font = rcstyle->font;

  gtk_window_set_title (GTK_WINDOW (defwin), titlebar);
  gtk_signal_connect (GTK_OBJECT (defwin), "destroy",
                      GTK_SIGNAL_FUNC (avd_quit), NULL);

  gtk_window_set_policy(GTK_WINDOW(defwin), TRUE, TRUE, FALSE);
  gtk_widget_set_usize(GTK_WIDGET(defwin), 260, 300); 
  gtk_container_border_width (GTK_CONTAINER (defwin), 5);

  vbox = gtk_vbox_new(FALSE, 0);
  gtk_container_add(GTK_CONTAINER(defwin), vbox);
  gtk_widget_show(vbox);

  hbox = gtk_hbox_new(TRUE, 0);
  markup_session(hbox);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0);
  gtk_widget_show(hbox);

  scrolladj = gtk_adjustment_new(scrollval, 0, 100, 4, 20, 2); 
  scrollwin = gtk_scrolled_window_new (NULL, GTK_ADJUSTMENT(scrolladj));
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrollwin),
                                  GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS); 
  gtk_box_pack_start(GTK_BOX(vbox), scrollwin, TRUE, TRUE, 0);
  gtk_widget_show (scrollwin);

  markup_deflist();

  hbox = gtk_hbox_new(FALSE, 0);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 5);
  gtk_widget_show(hbox);

  button = gtk_button_new_with_label(" Close ");
  gtk_box_pack_start(GTK_BOX(hbox), button, FALSE, FALSE, 0);
  gtk_widget_show(button);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(avd_quit), NULL);

  update_adj = GTK_ADJUSTMENT(gtk_adjustment_new(1.0, 0.1, 10.0, 0.1, 1, 2));
  updatescale=gtk_hscale_new(GTK_ADJUSTMENT(update_adj)); 
  gtk_signal_connect(GTK_OBJECT(update_adj),"value_changed",
                     GTK_SIGNAL_FUNC(new_interval), NULL);
  gtk_box_pack_end(GTK_BOX(hbox), updatescale, TRUE, TRUE, 5);
  gtk_widget_show(updatescale);

  gtk_widget_show(defwin);
}

struct Plist *plist_prepend(struct Plist *list, pid_t pid)
{
  struct Plist *newplist;

  newplist = malloc(sizeof(struct Plist));
  newplist->pid = pid;
  newplist->next = list;
  if(list) list->previous = newplist;
  newplist->previous = NULL;
  list = newplist;
  return list;
}

struct Plist *plist_remove(struct Plist *list, pid_t pid)
{
  struct Plist *temp;

  for(temp=list; temp; temp=temp->next){
    if((int) temp->pid == (int) pid){
      if(temp->previous) temp->previous->next = temp->next;
      else list = list->next;
      if(temp->next) temp->next->previous = temp->previous;
      free(temp);
      break;
    }
  }
  return(list);
}

void plist_destroy(struct Plist *list)
{
  struct Plist *temp;

  while(!list){
    temp = list;
    list = list->next;
    free(temp);
  }
}

void sigchld_handler(int num)
{
  sigset_t set, oldset;
  pid_t pid;
  int status, exitstatus;
  struct Plist *temp;

  /* block other incoming SIGCHLD signals */
  sigemptyset(&set);
  sigaddset(&set, SIGCHLD);
  sigprocmask(SIG_BLOCK, &set, &oldset);

  /* wait for child */
  while((pid = waitpid((pid_t)-1, &status, WNOHANG)) > 0)
  { 
    /* remove process from list */
    pidlist = plist_remove(pidlist, pid);
   
    if(WIFEXITED(status))
    {
      exitstatus = WEXITSTATUS(status); 
    }
    else if(WIFSIGNALED(status))
    {
      exitstatus = WTERMSIG(status); 
    }
    else if(WIFSTOPPED(status))
    {
      exitstatus = WSTOPSIG(status); 
    }
    else
    { 
    } 
  } 
  /* re-install the signal handler (some systems need this) */
  signal(SIGCHLD, sigchld_handler);

  /* and unblock it */
  sigemptyset(&set);
  sigaddset(&set, SIGCHLD);
  sigprocmask(SIG_UNBLOCK, &set, &oldset);
}

void sigterm_handler(int num)
{
  close_all_windows(NULL, NULL);
  gtk_main_quit();
}

void close_all_windows(GtkWidget *button, gpointer window)
{
  int ii;
  struct Plist *list, *killlist=NULL;
  int pidnum=0;

  if(pidlist){
    for(list=pidlist; list; list=list->next){
      killlist = plist_prepend(killlist, list->pid);
    }
    for(list=killlist; list; list=list->next){
      kill(list->pid, SIGTERM);
    }
    plist_destroy(killlist);
  }
}

void launch_tool(GtkWidget *butt, gpointer data)
{
  pid_t pid;
  int status;

  pid = fork();
  if(pid == -1)
  {
    perror("fork");
    exit(-1);
  }
  else if(pid == 0)
  {
    if(execlp("vdt", "vdt", cid, (char *) data, optchar, 0) == -1) 
    {
      perror("exec");
      _exit(-1);
    }
  } 
  else {
    waitpid (-1, 0, WNOHANG);
    pidlist = plist_prepend(pidlist, pid);
  }
}

int main(int argc, char *argv[])
{
  char temp[3];
  int option;

  gtk_init(&argc, &argv);

  if (argc < 2) {
    printf("Usage: avd ConnectionID [-l(ocal)|-r(emote)]\n");
    exit(2);
  }
  option = getopt(argc, argv, "lr");
  strcpy(optchar, "-"); 
  switch(option)
  {
    case 'l':
      gtk_rc_parse("lcl.rc");
      sprintf(temp, "%c", option);
      strcat(optchar, temp);
      break;
    case 'r':
      gtk_rc_parse("rmt.rc");
      sprintf(temp, "%c", option);
      strcat(optchar, temp);
      break;
    default:
      gtk_rc_parse("web100.rc"); 
      break;
  }

  gethostname(hostname, (size_t) 60);

  new_avd(argv[1]);

  signal(SIGCHLD, sigchld_handler);
  signal(SIGTERM, sigterm_handler);

  gtk_main();
}
