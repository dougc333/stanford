
/*
 *  Copyrights
 *
 *   All documentation and programs in this release is copyright (c)
 *   Carnegie Mellon University, The Board of Trustees of the University of
 *   Illinois, and University Corporation for Atmospheric Research, 2001.
 *   This software comes with NO WARRANTY.
 *
 *   The kernel changes and additions are also covered by the GPL version 2.
 *
 *   Since our code is currently under active development we prefer that
 *   everyone gets the it directly from us.  This will permit us to
 *   collaborate with all of the users.  So for the time being, please refer
 *   potential users to us instead of redistributing web100.
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h> 
#include <fnmatch.h>

#include <gtk/gtk.h>

#include "web100.h" 
#include "web100gui.h"

#define WEB100_ROOT_DIR "/proc/web100/"
#define MAXVARNAME 30 

struct web100_agent *agent; 
struct web100_connection *conn;

struct session_info{
  char cid[20];
  char ftuple[60];
} *button_info = NULL;

char hostname[60];
char varname[15][MAXVARNAME];
char optchar[3];

GtkWidget *topwin, *toollist, *varlist, *vbox, *sessentry, *cidentry;
GtkWidget *errwin = NULL, *errtext;  
GtkWidget *sesswin; 
GtkStyle *rcstyle;
GdkFont *font;
gint hsize, vsize;
gint guierror;
gchar *ftuple_entry_text;
gchar *ftuple_entry[4]; 

int filter_on=0; 
int sample_interval = 1;
int varnum = -1;
int toolnum = 0;

char *text[5];

/* keep track of forked processes */
struct Plist{
  pid_t pid;
  struct Plist *next;
  struct Plist *previous;
} *pidlist = NULL;


void show_sessions(GtkWidget*, gpointer);

struct Plist *plist_prepend(struct Plist *list, pid_t pid)
{
  struct Plist *newplist;

  newplist = malloc(sizeof(struct Plist));
  newplist->pid = pid;
  newplist->next = list;
  if(list) list->previous = newplist;
  newplist->previous = NULL;
  list = newplist;
  return list;
}

struct Plist *plist_remove(struct Plist *list, pid_t pid)
{
  struct Plist *temp;

  for(temp=list; temp; temp=temp->next){
    if((int) temp->pid == (int) pid){
      if(temp->previous) temp->previous->next = temp->next;
      else list = list->next;
      if(temp->next) temp->next->previous = temp->previous;
      free(temp); 
      break;
    }
  } 
  return(list);
}

void plist_destroy(struct Plist *list)
{
  struct Plist *temp;

  while(!list){
    temp = list;
    list = list->next;
    free(temp);
  }
}

void *row_destroy(gpointer data)
{ 
  free(data); 
}

void error_window(gchar *msg)
{
  GtkWidget *entry;
  errwin = gtk_window_new(GTK_WINDOW_DIALOG); 
  gtk_window_set_position(GTK_WINDOW(errwin), GTK_WIN_POS_MOUSE); 
  errtext = gtk_label_new(msg); 
  gtk_container_add(GTK_CONTAINER(errwin), errtext); 
  gtk_widget_show(errtext);
  gtk_widget_show(errwin); 
}

void list_sessions(GtkWidget *clist)
{ 
  char *name;
  DIR *dirp;
  struct dirent *direntp; 
  struct session_info *sess; 
  int ii=0, jj;
  char temp[60]; 

  dirp = opendir( "/proc/web100" );
  if(dirp == NULL) {
    perror("can't open /proc/web100");
  } else {
    gtk_clist_freeze(GTK_CLIST(clist));
    for(;;) {
      direntp = readdir(dirp);
      if(direntp == NULL) break;
      if(direntp->d_name[0] != '.' && direntp->d_name[0] != 'h') { 
	conn = web100_find_connection(agent, direntp->d_name);
	if(conn->error){
 	  web100_perror(conn); 
	  goto next;
	}

	sprintf(text[0], "%d.%d.%d.%d",
	    (conn->ftuple->localadd) & 0xff,
	    (conn->ftuple->localadd >> 8) & 0xff,
	    (conn->ftuple->localadd >> 16) & 0xff,
	    (conn->ftuple->localadd >> 24) & 0xff); 
	sprintf(text[1], "%d", conn->ftuple->localport); 
	sprintf(text[2], "%d.%d.%d.%d",
	    (conn->ftuple->remoteadd) & 0xff,
	    (conn->ftuple->remoteadd >> 8) & 0xff,
	    (conn->ftuple->remoteadd >> 16) & 0xff,
	    (conn->ftuple->remoteadd >> 24) & 0xff); 
	sprintf(text[3], "%d", conn->ftuple->remoteport);

	if(filter_on) for(jj=0;jj<4;jj++) {
	  if(fnmatch(ftuple_entry[jj], text[jj], 0)) 
	    goto next; 
	} 

	strcpy(temp, text[0]);
	strcat(temp, ":");
	strcat(temp, text[1]);
	strcat(temp, ";");
	strcat(temp, text[2]);
	strcat(temp, ":");
	strcat(temp, text[3]);

	if((sess = malloc(sizeof(struct session_info))) == NULL){
	  fprintf(stderr, "Out of memory!\n");
	  exit(1);
	}
	strcpy(sess->cid, direntp->d_name);
	strcpy(sess->ftuple, temp);

	strcpy(text[4], sess->cid);
	gtk_clist_insert(GTK_CLIST(clist), ii, text);

	gtk_clist_set_row_data_full(GTK_CLIST(clist), ii, sess,
	    			    (GtkDestroyNotify) row_destroy); 
	ii++;
	web100_free_connection(conn);
      } 
next: 
    } 
    closedir( dirp ); 
    filter_on = 0;
    gtk_clist_thaw(GTK_CLIST(clist));	
  }
}

void print_session(void)
{
  if(button_info){
    hsize = gdk_string_width(font, button_info->ftuple);
    hsize += gdk_string_width(font, "w");
    vsize = gdk_string_height(font, button_info->ftuple);
    gtk_widget_set_usize(sessentry, hsize, 1.6*vsize);
    gtk_entry_set_text(GTK_ENTRY(sessentry), button_info->ftuple);
    hsize = gdk_string_width(font, button_info->cid);
    hsize += gdk_string_width(font, "w");
    gtk_widget_set_usize(cidentry, hsize, 1.6*vsize);
    gtk_entry_set_text(GTK_ENTRY(cidentry), button_info->cid); 
  }
}

void choose_session(GtkWidget *parentclist, gint row, gint column,
                 GdkEventAny *event, gpointer data) 
{ 
  struct session_info *sinf;

  if(errwin){ 
    gtk_widget_destroy(errwin);
    errwin = NULL;
  }
  if(button_info){
    free(button_info);
  }
  button_info = malloc(sizeof(struct session_info)); 
  sinf = gtk_clist_get_row_data(GTK_CLIST(parentclist), row); 
  strcpy(button_info->ftuple, sinf->ftuple); 
  strcpy(button_info->cid, sinf->cid); 
  print_session();
}

void choose_session_by_cid(char *cid)
{
  if(errwin){ 
    gtk_widget_destroy(errwin);
    errwin = NULL;
  }
  if(button_info){
    free(button_info); 
  }

  conn = web100_find_connection(agent, cid);
  if(conn->error){  
    web100_perror(conn);
    return;  
  } 
  button_info = malloc(sizeof(struct session_info));
  strcpy(button_info->cid, cid);
  sprintftuple(button_info->ftuple, conn);
  print_session();   
  web100_free_connection(conn);
}

void close_window(GtkWidget *button, gpointer winptr)
{ 
  gtk_widget_destroy(GTK_WIDGET(winptr)); 
}

void close_all_windows(GtkWidget *button, gpointer window)
{
  int ii;
  struct Plist *list, *killlist=NULL; 
  int pidnum=0;

  if(pidlist){
  for(list=pidlist; list; list=list->next){ 
    killlist = plist_prepend(killlist, list->pid); 
  } 
  for(list=killlist; list; list=list->next){ 
    kill(list->pid, SIGTERM); 
  } 
  plist_destroy(killlist);
  }
}

gint signal_handler_close(GtkWidget *widget,
                          GdkEventButton *event, gpointer func_data)
{
  if (GTK_IS_CLIST(widget) &&
      (event->type==GDK_2BUTTON_PRESS ||
       event->type==GDK_3BUTTON_PRESS) ) { 
   close_window(NULL, func_data); 
  } 
  return FALSE;
}

void sessentry_callback(GtkWidget *widget, gpointer data)
{ 
  int ii;

  filter_on = 1;
  ftuple_entry_text = gtk_entry_get_text(GTK_ENTRY(widget));
  sscanf(ftuple_entry_text, "%[^:]%*[:]%[^;]%*[;]%[^:]%*[:]%s",
         ftuple_entry[0], ftuple_entry[1], ftuple_entry[2], ftuple_entry[3]); 
  show_sessions(NULL, NULL);
}

void cidentry_callback(GtkWidget *widget, gpointer data)
{
  char *cid;

  cid = gtk_entry_get_text(GTK_ENTRY(widget));
  choose_session_by_cid(cid); 
}

void show_sessions(GtkWidget *button, gpointer data)
{ 
  GtkWidget *vbox, *scrolled, *slist, *hbox, *cbutton;
  gchar *titles[5] = { "Local-IP", "Port",
                       "Remote-IP", "Port", "CID" }; 
  gint asize, bsize;
  char titlebar[65];

   if(GTK_IS_WIDGET(sesswin)){
     close_window(NULL, sesswin); 
   } 
  
  strcpy(titlebar, "TCP session@");
  strcat(titlebar, hostname);

  asize = gdk_string_width(font, "555.555.555.555W");
  bsize = gdk_string_width(font, "55555W");
  hsize = 2*asize + 5*bsize;

  sesswin = gtk_window_new(GTK_WINDOW_TOPLEVEL); 
  gtk_window_set_policy(GTK_WINDOW(sesswin), TRUE, TRUE, FALSE);

  gtk_window_set_title (GTK_WINDOW (sesswin), titlebar);
  gtk_widget_set_usize(GTK_WIDGET(sesswin), hsize, 400);
  vbox = gtk_vbox_new(FALSE, 0);
  gtk_container_add(GTK_CONTAINER(sesswin), vbox);
  gtk_widget_show(vbox);

  scrolled = gtk_scrolled_window_new(NULL, NULL);

  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled),
      GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS); 
  gtk_box_pack_start(GTK_BOX(vbox), scrolled, TRUE, TRUE, 0);
  gtk_widget_show(scrolled);

  slist = gtk_clist_new_with_titles(5, titles); 
  gtk_clist_set_column_width(GTK_CLIST(slist), 0, asize);
  gtk_clist_set_column_width(GTK_CLIST(slist), 1, bsize);
  gtk_clist_set_column_width(GTK_CLIST(slist), 2, asize);
  gtk_clist_set_column_width(GTK_CLIST(slist), 3, bsize); 
  gtk_clist_set_column_width(GTK_CLIST(slist), 4, bsize);  
  gtk_clist_set_shadow_type(GTK_CLIST(slist), GTK_SHADOW_OUT);

  gtk_signal_connect(GTK_OBJECT(slist), "select-row",
                     GTK_SIGNAL_FUNC(choose_session), NULL);
  gtk_signal_connect(GTK_OBJECT(slist), "button_press_event",
                     GTK_SIGNAL_FUNC(signal_handler_close), sesswin);

  gtk_container_add(GTK_CONTAINER(scrolled), slist);

  list_sessions(slist); 

  gtk_widget_show(slist);

  hbox = gtk_hbox_new(FALSE, 0);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0);
  gtk_widget_show(hbox); 
  cbutton = gtk_button_new_with_label("Close");

  gtk_signal_connect(GTK_OBJECT(cbutton), "clicked",
                     GTK_SIGNAL_FUNC(close_window), sesswin);
  gtk_box_pack_start(GTK_BOX(hbox), cbutton, TRUE, FALSE, 0);
  gtk_widget_show(cbutton);

  gtk_widget_show(sesswin);  
}


void sigchld_handler(int num)
{
  sigset_t set, oldset;
  pid_t pid;
  int status, exitstatus;
  struct Plist *temp;

  /* block other incoming SIGCHLD signals */
  sigemptyset(&set);
  sigaddset(&set, SIGCHLD);
  sigprocmask(SIG_BLOCK, &set, &oldset);

  /* wait for child */
  while((pid = waitpid((pid_t)-1, &status, WNOHANG)) > 0)
  { 
    /* remove process from list */
    pidlist = plist_remove(pidlist, pid);
   
    if(WIFEXITED(status))
    {
      exitstatus = WEXITSTATUS(status); 
    }
    else if(WIFSIGNALED(status))
    {
      exitstatus = WTERMSIG(status); 
    }
    else if(WIFSTOPPED(status))
    {
      exitstatus = WSTOPSIG(status); 
    }
    else
    { 
    } 
  } 
  /* re-install the signal handler (some systems need this) */
  signal(SIGCHLD, sigchld_handler);

  /* and unblock it */
  sigemptyset(&set);
  sigaddset(&set, SIGCHLD);
  sigprocmask(SIG_UNBLOCK, &set, &oldset);
}

void launch_tool(GtkWidget *butt, gpointer data)
{
  pid_t pid; 
  int status;

  if(errwin){ 
    gtk_widget_destroy(errwin);
    errwin = NULL;
  }
  if(!button_info){
    error_window("Please choose a TCP session"); return;
  }
  if((toolnum == 0) && (varnum == -1)) {
    error_window("Please choose a variable"); return;
  }
  pid = fork();

  if(pid == -1)
  {
    perror("fork");
    exit(-1);
  }
  else if(pid == 0)
  { 
    switch (toolnum) {
      case 0:  
	if(varnum == -1) {
	  guierror = 1;
	  fprintf(stderr, "Please choose a variable\n");
	  _exit(-1);
	}
	else {
	  if(execlp("vdt", "vdt", button_info->cid, varname[varnum], optchar, 0) == -1)
	  { 
	    perror("exec");
	    _exit(-1);
	  }
	}
	break;
      case 1: 
	if(execlp("avd", "avd", button_info->cid, optchar, 0) == -1)
	{
	  perror("exec"); 
	  _exit(-1);
	}
	break;
      case 2:
	if(execlp("cpr", "cpr", button_info->cid, optchar, 0) == -1)
	{
	  perror("exec");
	  _exit(-1);
	}
	break;
      case 3:
	if(execlp("triage", "triage", button_info->cid, optchar, 0) == -1)
	{
	  perror("exec");
	  _exit(-1);
	}
	break;
      case 4: 
	if(execlp("stuner", "stuner", button_info->cid, optchar, 0) == -1)
        {
	  perror("exec"); 
          _exit(-1);
        }
	break;
      case 5: 
        if(execlp("rtuner", "rtuner", button_info->cid, optchar, 0) == -1)
        {
          perror("exec");
          _exit(-1);
        } 
        break;
      default:
	_exit(0);
	break;
    } 
  } 
  else {
    waitpid (-1, 0, WNOHANG);   
    pidlist = plist_prepend(pidlist, pid); 
  } 
}

void choose_tool(GtkWidget *parentclist, gint row, gint column,
		GdkEventButton *event, gpointer data)
{
  toolnum = row; 
}

void choose_var(GtkWidget *parentclist, gint row, gint column,
                GdkEventButton *event, gpointer data)
{
  varnum = row;
}

gint signal_handler_start(GtkWidget *widget,
                          GdkEventButton *event, gpointer func_data)
{
  if (GTK_IS_CLIST(widget) &&
      (event->type==GDK_2BUTTON_PRESS ||
      event->type==GDK_3BUTTON_PRESS) ) { 
    launch_tool(NULL, NULL);
  } 
  return FALSE;
}

gint signal_handler_startvar(GtkWidget *widget,
                          GdkEventButton *event, gpointer func_data)
{
  if (GTK_IS_CLIST(widget) &&
      (event->type==GDK_2BUTTON_PRESS ||
       event->type==GDK_3BUTTON_PRESS) ) {
    gtk_clist_select_row(GTK_CLIST(toollist), 0, 0); 
    launch_tool(NULL, NULL);
  }
  return FALSE;
} 

void markup_session(void)
{
  GtkWidget *button, *frame, *frame1;
  GtkWidget *hbox, *hbox1, *label;

  hbox = gtk_hbox_new(FALSE, 0); 
  gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 10);
  gtk_widget_show(hbox);

  hbox1 = gtk_hbox_new(FALSE, 0);
  gtk_box_pack_start(GTK_BOX(hbox), hbox1, TRUE, FALSE, 0); 
  gtk_widget_show(hbox1);

  frame = gtk_frame_new(NULL);
  gtk_frame_set_label(GTK_FRAME(frame), "TCP session name");
  gtk_frame_set_label_align(GTK_FRAME(frame), 0.5, 0.0);
  gtk_box_pack_start(GTK_BOX(hbox1), frame, FALSE, FALSE, 0);
  gtk_widget_show(frame);

  sessentry = gtk_entry_new(); 
  gtk_widget_set_usize(sessentry, 150, 20);
  gtk_signal_connect(GTK_OBJECT(sessentry), "activate",
                     GTK_SIGNAL_FUNC(sessentry_callback), NULL);
  gtk_container_add(GTK_CONTAINER(frame), sessentry);
  gtk_widget_show(sessentry);

  frame = gtk_frame_new(NULL);
  gtk_frame_set_label(GTK_FRAME(frame), "CID");
  gtk_frame_set_label_align(GTK_FRAME(frame), 0.5, 0.0);
  gtk_box_pack_start(GTK_BOX(hbox1), frame, FALSE, FALSE, 0);
  gtk_widget_show(frame);

  cidentry = gtk_entry_new();
  gtk_widget_set_usize(cidentry, 30, 20);
  gtk_signal_connect(GTK_OBJECT(cidentry), "activate",
                     GTK_SIGNAL_FUNC(cidentry_callback), NULL);
  gtk_container_add(GTK_CONTAINER(frame), cidentry); 
  gtk_widget_show(cidentry); 
}

void markup_tools(GtkWidget *clist)
{
  char *mtext[1];

  if((mtext[0] = malloc(40)) == NULL){ 
    fprintf(stderr, "Out of memory!\n");
    exit(1);
  }

  hsize = gdk_string_width(font, "One counter/gauge display");
  hsize += gdk_string_width(font, "w");
  gtk_clist_set_column_width(GTK_CLIST(clist), 0, hsize);
  gtk_clist_set_column_justification(GTK_CLIST(clist), 0, GTK_JUSTIFY_CENTER);

  strcpy(mtext[0], "One counter/gauge display");
  gtk_clist_append(GTK_CLIST(clist), mtext); 
  strcpy(mtext[0], "All variable display");
  gtk_clist_append(GTK_CLIST(clist), mtext);
  strcpy(mtext[0], "Connection properties");
  gtk_clist_append(GTK_CLIST(clist), mtext);
  strcpy(mtext[0], "Congestion pie chart");
  gtk_clist_append(GTK_CLIST(clist), mtext);
  strcpy(mtext[0], "Send tuning controls");
  gtk_clist_append(GTK_CLIST(clist), mtext);
  strcpy(mtext[0], "Receive tuning controls");
  gtk_clist_append(GTK_CLIST(clist), mtext);

  gtk_signal_connect(GTK_OBJECT(clist), "select-row", 
                     GTK_SIGNAL_FUNC(choose_tool), NULL); 
  gtk_signal_connect(GTK_OBJECT(clist),
      "button_press_event",
      GTK_SIGNAL_FUNC(signal_handler_start),
      NULL);
}

void markup_vars(GtkWidget *clist)
{
  char *mtext[1];

  if((mtext[0] = malloc(40)) == NULL){ 
    fprintf(stderr, "Out of memory!\n");
    exit(1);
  }

  hsize = gdk_string_width(font, "Total Packets Transmitted");
  hsize += gdk_string_width(font, "w");
  gtk_clist_set_column_width(GTK_CLIST(clist), 0, hsize);
  gtk_clist_set_column_justification(GTK_CLIST(clist), 0, GTK_JUSTIFY_CENTER);

  strcpy(mtext[0], "Total Packets Received");
  gtk_clist_append(GTK_CLIST(clist), mtext);
  strcpy(mtext[0], "Data Packets Received");
  gtk_clist_append(GTK_CLIST(clist), mtext);
  strcpy(mtext[0], "Ack Packets Received");
  gtk_clist_append(GTK_CLIST(clist), mtext);
  strcpy(mtext[0], "Data Bytes Received");
  gtk_clist_append(GTK_CLIST(clist), mtext);
  strcpy(mtext[0], "Total Packets Transmitted");
  gtk_clist_append(GTK_CLIST(clist), mtext);
  strcpy(mtext[0], "Data Packets Transmitted");
  gtk_clist_append(GTK_CLIST(clist), mtext); 
  strcpy(mtext[0], "Ack Packets Transmitted");
  gtk_clist_append(GTK_CLIST(clist), mtext);
  strcpy(mtext[0], "Data Bytes Transmitted");
  gtk_clist_append(GTK_CLIST(clist), mtext);
  strcpy(mtext[0], "Packets Retransmitted");
  gtk_clist_append(GTK_CLIST(clist), mtext);
  strcpy(mtext[0], "Bytes Retransmitted");
  gtk_clist_append(GTK_CLIST(clist), mtext);
  strcpy(mtext[0], "Duplicate Acks Received");
  gtk_clist_append(GTK_CLIST(clist), mtext);
  strcpy(mtext[0], "CurrentCwnd");
  gtk_clist_append(GTK_CLIST(clist), mtext);
  strcpy(mtext[0], "CurrentSsthresh");
  gtk_clist_append(GTK_CLIST(clist), mtext); 
  strcpy(mtext[0], "SmoothedRTT");
  gtk_clist_append(GTK_CLIST(clist), mtext);
  strcpy(mtext[0], "CurrentRTO");
  gtk_clist_append(GTK_CLIST(clist), mtext);

  gtk_signal_connect(GTK_OBJECT(clist), "select-row",
                     GTK_SIGNAL_FUNC(choose_var), NULL);
  gtk_signal_connect(GTK_OBJECT(clist),
      "button_press_event",
      GTK_SIGNAL_FUNC(signal_handler_startvar),
      NULL);
}


void markup_dtb()
{ 
  GtkWidget *hbox, *button, *align, *frame;
  char titlebar[65];

  strcpy(titlebar, "dtb@"); 
  strcat(titlebar, hostname);

  topwin = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_widget_ensure_style(topwin);
  if((rcstyle = gtk_rc_get_style(topwin))==NULL)
    rcstyle = gtk_widget_get_default_style();
  font = rcstyle->font;

  gtk_window_set_title (GTK_WINDOW (topwin), titlebar); 
  gtk_window_set_policy(GTK_WINDOW(topwin), TRUE, TRUE, FALSE);
  gtk_signal_connect (GTK_OBJECT (topwin), "destroy",
                      GTK_SIGNAL_FUNC (gtk_main_quit), NULL); 

  vbox = gtk_vbox_new(FALSE, 0);
  gtk_container_add(GTK_CONTAINER(topwin), vbox);
  gtk_widget_show(vbox); 

  markup_session();
 
  hbox = gtk_hbox_new(FALSE, 0); 
  button = gtk_button_new_with_label("Select TCP session");
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
      GTK_SIGNAL_FUNC(show_sessions), NULL); 
  gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, FALSE, 0);
  gtk_widget_show(button); 
  gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0);
  gtk_widget_show(hbox);

  hbox = gtk_hbox_new(FALSE, 0);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 10);
  gtk_widget_show(hbox);

  align = gtk_alignment_new(0.2,0.5,0.0,0.0);
  gtk_box_pack_start(GTK_BOX(hbox), align, FALSE, FALSE, 10);
  gtk_widget_show(align);
  frame = gtk_frame_new("Tool box");
  gtk_frame_set_label_align(GTK_FRAME(frame), 0.5, 0.0);
  gtk_container_add(GTK_CONTAINER(align), frame);
  gtk_widget_show(frame);
  toollist = gtk_clist_new(1);

  markup_tools(toollist);

  gtk_container_add(GTK_CONTAINER(frame),  toollist);
  gtk_widget_show(toollist);

  align = gtk_alignment_new(0.7,0.5,0.0,0.0);
  gtk_box_pack_end(GTK_BOX(hbox), align, FALSE, FALSE, 10);
  gtk_widget_show(align);
  frame = gtk_frame_new("Counter/gauge");
  gtk_frame_set_label_align(GTK_FRAME(frame), 0.5, 0.0);
  gtk_container_add(GTK_CONTAINER(align), frame);
  gtk_widget_show(frame);
  varlist = gtk_clist_new(1);

  markup_vars(varlist);

  gtk_container_add(GTK_CONTAINER(frame),  varlist);
  gtk_widget_show(varlist);

  hbox = gtk_hbox_new(FALSE, 0);

  button = gtk_button_new_with_label(" Open window "); 
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(launch_tool), NULL);
  gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, FALSE, 0);
  gtk_widget_show(button);

  button = gtk_button_new_with_label(" Close dtb " );
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(gtk_main_quit), NULL);
  gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, FALSE, 0);
  gtk_widget_show(button);

  button = gtk_button_new_with_label(" Close all other");
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(close_all_windows), NULL);
  gtk_box_pack_start(GTK_BOX(hbox), button, TRUE, FALSE, 0);
  gtk_widget_show(button);

  gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 10);
  gtk_widget_show(hbox);

  gtk_widget_show(topwin);
}

void data_init(void)
{
  int ii;

  strcpy(varname[0], "PktsIn");
  strcpy(varname[1], "DataPktsIn");
  strcpy(varname[2], "AckPktsIn");
  strcpy(varname[3], "DataBytesIn");
  strcpy(varname[4], "PktsOut");
  strcpy(varname[5], "DataPktsOut");
  strcpy(varname[6], "AckPktsOut");
  strcpy(varname[7], "DataBytesOut");
  strcpy(varname[8], "PktsRetrans");
  strcpy(varname[9], "BytesRetrans");
  strcpy(varname[10], "DupAcksIn");
  strcpy(varname[11], "CurrentCwnd");
  strcpy(varname[12], "CurrentSsthresh");
  strcpy(varname[13], "SmoothedRTT");
  strcpy(varname[14], "CurrentRTO"); 

  for(ii=0;ii<5;ii++) if((text[ii] = malloc(60))==NULL){
    fprintf(stderr, "Out of memory!\n");
    exit(1);
  }
  for(ii=0;ii<4;ii++) if((ftuple_entry[ii] = malloc(60))==NULL){
    fprintf(stderr, "Out of memory!\n");
    exit(1);
  }
}

int main(int argc, char *argv[])
{ 
  char cid[MAXCNAME]; 
  struct web100_var *wv; 
  char temp[60];
  int option; 

  gtk_init(&argc, &argv); 

  data_init();

  gethostname(hostname, (size_t) 60);

  agent = web100_attach("localhost");

  option = getopt(argc, argv, "lr");

  strcpy(optchar, "-");
  switch(option)
  {
    case 'l':
      gtk_rc_parse("lcl.rc"); 
      sprintf(temp, "%c", option);
      strcat(optchar, temp);
      break;
    case 'r':
      gtk_rc_parse("rmt.rc"); 
      sprintf(temp, "%c", option);
      strcat(optchar, temp);
      break;
    default:
      gtk_rc_parse("web100.rc"); 
      break;
  }

  markup_dtb(); 

  if(argc > 3){
    fprintf(stderr, "Usage: dtb [cid] [-l(ocal)|-r(emote)]\n");
    exit(1);
  }else{ 
    if(argc >= 2 && argv[1][0] != '-'){ 
       choose_session_by_cid(argv[1]);   
    }
  }

  signal(SIGCHLD, sigchld_handler); 

  gtk_main();
}

