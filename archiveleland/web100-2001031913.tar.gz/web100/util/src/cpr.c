
/*
 *  Copyrights
 *
 *   All documentation and programs in this release is copyright (c)
 *   Carnegie Mellon University, The Board of Trustees of the University of
 *   Illinois, and University Corporation for Atmospheric Research, 2001.
 *   This software comes with NO WARRANTY.
 *
 *   The kernel changes and additions are also covered by the GPL version 2.
 *
 *   Since our code is currently under active development we prefer that
 *   everyone gets the it directly from us.  This will permit us to
 *   collaborate with all of the users.  So for the time being, please refer
 *   potential users to us instead of redistributing web100.
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <math.h>
#include <string.h>
#include <unistd.h>

#include <gtk/gtk.h>
#include "web100.h"
#include "web100gui.h"

#define MAXVARNAME 30

struct web100_agent *agent;
struct web100_connection *conn;
struct web100_var *wv; 
char cid[20];
char ftuple[60];


u_int32_t val;

char varname[9][MAXVARNAME];   
char valtext[21];
int update_id;

GtkWidget *cprwin, *cprlist; 
GtkWidget *scrollwin;
GtkObject *scrolladj;
float      scrollval=0;
GtkStyle *rcstyle;
GdkFont *font;
gint hsize, vsize;

gint update_cpr(gpointer);

void markup_cprwin(void);
void markup_cprlist(void);

void new_cpr(char *id)
{ 
  strcpy(cid, id);
  if((wv = malloc(sizeof(struct web100_var)))==NULL){
    fprintf(stderr, "Out of memory!\n");
    exit(1);
  }
  agent = web100_attach("localhost");
  conn = web100_find_connection(agent, cid);

  markup_cprwin(); 
}

void list_vars(void)
{ 
  int ii;
  
  gtk_clist_freeze(GTK_CLIST(cprlist)); 

  for(ii=0;ii<9;ii++) {
    wv = web100_find_var(conn, varname[ii]);
    val = web100_raw_get_any32(conn, wv);
    if(conn->error) return;
    sprintval(valtext, wv, &val);
    gtk_clist_set_text(GTK_CLIST(cprlist), ii, 1, valtext); 
  }

  gtk_clist_thaw(GTK_CLIST(cprlist));  
}

gint update_cpr(gpointer data)
{
  list_vars();  
  return TRUE;
}

void free_cpr(void)
{
  free(wv);
  web100_free_connection(conn);
  gtk_main_quit;
}

void markup_session(GtkWidget *hbox)
{ 
  GtkWidget *hbox1, *frame, *entry; 
  void *val;
  int jj=0;

  if(conn->error){
    web100_perror(conn);
    return;
  }
  sprintftuple(ftuple, conn);

  hbox1 = gtk_hbox_new(FALSE, 0);
  gtk_box_pack_start(GTK_BOX(hbox), hbox1, TRUE, FALSE, 0);
  gtk_widget_show(hbox1);

  frame = gtk_frame_new(NULL);
  gtk_frame_set_label(GTK_FRAME(frame), "TCP session name");
  gtk_frame_set_label_align(GTK_FRAME(frame), 0.5, 0.0); 
  gtk_box_pack_start(GTK_BOX(hbox1), frame, FALSE, FALSE, 0);
  gtk_widget_show(frame);

  entry = gtk_entry_new(); 
  gtk_entry_set_editable(GTK_ENTRY(entry), FALSE); 
  hsize = gdk_string_width(font, ftuple);
  hsize += gdk_string_width(font, "w");
  vsize = gdk_string_height(font, ftuple);
  gtk_widget_set_usize(entry, hsize, 1.6*vsize);
  gtk_entry_set_text(GTK_ENTRY(entry), ftuple); 
  gtk_container_add(GTK_CONTAINER(frame), entry);
  gtk_widget_show(entry);

  frame = gtk_frame_new(NULL);
  gtk_frame_set_label(GTK_FRAME(frame), "CID");
  gtk_frame_set_label_align(GTK_FRAME(frame), 0.5, 0.0); 
  gtk_box_pack_start(GTK_BOX(hbox1), frame, FALSE, FALSE, 0);
  gtk_widget_show(frame);

  entry = gtk_entry_new(); 
  gtk_entry_set_editable(GTK_ENTRY(entry), FALSE);
  hsize = gdk_string_width(font, conn->cid);
  hsize += gdk_string_width(font, "w");
  gtk_widget_set_usize(entry, hsize, 1.6*vsize);
  gtk_entry_set_text(GTK_ENTRY(entry), cid); 
  gtk_container_add(GTK_CONTAINER(frame), entry);
  gtk_widget_show(entry);
}

void markup_cprlist(void)
{ 
  gchar *titles[2] = { "Var name", "value" };
  gchar *ntext[3] = { NULL, NULL, NULL };
  int ii;

  cprlist = gtk_clist_new_with_titles( 2, titles);
  gtk_clist_column_titles_passive(GTK_CLIST(cprlist));
  gtk_clist_set_shadow_type(GTK_CLIST(cprlist), GTK_SHADOW_OUT);
  gtk_clist_set_column_width(GTK_CLIST(cprlist), 0, 100);
  gtk_clist_set_column_width(GTK_CLIST(cprlist), 1, 40);

  for(ii=0;ii<9;ii++) { 
    gtk_clist_insert(GTK_CLIST(cprlist), ii, ntext);
    gtk_clist_set_text(GTK_CLIST(cprlist), ii, 0, varname[ii]);
  }

  gtk_container_add(GTK_CONTAINER(scrollwin), cprlist);

  list_vars();

  gtk_widget_show(cprlist);
}

void markup_cprwin(void)
{
  GtkWidget *vbox, *hbox, *button;

  cprwin = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_widget_ensure_style(cprwin);
  if((rcstyle = gtk_rc_get_style(cprwin))==NULL)
    rcstyle = gtk_widget_get_default_style();
  font = rcstyle->font;

  gtk_window_set_title (GTK_WINDOW (cprwin), "connection properties");
  gtk_signal_connect (GTK_OBJECT (cprwin), "destroy",
                      GTK_SIGNAL_FUNC (free_cpr), NULL);

  gtk_window_set_policy(GTK_WINDOW(cprwin), TRUE, TRUE, FALSE);
  gtk_widget_set_usize(GTK_WIDGET(cprwin), 200, 250); 
  gtk_container_border_width (GTK_CONTAINER (cprwin), 5);

  vbox = gtk_vbox_new(FALSE, 0);
  gtk_container_add(GTK_CONTAINER(cprwin), vbox);
  gtk_widget_show(vbox);

  hbox = gtk_hbox_new(TRUE, 0);
  markup_session(hbox); 
  gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0); 
  gtk_widget_show(hbox); 

  scrolladj = gtk_adjustment_new(scrollval, 0, 100, 4, 20, 2); 
  scrollwin = gtk_scrolled_window_new (NULL, GTK_ADJUSTMENT(scrolladj));
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrollwin),
                                  GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS); 
  gtk_box_pack_start(GTK_BOX(vbox), scrollwin, TRUE, TRUE, 0);
  gtk_widget_show(scrollwin); 

  markup_cprlist();

  hbox = gtk_hbox_new(FALSE, 0);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 5);
  gtk_widget_show(hbox);

  button = gtk_button_new_with_label(" Close ");
  gtk_box_pack_start(GTK_BOX(hbox), button, FALSE, FALSE, 0);
  gtk_widget_show(button);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(gtk_main_quit), NULL);

  button = gtk_button_new_with_label(" Update ");
  gtk_box_pack_end(GTK_BOX(hbox), button, FALSE, FALSE, 0);
  gtk_widget_show(button);
  gtk_signal_connect(GTK_OBJECT(button), "clicked",
                     GTK_SIGNAL_FUNC(update_cpr), NULL);

  gtk_widget_show(cprwin);
}

int main(int argc, char *argv[])
{
  int option;

  gtk_init(&argc, &argv);

  if (argc < 2) {
    printf("Usage: cpr ConnectionID\n");
    exit(2);
  }

  option = getopt(argc, argv, "lr");

  switch(option)
  {
    case 'l':
      gtk_rc_parse("lcl.rc");
      break;
    case 'r':
      gtk_rc_parse("rmt.rc");
      break;
    default:
      gtk_rc_parse("web100.rc");
      break;
  }

  strcpy(varname[0], "State");
  strcpy(varname[1], "SACKEnabled");
  strcpy(varname[2], "TimestampsEnabled");
  strcpy(varname[3], "CurrentMSS");
  strcpy(varname[4], "MaxMSS");
  strcpy(varname[5], "MinMSS");
  strcpy(varname[6], "WinScaleRcvd");
  strcpy(varname[7], "WinScaleSent");
  strcpy(varname[8], "NagleEnabled");

  new_cpr(argv[1]);

  gtk_main();

  return 0;
} 



