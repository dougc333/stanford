
/*
 *  Copyrights
 *
 *   All documentation and programs in this release is copyright (c)
 *   Carnegie Mellon University, The Board of Trustees of the University of
 *   Illinois, and University Corporation for Atmospheric Research, 2001.
 *   This software comes with NO WARRANTY.
 *
 *   The kernel changes and additions are also covered by the GPL version 2.
 *
 *   Since our code is currently under active development we prefer that
 *   everyone gets the it directly from us.  This will permit us to
 *   collaborate with all of the users.  So for the time being, please refer
 *   potential users to us instead of redistributing web100.
 */

void sprintval(char *text, struct web100_var *wv, void *val)
{
  switch (wv->type) { 
    case TYPE_IP_ADDRESS:
      sprintf(text, "%d.%d.%d.%d",
	  (*(u_int32_t *) val) & 0xff,
	  (*(u_int32_t *) val >> 8) & 0xff,
	  (*(u_int32_t *) val >> 16) & 0xff,
	  (*(u_int32_t *) val >> 24) & 0xff);
      break;
    case TYPE_UNSIGNED16:
      sprintf(text, "%u", *(u_int16_t *) val);
    case TYPE_COUNTER64:
      sprintf(text, "%u", *(u_int64_t *) val);
    default:
      sprintf(text, "%u", *(u_int32_t *) val);
      break;
  }
}

sprintftuple(char *text, struct web100_connection *conn)
{ 
  char temp[4][60];

  sprintf(temp[0], "%d.%d.%d.%d",
      (conn->ftuple->localadd) & 0xff,
      (conn->ftuple->localadd >> 8) & 0xff,
      (conn->ftuple->localadd >> 16) & 0xff,
      (conn->ftuple->localadd >> 24) & 0xff);

  sprintf(temp[1], "%d", conn->ftuple->localport);

  sprintf(temp[2], "%d.%d.%d.%d",
      (conn->ftuple->remoteadd) & 0xff,
      (conn->ftuple->remoteadd >> 8) & 0xff,
      (conn->ftuple->remoteadd >> 16) & 0xff,
      (conn->ftuple->remoteadd >> 24) & 0xff);

  sprintf(temp[3], "%d", conn->ftuple->remoteport);

  strcpy(text, temp[0]);
  strcat(text, ":");
  strcat(text, temp[1]);
  strcat(text, ";");
  strcat(text, temp[2]);
  strcat(text, ":");
  strcat(text, temp[3]); 
}
