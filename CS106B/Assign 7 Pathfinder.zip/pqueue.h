/*
 * File: pqueue.h
 * Last modified on Wed May  3 22:46:08 PDT 2000 by jzelenski
 * ----------------------------------------------------------
 * Defines an abstraction for the priority queue ADT.  This queue is not
 * simple FIFO queue, it is a priority queue, where elements are
 * retrieved in order of priority, not just by longevity in queue.
 * The type is exported as an "abstract data type," defined conceptually 
 * only by the operations  on that type. Clients should not make any 
 * assumptions about the underlying representation.
 */
 
 
#ifndef _pqueue_h
#define _pqueue_h

#include "genlib.h"

#ifdef __MWERKS__
#include "macqueue.h"/* Used to avoid MacOS conflicts */
#endif

/*
 * Type: pqueueADT
 * ---------------
 * This is the abstract type for a priority queue.  The type definition
 * below is "incomplete".  Clients know that pqueueADT is a pointer to
 * a struct tagged "pqueueCDT" but that's it.  No details of the size,
 * field names, and types of the structure are visible to the client since
 * we want to keep them on their side of the wall!
 */
typedef struct pqueueCDT *pqueueADT;



/* 
 * Type: cmpFn
 * -----------
 * Defines the protoype for the comparison function used to compare
 * two void * elements in the priority queue to determine their relative
 * priority. Given two elements, a comparison function should return a
 * negative number to indicate the first is lower priority than the second,
 * 0 to say they are equal priority, and positive to indicate first is
 * higher priority.
 */
typedef int (*cmpFn)(void *, void *);



/*
 * Function: NewPQueue
 * Usage: queue = NewPQueue(CompareWeights);
 * -----------------------------------------
 * Returns a new empty pqueueADT with no elements.  The comparison function 
 * will be applied to elements while enqueueing/deuqueing to be sure the
 * element that is higher priority is dequeued first.
 */
pqueueADT NewPQueue(cmpFn cmp);


/*
 * Function: FreeQueue
 * Usage: FreeQueue(queue);
 * ------------------------
 * Frees all the storage associated with the queue.
 */
void FreePQueue(pqueueADT queue);



/*
 * Function: PQueueIsEmpty
 * Usage: if (PQueueIsEmpty(queue)) . . .
 * --------------------------------------
 * Returns TRUE if queue has no entries.
 */
bool PQueueIsEmpty(pqueueADT queue);


/*
 * Function: PQueueIsFull
 * Usage: if (PQueueIsFull(queue)) . . .
 * --------------------------------------
 * Returns TRUE if queue has no more room for entries.  Clients can use
 * this to check if any further Enqueue operation will overflow the
 * ability of the queue to handle it. Some versions of the pqueue may 
 * never return TRUE if they can always accommodate more entries.
 */
bool PQueueIsFull(pqueueADT queue);


/*
 * Function: Enqueue
 * Usage: Enqueue(queue, newElem);
 * ------------------------------
 * Adds the specified void *element to the queue. No effort is made to
 * avoid duplicates.  If the queue is full, this function raises an error.
 */
void Enqueue(pqueueADT queue, void *newElem);


/*
 * Function: DequeueMax
 * Usage: maxElem = DequeueMax(queue);
 * -----------------------------------
 * Removes the largest priority element from the queue (according to the
 * comparator function supplied when creating this queue) and returns it.
 * If there is more than one element of equal high priority, the first
 * element enqueued with that priority is the one dequeued.
 * If the queue is empty, this function raises an error.
 */
void *DequeueMax(pqueueADT queue);


#endif