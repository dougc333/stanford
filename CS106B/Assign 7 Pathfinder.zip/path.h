/*
 * File: path.h
 * ------------
 * This interface defines an abstraction for paths consisting
 * of a sequence of arcs.
 */

#ifndef _path_h
#define _path_h

#include "graph.h"

/*
 * Type: pathADT
 * -------------
 * This type is the abstract type representing a path.  
 */

typedef struct pathCDT *pathADT;

/*
 * Type: distanceFnT
 * -----------------
 * This type defines the space of functions that can be used to
 * determine the distance (or, more generally, the cost according
 * to some metric) of a individual arc.  Such functions take an
 * arc and return a double representing the contribution of that
 * arc to the total path distance.
 */

typedef double (*distanceFnT)(arcADT arc);

/*
 * Type: arcMappingFnT
 * -------------------
 * This type defines the space of functions that can be used to
 * map over the list of arcs in order from the first to the last.
 * Each function is called with an arc and a client data pointer
 * passed in from the caller.
 */

typedef void (*arcMappingFnT)(arcADT arc, void *clientData);

/*
 * Function: NewPath
 * Usage: path = NewPath(distanceFn);
 * ----------------------------------
 * This function creates a new empty path.  The distanceFn
 * parameter is used to compute the total path distance.
 */

pathADT NewPath(distanceFnT distanceFn);

/*
 * Function: CopyPath
 * Usage: copy = CopyPath(path);
 * -----------------------------
 * This function returns a newly allocated path that is a copy of
 * the given path: same arcs, same order, same distance function.
 */

pathADT CopyPath(pathADT path);

/*
 * Function: FreePath
 * Usage: FreePath(path);
 * ----------------------
 * This function frees the storage associated with the path.
 */

void FreePath(pathADT path);

/*
 * Function: StartOfPath, EndOfPath
 * Usage: n1 = StartOfPath(path);
 *        n2 = EndOfPath(path);
 * --------------------------------
 * These functions return the nodes at the start and end of
 * a path, respectively.  If the path is empty, these functions
 * return NULL.
 */

nodeADT StartOfPath(pathADT path);
nodeADT EndOfPath(pathADT path);

/*
 * Function: AppendToPath
 * Usage: AppendToPath(path, arc);
 * -------------------------------
 * This function appends a new arc to the end of the path.
 */

void AppendToPath(pathADT path, arcADT arc);

/*
 * Function: NewExtendedPath
 * Usage: newpath = NewExtendedPath(path, arc);
 * --------------------------------------------
 * This function creates a new path that consists of a copy
 * of the old path with the new arc added at the end.
 */

pathADT NewExtendedPath(pathADT path, arcADT arc);

/*
 * Function: TotalPathDistance
 * Usage: sum = TotalPathDistance(path);
 * -------------------------------------
 * This function returns the total distance along the specified
 * path, by summing the distance function value for each arc.
 * If the path is empty, TotalPathDistance returns 0.
 */

double TotalPathDistance(pathADT path);

/*
 * Function: MapPath
 * Usage: MapPath(fn, path, clientData);
 * -------------------------------------
 * This function iterates through the arcs in the path and calls
 * the fn(arc, clientData) for each arc in the path.
 */

void MapPath(arcMappingFnT fn, pathADT path, void *clientData);

#endif
