/*
 * File: binaryfile.h
 * Last modified on Fri May  5 21:15:27 PDT 2000 by jzelenski
 * ----------------------------------------------------------
 * Exports routines for opening a binary file that is capable
 * of reading and writing single bits at a time. 
 */
 
#ifndef _binary_file_
#define _binary_file_

#include <stdio.h>
#include "genlib.h"

typedef struct BinaryFileCDT BinaryFile;


/*
 * Function: OpenForReading
 * Usage: bfile = OpenForReading("compressed");
 * --------------------------------------------
 * Given a filename, attempts to open that file as a binary file
 * for reading. If the file cannot be found or fails to open, NULL 
 * is returned, else the opened file is examined to ensure it has
 * valid binary contents and was properly closed after being written.
 * If either of these last two conditions are not met, an Error is raised.
 * If all goes well, the opened BinaryFile * is returned and is ready
 * for reading.
 */
BinaryFile *OpenForReading(string filename);



/*
 * Function: OpenForWriting
 * Usage: bfile = OpenForWriting("compressed");
 * --------------------------------------------
 * Given a filename, attempts to open that file as a binary file
 * for writing. If the file cannot be opened, NULL is returned, else
 * the newly opened BinaryFile * is returned and is ready for writing.
 */
BinaryFile *OpenForWriting(string filename);



/*
 * Function: CloseAndFree
 * Usage: CloseAndFree(bfile);
 * --------------------------
 * Closes a previously opened binary file. This is used for binary
 * files opened for either reading or writing. Failing to close a
 * binary file will leave it in an inconsistent state such that you
 * will not be able to later read from it, so be sure to close when
 * done!
 */
 void CloseAndFree(BinaryFile *bfile);



/*
 * Function: WriteBit
 * Usage: WriteBit(bfile, 0);
 * --------------------------
 * Writes a single bit to an opened binary file.  If the binary file
 * is not open for writing, an error is raised. The value of the bit
 * parameter is interpreted as 1 for any non-zero value and 0 otherwise.
 */
void WriteBit(BinaryFile *bfile, int bit);



/*
 * Function: ReadBit
 * Usage: val = ReadBit(bfile);
 * ----------------------------
 * Reads a single bit from an opened binary file.  If the binary file
 * is not open for reading, an error is raised. A value of 0 or 1
 * is returned corresponding to the value of the bit read. If attempting
 * to read at the end of the binary file, EOF (-1) is returned.
 */
int ReadBit(BinaryFile *bfile);


/*
 * Function: GetUnderlyingFile
 * Usage: fp = GetUnderlyingFile(bfile);
 * -------------------------------------
 * Returns the FILE * corresponding to the binary file. You can use this
 * function to get the FILE * so you can read and write to the file using
 * normal I/O functions (fprintf, getc, ReadLine, etc.).  It is allowable
 * to intermingle ordinary I/O with bit I/O, but you should take care to
 * read the data in the same order/using same functions that it was written.
 * (i.e. if you wrote 3 bits via WriteBit then a char using printf, you
 * should read the first 3 bits via ReadBit, then use getc or scanf to
 * read the character). You should not fclose this FILE *, it is owned
 * by the binary file and it will be closed when the binary file is closed
 * via the Close function above.
 */
FILE *GetUnderlyingFile(BinaryFile *bitfile);


#endif
