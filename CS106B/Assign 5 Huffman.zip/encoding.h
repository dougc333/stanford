/*
 * File: encoding.h
 * Last modified on Wed May  3 22:46:08 PDT 2000 by jzelenski
 * ----------------------------------------------------------
 * Defines an abstraction for the encoding ADT which constructs
 * and maintains a mapping from character to encoded bit pattern
 * and vice versa.
 */
#ifndef _encoding_h
#define _encoding_h

#include "genlib.h"
#include "binaryfile.h"



/*
 * Type: encodingADT
 * -----------------
 * Astract data type for managing an encoding, declared as
 * an incomplete type for privacy.
 */
typedef struct encodingCDT *encodingADT;


/*
 * Function: NewEncoding
 * Usage: encoding = NewEncoding();
 * --------------------------------
 * Returns a new empty encoding.  There are no entries
 * mapping characters to bit patterns or vice versa. To be
 * made useful, you must call the function that builds a
 * new encoding from a file or reads a previously saved encoding
 * from a file header. 
 */
encodingADT NewEncoding(void);



/*
 * Function: FreeEncoding
 * Usage: FreeEncoding(encoding);
 * -------------------------------
 * Frees all storage associated with an encoding.
 */
void FreeEncoding(encodingADT e);


/*
 * Function: EncodedBitPatternForChar
 * Usage: str = EncodedBitPatternForChar(encoding, 201);
 * -----------------------------------------------------
 * Returns the bit pattern (as a string of ASCII 0 and 1
 * characters) for a given character or NULL if no entry for
 * this character exists in the encoding. Not all characters
 * appear in every encoding. The string that is returned
 * is owned by the encoding module and should not be
 * altered or freed.
 */
string EncodedBitPatternForChar(encodingADT e, int ch);


/*
 * Function: CharForEncodedBitPattern
 * Usage: ch = CharForEncodedBitPattern(encoding, "010");
 * -----------------------------------------------------
 * Returns the character assigned to a bit pattern (expressed
 * as a string of ASCII 0 and 1 characters) or -1 if that
 * pattern doesn't map to any character in the encoding.  The
 * -1 result usually means that the bit pattern is a prefix
 * of other longer patterns that map to characters, but that
 * the prefix by itself is not enough to determine which one.
 * It could also mean that pattern doesn't appear in the 
 * encoding at all.
 */
int CharForEncodedBitPattern(encodingADT e, string pattern);


/*
 * Function: BuildEncodingForInputFile
 * Usage: BuildEncodingForInputFile(encoding, fp);
 * -----------------------------------------------
 * Scans the input file, counts characters, and does all
 * the analysis and building to construct the optimal Huffman
 * encoding for that file. The input file is assumed to be an 
 * opened FILE *, positioned at the beginning of the file, and 
 * ready for reading. After building an encoding, you can then 
 * look up the bit pattern for a character and vice versa.
 */
void BuildEncodingForInputFile(encodingADT e, FILE *in);


/*
 * Function: WriteEncodingTableToBinaryFile
 * Usage: WriteEncodingTableToBinaryFile(encoding, bfile);
 * ------------------------------------------------------
 * Writes a version of the encoding table to the given binary
 * file.  The binary file is assumed to be an opened BinaryFile *
 * that is positioned at the beginning of the file, and is ready
 * for writing. This function is reponsible for writing the file header
 * containing the encoding information  necessary to recreate the
 * mapping when later reading the file. This file header might be
 * a list of char to bit patterns, a table of character frequencies,
 * a representation of the tree itself, etc. The header may be
 * written using standard I/O functions or bit I/O or a combination.
 * The most important requirement is that it write all the
 * necessary facts in a consistent manner for the read function 
 * (below) to recreate the mapping. 
 */
void WriteEncodingTableToBinaryFile(encodingADT e, BinaryFile *bfile);


/*
 * Function: ReadEncodingTableFromBinaryFile
 * Usage: ReadEncodingTableFromBinaryFile(encoding, bfile);
 * --------------------------------------------------------
 * Reader the encoding table from the given binary file.  The binary 
 * file is assumed to be an opened BinaryFile *, positioned at the 
 * beginning of the file, and ready for reading. This function is 
 * reponsible for reading the file header of encoding information and 
 * reconstructing the mapping. The more important requirement is that 
 * it read all the necessary facts in a consistent manner with the 
 * write function (below) to recreate the mapping.
 */
void ReadEncodingTableFromBinaryFile(encodingADT e, BinaryFile *bfile);

#endif