/*
 * File: gboggle.h
 * ---------------
 * The gboggle.h file defines the interface for a set of
 * functions that
 *
 *   1. Draw the boggle board
 *   2. Manage the word lists
 *   3. Update the scoreboard
 */

#ifndef _gboggle_h
#define _gboggle_h

/*
 * Type: playerT
 * -------------
 * This enumeration distinguishes the human and computer players.
 */

typedef enum {Human, Computer} playerT;

/*
 * Function: DrawBoard
 * Usage: DrawBoard();
 * -------------------
 * This function draws the empty layout of the board.  It should
 * be called once at the beginning of each game, after calling
 * InitGraphics() to erase the graphics window.  It will redraw
 * the boggle cubes, board, and scores.  It resets the scores
 * and word lists to zero for each player.  The boggle cubes are
 * drawn with blank faces, ready for letters to be set using the
 * LabelCube function.
 */

void DrawBoard(void);

/*
 * Function: LabelCube
 * Usage: LabelCube(row, col, letter);
 * -----------------------------------
 * This function draws the specified letter on the face of the
 * cube at position (row, col).  The cubes are numbered from top
 * to bottom, left to right starting  with zero. Therefore, the
 * upper left corner is (0, 0); the lower right is (3, 3).  Thus,
 * the call
 *
 *      LabelCube(0, 3, 'D');
 *
 * would put a D in the top right corner cube.
 */

void LabelCube(int row, int col, char letter);

/*
 * Function: HighlightCube
 * Usage: HighlightCube(row, col, flag);
 * -------------------------------------
 * This function highlights or unhighlights the specified cube
 * according to the setting of flag: if flag is TRUE, the cube
 * is highlighted; if flag is FALSE, the highlight is removed.
 * The highlight flag makes it possible for you to show which
 * letters are in a word.
 */

void HighlightCube(int row, int col, bool flag);

/*
 * Function: RecordNewWord
 * Usage: RecordNewWord(word, player);
 * -----------------------------------
 * This function records the specified word by adding it to
 * the screen display for the specified player and updating
 * the scoreboard accordingly.  Scoring is calculated as
 * follows:  a 4-letter word is worth 1 point, a 5-letter
 * is worth 2 points, and so on.
 */

void RecordNewWord(string word, playerT player);

#endif
