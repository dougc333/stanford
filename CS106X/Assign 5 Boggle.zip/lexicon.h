/*
 * File: lexicon.h
 * ---------------
 * This file is the interface to an abstraction that allows
 * the client to keep track of a list of words.  The difference
 * between the lexicon abstraction and a symbol table or
 * dictionary is that the lexicon does not provide a mechanism
 * for storing the definitions of words; a lexicon merely
 * indicates whether a given string is a legal word.
 */

#ifndef _lexicon_h
#define _lexicon_h

#include "genlib.h"

/*
 * Type: lexiconADT
 * ----------------
 * This type represents the ADT for a lexicon.  The type is
 * a purely abstract type in this interface, defined entirely
 * in terms of the operations.  Because the type is represented
 * as a pointer to an incomplete structure type, the client has
 * no access to the underlying record structure.
 */

typedef struct lexiconCDT *lexiconADT;

/* Operations */

/*
 * Function: NewLexicon
 * Usage: lexicon = NewLexicon();
 * ------------------------------
 * This function creates a new lexicon and initializes it to
 * be empty.
 */

lexiconADT NewLexicon(void);

/*
 * Function: FreeLexicon
 * Usage: FreeLexicon(lexicon);
 * ----------------------------
 * This function frees the storage associated with the lexicon.
 */

void FreeLexicon(lexiconADT lexicon);

/*
 * Function: ReadLexiconFile
 * Usage: ReadLexiconFile(lexicon, filename);
 * ------------------------------------------
 * This function initializes the lexicon to the set of words
 * stored in the file with the specified name.  If the file
 * does not exist or memory space is exhausted, this function
 * calls Error with an appropriate message.
 */

void ReadLexiconFile(lexiconADT lexicon, string filename);

/*
 * Function: AddWordToLexicon
 * Usage: AddWordToLexicon(lexicon, word);
 * ---------------------------------------
 * This function adds the specified word to the lexicon.
 */

void AddWordToLexicon(lexiconADT lexicon, string word);

/*
 * Function: WordsInLexicon
 * Usage: n = WordsInLexicon(lexicon);
 * -----------------------------------
 * This function returns the number of words in the lexicon.
 */

long WordsInLexicon(lexiconADT lexicon);

/*
 * Function: IsWord
 * Usage: flag = IsWord(lexicon, word);
 * ------------------------------------
 * This function looks up the specified word in the lexicon
 * and returns TRUE if the word is a valid entry.
 */

bool IsWord(lexiconADT lexicon, string word);

/*
 * Function: IsPrefix
 * Usage: flag = IsPrefix(lexicon, prefix);
 * ----------------------------------------
 * This function returns TRUE if any words in the lexicon begin
 * with the specified prefix.  A word is defined to be a prefix
 * of itself and the empty string is a prefix of everything.
 */

bool IsPrefix(lexiconADT lexicon, string prefix);

/*
 * Function: GetWordFromPrefix
 * Usage: word = GetWordFromPrefix(lexicon, prefix);
 * -------------------------------------------------
 * This function returns some word from the lexicon that begins
 * with the specified prefix.  The implementation is free to
 * return any of the possibilities if there are several words
 * that start with that prefix.  If no such word exists, this
 * function returns NULL.
 */

string GetWordFromPrefix(lexiconADT lexicon, string prefix);

#endif
