/*
 * File: quilt.c
 * ---------------
 * Program that, when completed, will animate a funky sampler quilt screensaver.
 */

#include <stdio.h>                      /* library inclusions */
#include "genlib.h"
#include "extgraph.h"

#define NumColors 			18			/* General quilt constants */
#define WindowSizeFactor	0.75
#define NumBlocks			5

#define PetalRadiusRatio 	0.3  		/* Constants for the Flower block */
#define NumPetals			4

#define NumFrames 		4				/* Constants for the Log Cabin block */
#define SolidFill 		1.0
#define DenseFill		.75
#define MediumFill 		.50
#define LightFill 		.25
#define VeryLightFill 	.15

#define PointSizeRatio 	20				/* Constants for the "I love C!" block */

#define SamplerBlockSize 	1.0			/* Constants for the Sampler screensaver */

#define ZoomBlockStartSize 	.25			/* Constants for the Zoom screensaver */
#define ChangeAmount 		.20

#define BounceBlockSize 	2.0			/* Constants for Bounce screensaver */
#define MinVelocity			.05
#define MaxVelocity			.10



static void DefineNewColors(void);      /* Function protoypes */
static string ColorFromNumber(int colorNum);



main() 
{
	SetWindowSize(GetFullScreenWidth()*WindowSizeFactor, GetFullScreenHeight() * WindowSizeFactor);
    SetWindowTitle("Magic Quilt!");
    InitGraphics();
	DefineNewColors();
    printf("Click to bring the console window to the front, and then choose\n");
    printf("Quit from the File menu to exit.\n");
}


/* Function: DefineNewColors
 * Usage: DefineNewColors();
 * -------------------------
 * Defines some new color names, in addition to the 10 or so standard
 * names ("Red", "Blue", etc.) already defined. This function should be called
 * just once at the beginning of the program.
 */
static void DefineNewColors(void)
{
	DefineColor("Orange", 1.0, 0.6, 0);
	DefineColor("Gold", 0.9, 0.8, 0);
	DefineColor("Chautreuse", 0.7, 1.0, 0);
	DefineColor("Emerald", 0, 0.7, 0);
	DefineColor("Teal", 0, 0.8, 0.6);
	DefineColor("Turquoise", 0, 0.8, 0.7);
	DefineColor("Aqua", 0, 0.6, 1.0);
	DefineColor("Periwinkle", 0.5, 0, 0.7);
	DefineColor("Purple", 0.6, 0, 0.7);
	DefineColor("Violet", 0.6, 0, 0.6);
	DefineColor("Fuchsia", .8, 0, 0.8);
	DefineColor("HotPink", 1.0, 0, 0.5);
}


/* Function: ColorFromNumber
 * Usage: color = ColorFromNumber(4);
 * ---------------------------------
 * Looks up a color number in our table. Colors are numbered from 0 (Red)
 * to NumColors-1 (HotPink) and the colors in between follow in rainbow
 * order.  If the number is out of range, black is returned.
 */
static string ColorFromNumber(int colorNum)
{
	switch (colorNum) {
		case 0: return "Red";
		case 1: return "Orange";
		case 2: return "Gold";
		case 3: return "Yellow";
		case 4: return "Chautreuse";
		case 5: return "Green";
		case 6: return "Emerald";
		case 7: return "Teal";
		case 8: return "Turquoise";
		case 9: return "Cyan";
		case 10: return "Aqua";
		case 11: return "Blue";		
		case 12: return "Periwinkle";
		case 13: return "Purple";
		case 14: return "Violet";	
		case 15: return "Fuchsia";
		case 16: return "Magenta";
		case 17: return "HotPink";
	}
	return "Black"; /* on anything out of range, just return black */
}