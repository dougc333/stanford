/*
 * File: macqueue.h
 * Last modified on Sun Jul 26 16:54:27 1998 by eroberts
 * -----------------------------------------------------
 * The Macintosh automatically defines Enqueue and Dequeue because
 * they are part of the standard library.  This header file renames
 * Enqueue and Dequeue to avoid the conflict.  This code is not
 * required on other systems, and it is not necessary that you
 * understand how it works.
 */

#define Enqueue XEnqueue
#define Dequeue XDequeue
