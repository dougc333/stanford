/*
 * File: pathfinder.c
 * ------------------
 * This file is a shell for the Pathfinder application.  It merely
 * includes some scanf templates that parse the data for nodes and arcs from
 * a data file.  Your job is to complete the implementation.
 */

#include <stdio.h>
#include "genlib.h"
#include "extgraph.h"

/*
 * Constants
 * ---------
 * MaxString  -- The longest string allowed in data files.
 *               (Note: Must also be changed in sscanf formats)
 * NodeRadius -- The radius of the dot used to display nodes
 */

#define MaxString  99
#define NodeRadius .05




/* Helpful scanf templates & code to use for data files:
 * The strategy is the same for both, we use ReadLine to
 * pull the line in from the file, check against NULL (for
 * EOF) or word indicating end of nodes/arcs. Then we use
 * sscanf to scan pieces out of the string, checking the
 * return value to ensure we got the correct pieces of
 * data we need, and just bailing otherwise.
 *
 *  Reading one node:
 *  ----------------
 	string line;
	char name[MaxString + 1];
	double x, y;
	int nscan;
		
	line = ReadLine(infile);	
	if (line != NULL && !StringEqual(line, "ARCS")) {
    	nscan = sscanf(line,"\"%99[^\"]\" (%lf, %lf)\n",
    	               name, &x, &y);
    	if (nscan != 3) Error("Illegal node specification");
    	FreeBlock(line);
 *
 *
 *  Reading one arc:
 *  ----------------
    char mode[MaxString + 1], name1[MaxString + 1], name2[MaxString + 1];
    double distance, time, cost;
    int nscan;

    line = ReadLine(infile);
	if (line != NULL && !StringEqual(line, "")) {
        nscan = sscanf(line,
                       "\"%99[^\"]\" from \"%99[^\"]\" to \"%99[^\"]\""
                       " distance: %lf time: %lf cost: %lf", 
                       mode, name1, name2, &distance, &time, &cost);
        if (nscan != 6) Error("Illegal arc format");
    	FreeBlock(line);
*/



main()
{	
	InitGraphics();
	printf("Welcome to Pathfinder!\n");
}