/*
 * File: path.c
 * ------------
 * Fill in your implementation here.
 */
