/*
 * File: queue.c
 * -------------
 * Implements the queue.h abstraction.
 */

#include <stdio.h>

#include "genlib.h"
#include "queue.h"

/*
 * Constant: MaxQueueSize
 * ----------------------
 * Specifies the size of the queue array.  As implemented, the
 * queue can contain one less element than indicated by MaxQueueSize,
 * so that the empty and full cases can be differentiated. 
 */

#define MaxQueueSize 200

/*
 * Type: queueCDT
 * --------------
 * Defines the concrete representation of a queue corresponding
 * to queueADT.  This implementation uses an array of individual
 * elements, plus a head and a tail index, where head is the index
 * of the next item to be served and tail is the index of the next
 * free cell.  When head and tail are equal, the queue is empty.
 * Both the head and tail indices wrap around from the end of the
 * array back to the beginning, so that the array acts as a ring
 * buffer.
 */

struct queueCDT {
    void *array[MaxQueueSize];
    int head;
    int tail;
};

/* Implementation section */

queueADT NewQueue(void)
{
    queueADT queue;

    queue = New(queueADT);
    queue->head = queue->tail = 0;
    return (queue);
}

void FreeQueue(queueADT queue)
{
    FreeBlock(queue);
}

void Enqueue(queueADT queue, void *obj)
{
    if (QueueIsFull(queue)) {
        Error("Enqueue called on a full queue");
    }
    queue->array[queue->tail++] = obj;
    queue->tail %= MaxQueueSize;
}

void *Dequeue(queueADT queue)
{
    void *result;

    if (QueueIsEmpty(queue)) {
        Error("Dequeue of empty queue");
    }
    result = queue->array[queue->head++];
    queue->head %= MaxQueueSize;
    return (result);
}


bool QueueIsEmpty(queueADT queue)
{
    return (queue->head == queue->tail);
}


bool QueueIsFull(queueADT queue)
{
    return (((queue->tail + 1) % MaxQueueSize == queue->head));
}


int QueueLength(queueADT queue)
{
    return ((MaxQueueSize + queue->tail - queue->head) % MaxQueueSize);
}

void *GetQueueElement(queueADT queue, int k)
{
	if (k < 0 || k >= QueueLength(queue)) {
		Error("Non-existent queue element");
	}
	return (queue->array[(queue->head + k) % MaxQueueSize]);
}
