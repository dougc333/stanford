/*
 * File: queue.h
 * -------------
 * This file provides an interface to a simple queue abstraction.
 */

#ifndef _queue_h
#define _queue_h

#include "genlib.h"
#ifdef __MWERKS__
#include "macqueue.h"/* Used to avoid MacOS conflicts */
#endif

/*
 * Type: queueADT
 * --------------
 * Defines an abstract type for a queue.
 */

typedef struct queueCDT *queueADT;

/*
 * Function: NewQueue
 * Usage: queue = NewQueue();
 * --------------------------
 * Allocates and returns an empty queue.
 */

queueADT NewQueue(void);

/*
 * Function: FreeQueue
 * Usage: FreeQueue(queue);
 * ------------------------
 * Frees the storage associated with queue.
 */

void FreeQueue(queueADT queue);

/*
 * Function: Enqueue
 * Usage: Enqueue(queue, obj);
 * ---------------------------
 * Adds the object obj to the tail of the queue.
 */

void Enqueue(queueADT queue, void *obj);

/*
 * Function: Dequeue
 * Usage: obj = Dequeue(queue);
 * ----------------------------
 * Removes the object at the head of the queue and returns it.
 * Dequeueing an empty queue is caught as an error.
 */

void *Dequeue(queueADT queue);

/*
 * Function: QueueIsEmpty
 * Usage: if (QueueIsEmpty(queue)) . . .
 * --------------------------------------
 * Returns TRUE if queue has no entries.
 */
bool QueueIsEmpty(queueADT queue);


/*
 * Function: QueueIsFull
 * Usage: if (QueueIsFull(queue)) . . .
 * --------------------------------------
 * Returns TRUE if queue has no more room for entries.  Clients can use
 * this to check if any further Enqueue operation will overflow the
 * ability of the queue to handle it. Some versions of the pqueue may 
 * never return TRUE if they can always accommodate more entries.
 */
bool QueueIsFull(queueADT queue);


/*
 * Function: QueueLength
 * Usage: n = QueueLength(queue);
 * ------------------------------
 * Returns the number of elements currently in the queue.
 */

int QueueLength(queueADT queue);

/*
 * Function: GetQueueElement
 * Usage: element = GetQueueElement(queue, k);
 * -------------------------------------------
 * Returns the kth element in the queue, numbering the
 * elements from 0.  For example, GetQueueElement(queue, 0)
 * returns the initial element of the queue without
 * removing it (the element at the head of the line).
 * If the function tries to access an out-of-range
 * element, an error is generated.
 */

void *GetQueueElement(queueADT queue, int k);

#endif
