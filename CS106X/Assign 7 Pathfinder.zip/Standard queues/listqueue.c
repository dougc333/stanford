/*
 * File: queue.c
 * -------------
 * Implements the queue.h abstraction.
 */

#include <stdio.h>

#include "genlib.h"
#include "queue.h"

/*
 * Type: cell
 * ----------
 * Defines a linked list cell for the queue.
 */

typedef struct cell {
    void *value;
    struct cell *link;
} cell;

/*
 * Type: queueCDT
 * --------------
 * Defines the concrete representation of a queue corresponding
 * to queueADT.  This implementation uses a linked list of cells
 * implement the queue.  The next item to be dequeued is found at
 * the cell addressed by the "head" pointer.  The "tail" pointer
 * points to the last element in the queue, so that new enqueue
 * operations can add the new element in constant time.  The
 * empty queue is indicated by a NULL head pointer.
 */

struct queueCDT {
    cell *head;
    cell *tail;
};

/* Implementation section */

/*
 * Function: NewQueue
 * ------------------
 * Allocates the storage for the new queue header and ensures that
 * the head of the queue is NULL.
 */

queueADT NewQueue(void)
{
    queueADT queue;

    queue = New(queueADT);
    queue->head = NULL;
    return (queue);
}

/*
 * Function: FreeQueue
 * -------------------
 * This function first frees every cell in the chain beginning at
 * the head of the queue then goes back and frees the storage for
 * the new queue header.
 */

void FreeQueue(queueADT queue)
{
    cell *qp, *next;

    qp = queue->head;
    while (qp != NULL) {
        next = qp->link;
        FreeBlock(qp);
        qp = next;
    }
    FreeBlock(queue);
}

/*
 * Function: Enqueue
 * -----------------
 * This function chains in a new cell at the position indicated by
 * the tail pointer in the queue header.  Since the representation
 * uses a NULL head pointer to identify the empty queue (the value
 * of the tail pointer in an empty queue is unspecified), this
 * function must check for the empty queue as a special case.
 */

void Enqueue(queueADT queue, void *obj)
{
    cell *newcell;

    newcell = New(cell *);
    newcell->value = obj;
    newcell->link = NULL;
    if (queue->head == NULL) {
        queue->head = newcell;
    } else {
        queue->tail->link = newcell;
    }
    queue->tail = newcell;
}


/*
 * Function: Dequeue
 * -----------------
 * This function removes and returns the data value at the head of
 * the queue.
 */

void *Dequeue(queueADT queue)
{
    void *result;
    cell *oldcell;

    if (QueueIsEmpty(queue)) {
        Error("Dequeue: queue is empty");
    }
    oldcell = queue->head;
    result = oldcell->value;
    queue->head = oldcell->link;
    FreeBlock(oldcell);
    return (result);
}



bool QueueIsEmpty(queueADT queue)
{
    return (queue->head == NULL);
}


bool QueueIsFull(queueADT)
{
    return (FALSE);
}


int QueueLength(queueADT queue)
{
    int n;
    cell *qp;

    n = 0;
    for (qp = queue->head; qp != NULL; qp = qp->link) n++;
    return (n);
}

void *GetQueueElement(queueADT queue, int k)
{
	int i;
	cell *qp;
	
	if (k < 0 || k >= QueueLength(queue)) {
		Error("Non-existent queue element");
	}
	qp = queue->head;
	for (i = 0; i < k; i++) qp = qp->link;
	return (qp->value);
}
