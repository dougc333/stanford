CS Libraries for PC's running Windows
=====================================
eighth release to CS106 students, 11/12/99
library version 0.8


These libraries are designed for use with Microsoft Visual C++ version 6.0.
Install them by running setup.exe.  This will copy the files to various
places where MSVC will expect to find them.  If setup fails, alternate
instructions are below.


When starting an assignment:
1) start projects using type "CS106 Assignment Wizard"
2) if adding additional source files to your project, be sure to
   save them with the .c extension!


Manual installation instructions, if setup doesn't work:
1) put the CS106inc folder somewhere sensible, and add it to your MSVC
   include directories (Tools/Options/Directories)
2) put the CS106lib.lib file in your lib directory:
   C:\Program Files\Microsoft Visual Studio\VC98\Lib
3) put the CS106wiz.awx file in your templates directory:
   C:\Program Files\Microsoft Visual Studio\Common\MSDev98\Template


Please do not distribute these materials outside of Stanford.


For questions relating to these materials,
read:		http://cs106-pclibs.stanford.edu/
then contact:	cs106-pchelp@cs.stanford.edu.


last modified by magi, 11/12/99
