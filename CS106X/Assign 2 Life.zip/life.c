#include <stdio.h>
#include "genlib.h"
#include "extgraph.h"
#include "simpio.h"

#define NUM_COLS 40		
#define NUM_ROWS 30		
#define BIRTH_PROBABILITY .40
#define PAUSE_TIME .05 


static void Welcome(void);


 main()
{
      InitGraphics();
      Welcome();
}


static void Welcome(void)
{
	printf("Welcome to the game of Life, a simulation of the lifecycle of a bacteria colony.\n"
		"Cells live and die by the following rules:  \n"
			"\tA cell with 1 or fewer neighbors die of loneliness\n"
			"\tLocations with 2 neighbors remain stable\n"
			"\tLocations with 3 neighbors will spontaneously start life\n"
			"\tLocations with 4 or more neighbors die of overcrowding\n"
		"In the animation, new cells are dark and lighten as they age. \n");
	printf("Hit RETURN to continue: ");
	GetLine();
}


