/*
 * File: grid.h
 * Modified on Wed Oct 3 21:03:11 1996 by jzelenski
 * Last Modified on Thurs Jan 16 10:06:00 1997 by llaane
 * -----------------------------------------------------
 * Defines an abstraction for a two-dimentional grid of integers.  This ADT
 * is not entirely general, in that it was designed to specifically support
 * the 106X Life assignment.  Grids are numbered (row,col) starting at the 
 * upper left corner.  The row and columns are zero-based indexes, thus 
 * location (0,0) is the upper left corner.
 *
 */

#ifndef _grid_h
#define _grid_h

#include "CS106Inc/genlib.h"

/*
 * Constants: MAX_ROWS and MAX_COLS
 * --------------------------------
 * These define the absolute largest size grid one may create.
 */
#define MAX_ROWS 48
#define MAX_COLS 64


/*
 * Type: gridADT
 * ------------------
 * Provides an abstract data type for manipulating 2-dimensional
 * grids.  The type is a purely abstract type in this interface, defined 
 * entirely in terms of  the operations.  The client has no access to the 
 * record structure used to implement the actual type.
 */
typedef struct gridCDT *gridADT;


/* Operations */

/*
 * Function: CreateGrid
 * Usage: grid = CreateGrid(10,20);
 * --------------------------------
 * Dynamically allocates enough memory for the underlying representation
 * and initializes it to represent an empty grid of numRows by numCols.  
 * All locations are initialized to zero. An attempt to create a grid of 
 * a size larger than permitted by the constants will raise an error.
 */
gridADT CreateGrid(int numRows, int numCols);

/*
 * Function: FreeGrid
 * Usage: FreeGrid(grid);
 * ----------------------
 * Frees the storage associated with the grid. (You don't need
 * to be worried about freeing things at this point in quarter.)
 */
void FreeGrid(gridADT grid);


/*
 * Function: NumRows
 * Usage: rowCount = NumRows(grid);
 * --------------------------------
 * Returns the number of rows in the grid.
 */
int NumRows(gridADT grid);


/*
 * Function: NumCols
 * Usage: columnCount = NumCols(grid);
 * ----------------------------------
 * Returns the number of columns in the grid.
 */
int NumCols(gridADT grid);


/*
 * Function: SetValueAt
 * Usage: SetValueAt(grid, row, col, newValue);
 * -------------------------------------------
 * Sets the value at the given location to the specified new value.  If the
 * location is out of bounds for this grid, an error message is generated 
 * and the program halts.
 */
void SetValueAt(gridADT grid, int row, int col, int value);


/*
 * Function: GetValueAt
 * Usage: value = GetValueAt(grid, row, col);
 * -----------------------------------------
 * Retrieves the value at the given location and returns it.  If the
 * location is out of bounds for this grid, an error message is generated
 * and the program halts.
 */
int GetValueAt(gridADT grid, int row, int col);

/*
 * Function: CopyGrid
 * Usage: CopyGrid(source, destination);
 * -------------------------------------
 * Copies all the values from the source grid to the destination grid.
 * Afterwards, the destination grid has exactly the same contents as the 
 * source grid.  The source grid is unchanged.  The grids must be the same 
 * size in order to copy.  If they are not, an error message is generated 
 * and the program halts.
 */
void CopyGrid(gridADT from, gridADT to);



/*
 * Function: DrawGrid
 * Usage: DrawGrid(grid);
 * ----------------------
 * Draws the current state of the grid in the Graphics Window.  This will
 * erase the window completely and then draw the grid of cells in a box 
 * centered in the grahics window.  The cell size is chosen to be as large 
 * as will fit given the grid geometry, so larger grids have smaller cells 
 * and vice versa.  At startup, the grid chooses a random color to 
 * color the cells, and each cell will displayed in a shade which tells
 * its age.  Cells that have just been born (i.e. that have value 1) are
 * the darkest, they get lighter with age as the values go to 2, 3, and
 * so on.  The cells stabilize as very faint at generation 8 and older.
 * You probably will want to call UpdateDisplay() after calling
 * DrawGrid() in order to immediately flush the drawing on-screen.
 */
void DrawGrid(gridADT grid);


#endif 

