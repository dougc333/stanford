/*
 * File: bsinglelink.c
 * -------------------
 * This file implements the buffer.h abstraction using a singly linked
 * list to represent the buffer.
 */

#include <stdio.h>
#include "genlib.h"
#include "buffer.h"


typedef struct cellT {
   char ch;
   struct cellT *next;
} cellT;

struct bufferCDT {
   cellT *head;
   cellT *cursor;
};

static void FreeAllCells(cellT *ptr);
static cellT *CreateNewCell(char ch);


/*
 * Implementation notes: singly-linked list buffer
 * -----------------------------------------------
 * This implementation of the buffer using a singly-linked list for the buffer.
 * Each character is in its own cell and each cell has a pointer to the next 
 * cell which follows it. The last cell in the buffer has NULL in its next 
 * field. The buffer maintains a pointer to the head cell. The list has only
 * forward links (thus the "single" in singly-linked) which means the
 * operations behave assymetrically: moving forward is trivial, but backing
 * up requires starting at the head and traversing to find the previous cell.
 *
 * To simplify the splicing operations, this implementation adopts the
 * programming tactic of keeping an extra "dummy" cell at the beginning of 
 * each list, so that the empty buffer has the following representation:
 *
 *     +-------+          +------+
 *     |   o---+-----====>|      |
 *     +-------+    /     +------+
 *     |   o---+---/      | NULL |
 *     +-------+          +------+
 *
 * This means the head pointer is never NULL, it always points to this dummy, 
 * the dummy is never deleted. We need to be careful to skip over the dummy 
 * when displaying the buffer.
 *
 * The cursor is represented as a pointer to the cell containing the last 
 * character preceeding the cursor. By pointing to what is, in effect, the 
 * previous cell this allows easy forward-splicing to insert/delete at the 
 * cursor position. The cursor points to the dummy cell if the cursor precedes 
 * all characters.
 */




/*
 * Implementation notes: NewBuffer
 * -------------------------------
 * Note that we allocate the dummy cell as part of creating the empty 
 * list (drawn in above diagram). We assign the character '?' to it,
 * just a reminder that the dummy cell doesn't have a valid character
 * stored in it.
 */
bufferADT NewBuffer(void)
{
   bufferADT buffer;

   buffer = New(bufferADT);
   buffer->head = buffer->cursor = CreateNewCell('?');
   return buffer;
}


/*
 * Implementation notes: FreeBuffer
 * --------------------------------
 * This function must iterate over the entire linked list chain to free 
 * every individual cell. We use the helper function FreeAllCells to
 * do this (since shared by ClearBuffer). After doing this, we can free 
 * the memory occupied by bufferCDT itself. This is an O(N) operation since 
 * we have to visit and free each individual cell.
 */
void FreeBuffer(bufferADT buffer)
{
   FreeAllCells(buffer->head);
   FreeBlock(buffer);
}


/*
 * Implementation notes: MoveCursorForward
 * ---------------------------------------
 * This function advances the cursor pointer down one cell in our linked list 
 * chain.  If the cursor->next is NULL, the cursor is already at the end of 
 * the buffer and cannot be moved forward any further.
 * This is an O(1) operation.
 */
void MoveCursorForward(bufferADT buffer)
{
   if (buffer->cursor->next != NULL) 
       buffer->cursor = buffer->cursor->next;
}


/*
 * Implementation notes: MoveCursorBackward
 * -----------------------------------------
 * Because this is a singly linked list, the only way to move the cursor back 
 * is to traverse from the beginning until we reach cell whose next pointer 
 * points to the same cell that the cursor points to, (the character logically 
 * preceding the cursor in the buffer).  Once it is found, we set the cursor 
 * to that cell.  This makes the operation O(N) since it involves a traversal
 * through potentially all the cells to find that one preceding.
 *
 * If the cursor is pointing to the head, the cursor is already at the
 * the beginning of the buffer and cannot be moved backward any further.
 */
void MoveCursorBackward(bufferADT buffer)
{
   cellT *cur;

   if (buffer->cursor != buffer->head) {
       for (cur = buffer->head; cur->next != buffer->cursor; cur = cur->next)
       	;
       buffer->cursor = cur;
   }
}


/*
 * Implementation notes: MoveCursorToStart
 * ---------------------------------------
 * Moving the cursor to the beginning is merely a matter of resetting
 * to point to the dummy cell at the head of the list. This is an 
 * O(1) operation.
 */
void MoveCursorToStart(bufferADT buffer)
{
   buffer->cursor = buffer->head;
}



/*
 * Implementation notes: MoveCursorToEnd
 * -------------------------------------
 * Since we don't have a tail pointer in the buffer, we must traverse
 * down the list to find it, making this an O(1) operation. Would it be 
 * better to have such a pointer?  What affect would it have on our 
 * running time? What effect would it have on our memory usage and our
 * coding difficulty?
 */
void MoveCursorToEnd(bufferADT buffer)
{
   while (buffer->cursor->next != NULL)
       buffer->cursor = buffer->cursor->next;
}


/* 
 * Implementation notes: InsertCharacter
 * -------------------------------------
 * This function follows the typical paradigm for inserting a cell into
 * a linked list.  The cell is placed following the cursor, and the cursor 
 * pointer is updated to point to that cell (indicating the cursor follows
 * that new character). By having a dummy cell, we don't have to worry
 * about setting the head in the special case of inserting at the beginning
 * of the list. This is an O(1) operation.
 */
void InsertCharacter(bufferADT buffer, char ch)
{
   cellT *newCell;

   newCell = CreateNewCell(ch);
   newCell->next = buffer->cursor->next;
   buffer->cursor->next = newCell;
   buffer->cursor = newCell;
}

/* 
 * Implementation notes: DeleteCharacter
 * -------------------------------------
 * This function follows a typical paradigm for removing a cell from a
 * a linked list.  The cell following the cursor is removed (forward deletion). 
 * Given we have a dummy cell, we don't have to worry about setting the
 * head in the special case of deleting the first character. This is an
 * O(1) operation. What would the cost be for backward deletion using this 
 * singly-linked list?
 */
void DeleteCharacter(bufferADT buffer)
{
   cellT *cellToDelete;

   if (buffer->cursor->next != NULL) {
       cellToDelete = buffer->cursor->next;
       buffer->cursor->next = cellToDelete->next;
       FreeBlock(cellToDelete);
   }
}

/* 
 * Implementation notes: DisplayBuffer
 * -----------------------------------
 * This function traverses down the linked list, printing out the appropriate
 * characters, separated by spaces for easier reading. It makes a second pass
 * to print out the cursor location, lined up underneath the target location
 * between the two characters preceding and following the cursor. This
 * operation is O(N), in fact, the very best you can expect from this 
 * operation, no matter what, is O(N) since we have to print all N characters.
 */
void DisplayBuffer(bufferADT buffer)
{
   cellT *cur;
   
                /* Be sure to skip printing the dummy cell! */
   for (cur = buffer->head->next; cur != NULL; cur = cur->next) 
       printf(" %c", cur->ch);
   printf("\n");
   
   for (cur = buffer->head; cur != buffer->cursor; cur = cur->next)
       printf("  ");
   printf("^\n");
}


/*
 * Implementation notes: ClearBuffer
 * ---------------------------------
 * Empties the contents of the buffer by freeing all the cells past
 * the dummy cell and the resetting the state to indicate there are
 * no cells and the cursor is positioned at the beginning. This is
 * an O(N) operation since we have to visit and free all the cells
 * in the list.
 */
void ClearBuffer(bufferADT buffer)
{
   FreeAllCells(buffer->head->next); /* free everything _but_ dummy */

   buffer->head->next = NULL;
   buffer->cursor = buffer->head;
}


/*
 * Implementation notes: BytesUsed
 * -------------------------------
 * The bytes used is the sum of the bufferCDT plus all the storage
 * used in the cells themselves.
 */
int BytesUsed(bufferADT buffer)
{
     int bytes;
     cellT *cur;
     
     bytes = sizeof(*buffer); /* space for CDT itself */
     for (cur = buffer->head; cur != NULL; cur = cur->next)
         bytes += sizeof(*cur);
    return bytes;
}

/*
 * Implementation notes: PrintDebuggingInfo
 * ----------------------------------------
 * The version for the singly-linked list prints the node structure
 * in order as a debugging aid to keeping track of the cell contents
 * and the pointers between them. It prints each cell and identifies
 * where the cursor is pointing.
 */
void PrintDebuggingInfo(bufferADT buffer)
{
   cellT *cur;
   int count = 0, cPos = -1;

   for (cur = buffer->head; cur != NULL; cur = cur->next) {
       printf("%sCell #%d (at address %p) ch = '%c' next = %p\n", 
       	   (count == 0 ? "Dummy ":""), count, cur, cur->ch, cur->next);
       if (cur == buffer->cursor) cPos = count;
       count++;
   }
   printf("Cursor = %p (Cell #%d)\n", buffer->cursor, cPos);
}


/*
 * Simple helper function to create a new cell for a character.
 */
static cellT *CreateNewCell(char ch)
{
   cellT *newCell = New(cellT *);
   newCell->ch = ch;
   newCell->next = NULL;
   return newCell;
}


/*
 * Helper function to free entire contents of list. 
 */
static void FreeAllCells(cellT *ptr)
{
   cellT *next;
   while (ptr != NULL) {
       next = ptr->next;
       FreeBlock(ptr);
       ptr = next;
   }
}
