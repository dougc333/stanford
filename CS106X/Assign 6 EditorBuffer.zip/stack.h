/*
 * File: stack.h
 * -------------
 * Defines a general abstraction for stacks.
 */

#ifndef _stack_h
#define _stack_h

#include "genlib.h"


typedef char stackElementT;

/*
 * Type: stackADT
 * ------------------
 * Provides an abstract data type for manipulating
 * stacks of any allocated object.  The type is a
 * purely abstract type in this interface, defined
 * entirely in terms of the operations.  The client
 * has no access to the record structure used to
 * implement the actual type.
 */

typedef struct stackCDT *stackADT;

/* Operations */

/* Section 1 -- Creating and freeing stacks */

/*
 * Function: NewStack
 * Usage: stack = NewStack();
 * --------------------------
 * Dynamically allocates enough memory for the underlying
 * representation and initializes it to represent an empty
 * stack.
 */

stackADT NewStack(void);

/*
 * Function: FreeStack
 * Usage: FreeStack(stack);
 * ------------------------
 * Frees the storage associated with the stack.
 */

void FreeStack(stackADT stack);

/* Section 2 -- Push and Pop operations */

/*
 * Function: Push
 * Usage: Push(stack, element);
 * ----------------------------
 * Pushes the specified element onto the stack.  The
 * most recent element pushed will be the first one
 * popped.  If the stack exceeds its maximum size, an
 * error message is generated and the program quits.
 */

void Push(stackADT stack, stackElementT element);

/*
 * Function: Pop
 * Usage: element = Pop(stack);
 * ----------------------------
 * Pops the top element off the stack and returns
 * that value.  The element popped is the last one
 * pushed.  If the stack is empty when Pop is called,
 * an error message is generated and the program quits.
 */

stackElementT Pop(stackADT stack);

/* Section 3 -- Getting information from a stack */

/*
 * Function: IsStackEmpty
 * Usage: if (IsStackEmpty(stack)) ...
 * -----------------------------------
 * Returns TRUE if the stack is empty.
 */

bool IsStackEmpty(stackADT stack);

/*
 * Function: StackDepth
 * Usage: depth = StackDepth(stack);
 * ---------------------------------
 * Returns the number of elements currently pushed on
 * the stack.
 */

int StackDepth(stackADT stack);

/*
 * Function: GetStackElement
 * Usage: element = GetStackElement(stack, depth);
 * -----------------------------------------------
 * Returns the element at the indicated depth in the
 * stack.  For example, GetStackElement(stack, 0)
 * returns the top element of the stack without
 * removing it.  If the function tries to access an
 * out-of-range element, an error is generated.
 */

stackElementT GetStackElement(stackADT stack, int depth);


int StackBytesUsed(stackADT stack);

#endif

	