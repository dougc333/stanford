/*
 * File: performance.h
 * -----------------------------------------------------
 * This module exports just one function that runs a bufferADT through
 * its paces and reports the results to stdout.
 *
 * Julie Zelenski
 * CS106B April 2000
 */
 
 
#ifndef _trial_h
#define _trial_h


#define MinTrialSize 1000
#define MaxTrialSize 100000


/*
 * Function: RunPerformanceTrial
 * Usage: RunPerformanceTrial(10000);
 * ----------------------------------
 * Runs a performance trial using buffer of specified size.  The time trials
 * reports the amount of time necessary to move forward and backward in that
 * size buffer, as well as insert and delete into the buffer. The memory trial
 * reports on the bytes used to represent such a buffer.
 */
void RunPerformanceTrial(int size);


#endif