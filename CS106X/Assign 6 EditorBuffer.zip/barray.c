/*
 * File: barray.c
 * --------------
 * Implements the buffer.h abstraction using an array to
 * represent the buffer.
 */

#include <stdio.h>
#include "genlib.h"
#include "buffer.h"

#define StartingSize 100

/*
 * Type: bufferCDT
 * ---------------
 * In this representation of the buffer, all of the characters
 * are stored in a linear array in order. The cursor is represented
 * as the position of the last character preceding the cursor in
 * the array.
 */
struct bufferCDT {
   char *text;
   int allocatedLength, length;
   int cursor;
};

/* Section 1 -- Buffer creation and freeing */

bufferADT NewBuffer(void)
{
	bufferADT buffer;
	
	buffer = New(bufferADT);
	buffer->text = GetBlock(StartingSize);
	buffer->allocatedLength = StartingSize;
	buffer->length = 0;
	buffer->cursor = 0;
	return (buffer);
}
 
void FreeBuffer(bufferADT buffer)
{
	FreeBlock(buffer->text);
	FreeBlock(buffer);
}

/* Section 2 -- Operations to move the cursor */

void MoveCursorForward(bufferADT buffer)
{
	if (buffer->cursor < buffer->length) buffer->cursor++;
}

void MoveCursorBackward(bufferADT buffer)
{
	if (buffer->cursor > 0) buffer->cursor--;
}

void MoveCursorToStart(bufferADT buffer)
{
	buffer->cursor = 0;
}

void MoveCursorToEnd(bufferADT buffer)
{
	buffer->cursor = buffer->length;
}

/* Section 3 -- Insertion and deletion */

/*
 * Each of the functions in this section must shift
 * characters in the array, either to make room for
 * new characters or to close up space left by
 * deleted ones.
 */

void InsertCharacter(bufferADT buffer, char ch)
{
	int i;
	
	if (buffer->length == buffer->allocatedLength) {
		buffer->text = realloc(buffer->text, buffer->allocatedLength*2);
		if (buffer->text == NULL) Error("Out of memory!");
		buffer->allocatedLength *= 2;
	}
	for (i = buffer->length; i > buffer->cursor; i--) {
		buffer->text[i] = buffer->text[i-1];
	}
	buffer->text[buffer->cursor] = ch;
	buffer->length++;
	buffer->cursor++;
}

void DeleteCharacter(bufferADT buffer)
{
	int i;
	
	if (buffer->cursor < buffer->length) {
		for (i = buffer->cursor+1; i < buffer->length; i++) {
			buffer->text[i-1] = buffer->text[i];
		}
		buffer->length--;
	}
}

/* Section 4 -- Buffer display */

void DisplayBuffer(bufferADT buffer)
{
	int i;
	
	for (i = 0; i < buffer->length; i++) {
		printf(" %c", buffer->text[i]);
	}
	printf("\n");
	for (i = 0; i < buffer->cursor; i++) {
		printf("  ");
	}
	printf("^\n");	
}


void ClearBuffer(bufferADT buffer)
{
    buffer->length = buffer->cursor = 0;
}


void PrintDebuggingInfo(bufferADT buffer)
{
    printf("length = %d, cursor = %d\n", buffer->length, buffer->cursor);
    printf("Chars: %.*s\n", buffer->length, buffer->text);
}

int BytesUsed(bufferADT buffer)
{
    return sizeof(*buffer) + buffer->allocatedLength;
}


