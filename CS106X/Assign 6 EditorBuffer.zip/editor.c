/*
 * File: editor.c
 * --------------
 * This program implements a simple character editor, which
 * is used to test the buffer abstraction.  The editor reads
 * and executes simple commands entered by the user.
 */

#include <stdio.h>
#include <ctype.h>
#include "genlib.h"
#include "buffer.h"
#include "simpio.h"
#include "random.h"
#include "performance.h"

/* Private function prototypes */

static void ExecuteCommand(bufferADT buffer, string line);
static void HelpCommand(void);
static void PerformanceCommand(void);


main()
{
    bufferADT buffer;
    string line;

    Randomize();
    buffer = NewBuffer();
    while (TRUE) {
        printf("*");
	line = GetLine();
        ExecuteCommand(buffer, line);
	FreeBlock(line);
	DisplayBuffer(buffer);
    }
}

/*
 * Function: ExecuteCommand
 * Usage: ExecuteCommand(buffer, line, myConnection);
 * --------------------------------------------------
 * Given the line from the user, this function dispatches the appropriate
 * command.
 */
static void ExecuteCommand(bufferADT buffer, string line)
{
    int i;

    switch (toupper(line[0])) {
      case 'F': MoveCursorForward(buffer);
                break;
      case 'B': MoveCursorBackward(buffer);
                break;
      case 'J': MoveCursorToStart(buffer);
                break;
      case 'E': MoveCursorToEnd(buffer);
                break;
      case 'D': DeleteCharacter(buffer);
                break;
      case 'I': for (i = 1; line[i] != '\0'; i++) 
                    InsertCharacter(buffer, line[i]);
                break;
      case 'C': ClearBuffer(buffer);
                break;
      case 'P': PerformanceCommand();
                break;
      case 'G': PrintDebuggingInfo(buffer);
                break;
      case 'H': HelpCommand();
                break;
      case 'Q': FreeBuffer(buffer);
                exit(0);
      case '\0':break;                
      default:  printf("Illegal command: Enter 'H' for help.\n");
    }
}

/*
 * Function: HelpCommand
 * Usage: HelpCommand();
 * ---------------------
 * This function lists the available editor commands.
 */
static void HelpCommand(void)
{
    printf("Use the following commands to edit the buffer:\n");
    printf("  I...   Insert text up to the end of the line\n");
    printf("  F      Move forward a character\n");
    printf("  B      Move backward a character\n");
    printf("  J      Jump to the beginning of the buffer\n");
    printf("  E      Jump to the end of the buffer\n");
    printf("  D      Delete the next character\n");
    printf("  C      Clear buffer contents\n");
    printf("  P      Run performance trial\n");
    printf("  G      Print debugging info\n");
    printf("  H      Generate a help message\n");
    printf("  Q      Quit the program\n");
    printf("\n");
}


/*
 * Function: PerformanceCommand
 * Usage: PerformanceCommand();
 * ---------------------------
 * This function prompts the user for a size and then runs
 * various time trial and reports result.s.
 */
static void PerformanceCommand(void)
{
    int size;
    
    while (TRUE) {
    	printf("How large a buffer to use time trials? (%d to %d) ", 
	        MinTrialSize, MaxTrialSize);
    	size = GetInteger();
        if (size >= MinTrialSize && size <= MaxTrialSize) break;
	printf("Please use a size in the supported range.\n");
    }
    RunPerformanceTrial(size);
}