/*
 * File: buffer.h
 * --------------
 * This file defines the interface for an editor buffer abstraction.
 */

#ifndef _buffer_h
#define _buffer_h

#include "genlib.h"

/*
 * Type: bufferADT
 * ---------------
 * This type defines the abstract type used to represent
 * an editor buffer.
 */

typedef struct bufferCDT *bufferADT;

/* Exported entries */

/*
 * Function: NewBuffer
 * Usage: buffer = NewBuffer();
 * ----------------------------
 * This function dynamically allocates enough memory for the
 * underlying representation of a bufferADT and initializes
 * it to represent an empty buffer.
 */
bufferADT NewBuffer(void);

/*
 * Function: FreeBuffer
 * Usage: FreeBuffer(buffer);
 * --------------------------
 * This function frees the storage associated with the buffer.
 */
void FreeBuffer(bufferADT buffer);

/*
 * Functions: MoveCursorForward, MoveCursorBackward
 * Usage: MoveCursorForward(buffer);
 *        MoveCursorBackward(buffer);
 * ----------------------------------
 * These functions move the cursor forward or backward one
 * character, respectively.  If you call MoveCursorForward
 * at the end of the buffer or MoveCursorBackward at the
 * beginning, the function call has no effect.
 */
void MoveCursorForward(bufferADT buffer);
void MoveCursorBackward(bufferADT buffer);

/*
 * Functions: MoveCursorToStart, MoveCursorToEnd
 * Usage: MoveCursorToStart(buffer);
 *        MoveCursorToEnd(buffer);
 * -------------------------------
 * These functions move the cursor to the start or the
 * end of the buffer, respectively.
 */
void MoveCursorToStart(bufferADT buffer);
void MoveCursorToEnd(bufferADT buffer);

/*
 * Function: InsertCharacter
 * Usage: InsertCharacter(buffer, ch);
 * -----------------------------------
 * This function inserts the single character ch into the
 * buffer at the current cursor position.  The cursor is
 * positioned after the inserted character, which allows
 * for consecutive insertions.
 */
void InsertCharacter(bufferADT buffer, char ch);

/*
 * Function: DeleteCharacter
 * Usage: DeleteCharacter(buffer);
 * -------------------------------
 * This function deletes the character immediately after
 * the cursor.  If the cursor is at the end of the buffer,
 * this function has no effect.
 */
void DeleteCharacter(bufferADT buffer);

/*
 * Function: DisplayBuffer
 * Usage: DisplayBuffer(buffer);
 * -----------------------------
 * This function displays the current contents of the buffer
 * on the console.
 */
void DisplayBuffer(bufferADT buffer);

/*
 * Function: ClearBuffer
 * Usage: ClearBuffer(buffer);
 * -----------------------
 * Removes all of the characters from the buffer and reinitializes all of the
 * data structures.
 */
void ClearBuffer(bufferADT buffer);



/*
 * Function: BytesUsed
 * Usage: BytesUsed(buffer);
 * ------------------------
 * This function would not usually be included as part of the buffer.h,
 * but this is here as part of evaluating the tradeoffs betweem
 * implementations. Given a buffer, this function counts up
 * and return the total amount of space used by this buffer given its
 * current contents.
 */
int BytesUsed(bufferADT buffer);


/*
 * Function: PrintDebuggingInfo
 * Usage: PrintDebuggingInfo(buffer);
 * ---------------------------------
 * This function would not usually be included as part of the buffer.h,
 * but this is here to give you a routine to put any helpful debugging
 * print code (for example, something that prints the goopy details of
 * the internal structure) and it is wired up to the 'G' command in the 
 * editor, so you can invoke it during execution to get a dump of the
 * current internals. You don't need to implement this routine and can
 * ignore it entirely, but you may find it helpful to use as you are
 * doing development.
 */
void PrintDebuggingInfo(bufferADT buffer);



#endif
