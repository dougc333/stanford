/*
 * File: performance.c
 * -------------------
 * Implementation for the the performance testing module.  These
 * functions allow you to test a bufferADT implementation in
 * to evaluate its performance, both in time trials and in memory usage.
 *
 * Julie Zelenski
 * CS106B April 2000
 */
 
#include "performance.h"
#include "genlib.h"
#include "buffer.h"
#include "random.h"
#include <time.h>
#include <stdio.h>

#ifdef NeXT
#define CLOCKS_PER_SEC CLK_TCK
#endif

static void RunMovementTrial(int size);
static void RunEditingTrial(int size);
static void RunMemoryTrial(int size);
static double GetCurrentTime(void);


/*
 * Function: RunPerformanceTrial
 * ------------------------------
 * Test drives a buffer of specified size.  The first 2 time trials report
 * the amount of time necessary to move cursor and insert/delete on the
 * buffer.  The last trial reports on memory usage.
 */
void RunPerformanceTrial(int size)
{
    printf("\n------- Performance trial for %d-char buffer --------\n", size);
    RunMovementTrial(size);
    RunEditingTrial(size);
    RunMemoryTrial(size);
    printf("\n------------------- End of trial ---------------------\n\n");
}




/*
 * Function: RunMovementTrial
 * --------------------------
 * Runs the move cursor forward/backward trials for the specified
 * buffer size.  Reports results to stdout.
 */
static void RunMovementTrial(int size)
{
    bufferADT b;
    double start;
    int i;
    
    b = NewBuffer(); 
    for (i = 0; i < size; i++) 
	InsertCharacter(b, ('A' + i) % 26); 
	
    MoveCursorToEnd(b);
    start = GetCurrentTime();
    MoveCursorToStart(b);
    printf("Time to jump from end to start of %d-char buffer: %.1f msecs\n", 
           size, (GetCurrentTime() - start));

    MoveCursorToStart(b);
    start = GetCurrentTime();
    MoveCursorToEnd(b);
    printf("Time to jump from start to end of %d-char buffer: %.1f msecs\n", 
           size, (GetCurrentTime() - start));

    MoveCursorToStart(b);
    start = GetCurrentTime();
    for (i = 0; i < size; i++)
	MoveCursorForward(b);
    printf("Time to move forward in %d-char buffer: %.1f msecs\n", 
           size, (GetCurrentTime() - start)/size);
	
    MoveCursorToEnd(b);
    start = GetCurrentTime();
    for (i = 0; i < size; i++)
	MoveCursorBackward(b);
    printf("Time to move backward in %d-char buffer: %.1f msecs\n", 
           size, (GetCurrentTime() - start)/size);
    FreeBuffer(b);
}


/*
 * Function: RunEditingTrial
 * -------------------------
 * Runs the insert and delete time trials for the specified buffer size.
 * Reports results to stdout.
 */
static void RunEditingTrial(int size)
{	
    bufferADT b;
    double start;
    int i;
    	 
    b = NewBuffer();
    start = GetCurrentTime();
    for (i = 0; i < size; i++) 
	InsertCharacter(b, ('A' + i) % 26);
    printf("Time to insert char at end of %d-char buffer: %.1f msecs\n", 
           size, (GetCurrentTime() - start)/size);

    ClearBuffer(b);
    start = GetCurrentTime();
    for (i = 0; i < size; i++) {
	MoveCursorToStart(b);
	InsertCharacter(b, ('A' + i) % 26);
    }
    printf("Time to insert char at start of %d-char buffer: %.1f msecs\n",
           size,(GetCurrentTime() - start)/size);
		
    MoveCursorToEnd(b);
    start = GetCurrentTime();
    for (i = 0; i < size; i++)  {
    	MoveCursorBackward(b); /* move backwards to get last char */
	DeleteCharacter(b);
    }
    printf("Time to delete char at end of %d-char buffer: %.1f msecs\n", 
           size, (GetCurrentTime() - start)/size);
    
    ClearBuffer(b);
    for (i = 0; i < size; i++)
	InsertCharacter(b, ('A' + i) % 26);
		
    MoveCursorToStart(b);
    start = GetCurrentTime();
    for (i = 0; i < size; i++) 
	DeleteCharacter(b);
    printf("Time to delete char at start of %d-char buffer: %.1f msecs\n", 
           size, (GetCurrentTime() - start)/size);
	   
    FreeBuffer(b);
}


/*
 * Function: RunMemoryTrial
 * --------------------------
 * Fills a buffer to specified size and reports memory usage.  Then does
 * a bunch of move-insert-delete operations to jumble things up and reports
 * on the memory usage again. Reports results to stdout.
 */
static void RunMemoryTrial(int size)
{
    bufferADT b;
    int i, j, numInBuffer;
    
    b = NewBuffer(); 
    for (i = 0; i < size; i++) 
	InsertCharacter(b, ('A' + i) % 26); 
    printf("After consecutive inserts, %d-char buffer is using %d bytes of memory\n", size, BytesUsed(b));
    
    numInBuffer = size;
    for (i = 0; i < 1000; i++) { /* Make 1000 edits to buffer */
        if (RandomChance(.01))   /* Sometimes make big jump */
	    MoveCursorToStart(b);
	else if (RandomChance(.01))
	    MoveCursorToEnd(b);
    	else {                  /* Other times just move within */
	    int numToMove = RandomInteger(0, 100);
	    bool moveForward = RandomChance(.5);
	    for (j = 0; j < numToMove; j++) {
		if (moveForward) MoveCursorForward(b); 
		else MoveCursorBackward(b);
	    }
	}
	if (RandomChance(.5)) { /* half the time insert, other delete */
	    InsertCharacter(b, '#');
	    numInBuffer++;
        } else {
	    MoveCursorBackward(b);
	    DeleteCharacter(b);
	    numInBuffer--;
	}
    }
    printf("After lots of edits, %d-char buffer is using %d bytes of memory", 
            numInBuffer, BytesUsed(b));
    FreeBuffer(b);
}


static double GetCurrentTime(void)
{
    return ((double)clock()*1000000.0/CLOCKS_PER_SEC);
}

