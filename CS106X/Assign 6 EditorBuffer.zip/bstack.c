/*
 * File: bstack.c
 * --------------
 * Implements the buffer.h abstraction using two stacks to
 * represent the buffer.
 */

#include <stdio.h>
#include "genlib.h"
#include "stack.h"
#include "buffer.h"

/*
 * Type: bufferCDT
 * ---------------
 * In this representation of the buffer, all of the characters
 * are stored in one of two stacks.  The characters before the
 * cursor are pushed on the before stack, and those after the
 * pointer are pushed on the after stack.  The cursor is not
 * explicitly represented but is instead the boundary between
 * the stacks.  Characters are at deeper levels on their
 * respective stack if they are farther from the cursor.  As
 * an example, the buffer containing ABCDE with the cursor between
 * the C and the D would look like this:
 *
 *         C
 *         B         D
 *         A         E
 *      ------     -----
 *      before     after
 *
 */

struct bufferCDT {
    stackADT before, after;
};

/* Section 1 -- Buffer creation and freeing */

bufferADT NewBuffer(void)
{
	bufferADT buffer;
	
	buffer = New(bufferADT);
	buffer->before = NewStack();
	buffer->after = NewStack();
	return (buffer);
}
 
void FreeBuffer(bufferADT buffer)
{
	FreeStack(buffer->before);
	FreeStack(buffer->after);
	FreeBlock(buffer);
}

/* Section 2 -- Operations to move the cursor */

void MoveCursorForward(bufferADT buffer)
{
	if (!IsStackEmpty(buffer->after)) {
		Push(buffer->before, Pop(buffer->after));
	}
}

void MoveCursorBackward(bufferADT buffer)
{
	if (!IsStackEmpty(buffer->before)) {
		Push(buffer->after, Pop(buffer->before));
	}
}

void MoveCursorToStart(bufferADT buffer)
{
	while (!IsStackEmpty(buffer->before)) {
		Push(buffer->after, Pop(buffer->before));
	}
}

void MoveCursorToEnd(bufferADT buffer)
{
	while (!IsStackEmpty(buffer->after)) {
		Push(buffer->before, Pop(buffer->after));
	}
}

/* Section 3 -- Insertion and deletion */

void InsertCharacter(bufferADT buffer, char ch)
{
	Push(buffer->before, ch);
}

void DeleteCharacter(bufferADT buffer)
{
	if (!IsStackEmpty(buffer->after)) {
		(void) Pop(buffer->after);
	}
}


/* Section 4 -- Buffer display */

void DisplayBuffer(bufferADT buffer)
{
	int i;
	
	for (i = StackDepth(buffer->before) - 1; i >= 0; i--) {
		printf(" %c", GetStackElement(buffer->before, i));
	}
	for (i = 0; i < StackDepth(buffer->after); i++) {
		printf(" %c", GetStackElement(buffer->after, i));
	}
	printf("\n");
	for (i = 0; i < StackDepth(buffer->before); i++) {
		printf("  ");
	}
	printf("^\n");	
}


void ClearBuffer(bufferADT buffer)
{
	FreeStack(buffer->before);
	FreeStack(buffer->after);
	buffer->before = NewStack();
	buffer->after = NewStack();
}


void PrintDebuggingInfo(bufferADT buffer)
{
    	printf("Before stack has %d chars\n", StackDepth(buffer->before));
    	printf("After stack has %d chars\n", StackDepth(buffer->after));
}

int BytesUsed(bufferADT buffer)
{
   	return sizeof(*buffer) + StackBytesUsed(buffer->before) + 
	StackBytesUsed(buffer->after);
}