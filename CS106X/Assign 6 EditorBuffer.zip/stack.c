/*
 * File: stack.c
 * -------------
 * Implements the stack.h abstraction.
 */

#include <stdio.h>

#include "genlib.h"
#include "stack.h"

#define StartingSize 100

/*
 * Type: stackCDT
 * --------------
 * This type defines the concrete type that
 * corresponds to the abstract type stackADT.
 * Both the abstract data type and the concrete
 * data type point to the same address, but only
 * the implementation has access to the fields.
 * Since the two types are distinct as far as the
 * C compiler is concerned, the implementation is
 * responsible for using type casts to convert
 * from the abstract type to the concrete type
 * and vice versa.
 */

struct stackCDT {
	stackElementT *array;
	int count, allocatedCount;
};

/* Operations */

/* Section 1 -- Creating and freeing stacks */

stackADT NewStack(void)
{
	stackADT stack;
	
	stack = New(stackADT);
	stack->array = GetBlock(sizeof(stackElementT)*StartingSize);
	stack->allocatedCount = StartingSize;
	stack->count = 0;
	return (stack);
}

void FreeStack(stackADT stack)
{
	FreeBlock(stack->array);
	FreeBlock(stack);
}

/* Section 2 -- Push and Pop operations */

void Push(stackADT stack, stackElementT element)
{
	if (stack->count == stack->allocatedCount) { /* need to grow */
		stack->array = realloc(stack->array, 
		sizeof(stackElementT)*stack->allocatedCount*2);
		if (stack->array == NULL) Error("Out of memory!");
		stack->allocatedCount *= 2;
	}
	stack->array[stack->count++] = element;
}

stackElementT Pop(stackADT stack)
{
	if (stack->count == 0) {
		Error("Pop of an empty stack");
	}
	return (stack->array[--stack->count]);
}	

/* Section 3 -- Getting information from a stack */

bool IsStackEmpty(stackADT stack)
{
	return (stack->count == 0);
}

int StackDepth(stackADT stack)
{
	return (stack->count);
}

stackElementT GetStackElement(stackADT stack, int depth)
{
	if (depth < 0 || depth >= stack->count) {
		Error("Non-existent stack element");
	}
	return (stack->array[stack->count - depth - 1]);
}


int StackBytesUsed(stackADT stack)
{
     	return sizeof(*stack) + stack->allocatedCount*sizeof(stackElementT);
}