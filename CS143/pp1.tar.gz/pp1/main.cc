/*
 * CS143, Summer 2000-01
 * File: main.cc
 *
 * You should not need to modify this file.  It contains a driver
 * function, main, as well as some utility functions.
 *
 */

#include <stdio.h>
#include <stdarg.h>
#include "scanner.h"

YYSTYPE yylval;
struct yyltype yylloc;

void PrintToken( const char *text, int tokval, YYSTYPE *pval, struct yyltype *loc )
{
	printf( "%-12s line %d cols %d-%d is %s ", text, loc->first_line,
		loc->first_column, loc->last_column, gTokNames[tokval-T_boolean] );	
	if ( tokval == T_identifier )
	{
		pval->decl->Print();
	}
	else if ( tokval == T_floatliteral )
	{
		printf( "(value = %g)", pval->floatConst );
	}
	else if ( tokval == T_intliteral )
	{
		printf( "(value = %d)", pval->intConst );
	}
	else if ( tokval == T_stringliteral )
	{
		printf( "(value = \"%s\")", pval->stringConst );
	}
	else if ( tokval == T_charliteral )
	{
		printf( "(value = '%c')", pval->charConst );
	}
	printf( "\n" );
}

int main( int argc, char **argv )
{
	Inityylex();	
	int token;
	while ( ( token = yylex() ) != 0 )
		PrintToken( yytext, token, &yylval, &yylloc );
}

void yyerror( char *msg )
{
	ReportError( &yylloc, msg );
}

void ReportError( yyltype *ploc, const char *fmt, ... )
{
	fprintf( stderr, "*** Error line %d column %d: ", 
		ploc->first_line, ploc->first_column );
	va_list arglist;
	va_start( arglist, fmt );
	vfprintf( stderr, fmt, arglist );
	fprintf( stderr, "\n" );
	va_end( arglist );
}

