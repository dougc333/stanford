/*
 * CS143, Summer 2000-01
 * File: tokens.h
 *
 * You should not need to modify this file.  It contains declarations
 * of types used by flex, as well as definitions of token values.
 *
 */

typedef union {
	long intConst;
	double floatConst;
	char charConst;
	const char *stringConst;
	bool boolConst;
	Declaration *decl;
	int attr;
} YYSTYPE;

#ifndef YYLTYPE
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;

#define YYLTYPE yyltype
#endif

#define	T_boolean	257
#define	T_break	258
#define	T_byte	259
#define	T_case	260
#define	T_char	261
#define	T_class	262
#define	T_continue	263
#define	T_default	264
#define	T_do	265
#define	T_double	266
#define	T_else	267
#define	T_lelse	268
#define	T_extends	269
#define	T_boolliteral	270
#define	T_final	271
#define	T_float	272
#define	T_for	273
#define	T_if	274
#define	T_instanceof	275
#define	T_int	276
#define	T_long	277
#define	T_new	278
#define	T_nullliteral	279
#define	T_private	280
#define	T_protected	281
#define	T_public	282
#define	T_return	283
#define	T_short	284
#define	T_static	285
#define	T_switch	286
#define	T_this	287
#define	T_void	288
#define	T_while	289
#define	T_assign	290
#define	T_relop	291
#define	T_eqop	292
#define	T_not	293
#define	T_quest	294
#define	T_and	295
#define	T_or	296
#define	T_incr	297
#define	T_addop	298
#define	T_mulop	299
#define	T_bitand	300
#define	T_bitor	301
#define	T_shiftop	302
#define	T_lpar	303
#define	T_rpar	304
#define	T_lbrace	305
#define	T_rbrace	306
#define	T_lsquare	307
#define	T_rsquare	308
#define	T_semi	309
#define	T_comma	310
#define	T_dot	311
#define	T_intliteral	312
#define	T_floatliteral	313
#define	T_charliteral	314
#define	T_stringliteral	315
#define	T_identifier	316
#define	T_colon	317
#define	T_sro	318


extern YYSTYPE yylval;

static char *gTokNames[] = {
"T_boolean",
"T_break",
"T_byte",
"T_case",
"T_char",
"T_class",
"T_continue",
"T_default",
"T_do",
"T_double",
"T_else",
"T_lelse",
"T_extends",
"T_boolliteral",
"T_final",
"T_float",
"T_for",
"T_if",
"T_instanceof",
"T_int",
"T_long",
"T_new",
"T_nullliteral",
"T_private",
"T_protected",
"T_public",
"T_return",
"T_short",
"T_static",
"T_switch",
"T_this",
"T_void",
"T_while",
"T_assign",
"T_relop",
"T_eqop",
"T_not",
"T_quest",
"T_and",
"T_or",
"T_incr",
"T_addop",
"T_mulop",
"T_bitand",
"T_bitor",
"T_shiftop",
"T_lpar",
"T_rpar",
"T_lbrace",
"T_rbrace",
"T_lsquare",
"T_rsquare",
"T_semi",
"T_comma",
"T_dot",
"T_intliteral",
"T_floatliteral",
"T_charliteral",
"T_stringliteral",
"T_identifier",
"T_colon",
"T_sro",
};
