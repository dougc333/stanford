/*
 * CS143, Summer 2000-01
 * File: declaration.h
 *
 * This file contains the implementation of the Declaration class, 
 * which is used to store attributes of an identifier.
 *
 * You will need to complete the implementation of this class.
 *
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "declaration.h"

// TODO: complete the implementation of these methods

Declaration::Declaration( const char *_name, int _firstline )
{
}

Declaration::~Declaration()
{
}

void Declaration::IncrementOccurrences()
{
}

void Declaration::Print()
{
}

