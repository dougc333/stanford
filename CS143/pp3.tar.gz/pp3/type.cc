/*
 * CS143, Summer 2000-01
 * File: type.cc
 *
 * This file contains the implementation of the Type class and its
 * subclasses.  These classes store information about types for
 * compatibility checking.
 *
 */

#include <stdio.h>
#include <string.h>
#include "type.h"
#include "class.h"

MochaType *MochaType::intType = new MochaType( TypeInt );
MochaType *MochaType::charType = new MochaType( TypeChar );
MochaType *MochaType::longType = new MochaType( TypeLong );
MochaType *MochaType::doubleType = new MochaType( TypeDouble );
MochaType *MochaType::floatType = new MochaType( TypeFloat );
MochaType *MochaType::shortType = new MochaType( TypeShort );
MochaType *MochaType::booleanType = new MochaType( TypeBoolean );
MochaType *MochaType::voidType = new MochaType( TypeVoid );
MochaType *MochaType::nullType = new MochaType( TypeNull );
MochaType *MochaType::byteType = new MochaType( TypeByte );
MochaType *MochaType::noneType = new MochaType( TypeNone );

MochaType *MochaType::Copy()
{
	MochaType *t = new MochaType( m_Flag, m_class );
	t->SetCreator( m_bCreator );
	return t;
}

bool MochaType::IsNumeric()
{
	// TODO: return true if this type is one of the numeric types
	return false;
}

bool MochaType::IsIntegral()
{
	// TODO: return true if this type is one of the integral types
	return false;
}

bool MochaType::IsCompatible( MochaType *t )
{
	// TODO: return true if the given type is compatible with this
	// type.  If t is a method type, check against the return type.
}

const char *MochaType::toString()
{
	switch( m_Flag )
	{
	case TypeInt:
		return strdup( "int" );
	case TypeShort:
		return strdup( "short" );
	case TypeLong:
		return strdup( "long" );
	case TypeBoolean:
		return strdup( "boolean" );
	case TypeChar:
		return strdup( "char" );
	case TypeNull:
		return strdup( "null" );
	case TypeFloat:
		return strdup( "float" );
	case TypeDouble:
		return strdup( "double" );
	case TypeVoid:
		return strdup( "void" );
	case TypeArray:
		return strdup( "array" );
	case TypeByte:
		return strdup( "byte" );
	case TypeNone:
		return strdup( "" );
	case TypeReference:
		{
			char *s = new char[strlen(m_class->GetName()) + 7];
			sprintf( s, "class %s", m_class->GetName() );
			return s;
		}
	default:
		return strdup( "unknown" );
	}
}

MochaType *ArrayType::Copy()
{
	ArrayType *t = new ArrayType( m_base, m_dims );
	t->SetCreator( m_bCreator );
	return (MochaType *) t;
}

bool ArrayType::IsCompatible( MochaType *t )
{
	// TODO: return true if t is compatible with this type.
	// The base types must be compatible, and the dimensions
	// must match.
}

const char *ArrayType::toString()
{
	const char *szbase = m_base->toString();
	char *sz = new char[strlen(szbase) + m_dims * 2 + 1];
	strcpy(sz, szbase);
	int j;
	for ( j = 0; j < m_dims; j++ )
		sz = strcat(sz, "[]");
	delete [] szbase;
	return sz;
}

MochaTypeList *MochaTypeList::Add( MochaType *t )
{
	TypeNode *n = new TypeNode( t );

	if ( m_head == NULL )
		m_head = n;
	else
		m_tail->SetNext( n );
	m_tail = n;
	return this;
}

bool MochaTypeList::IsCompatible( MochaType *t )
{
	// TODO: return true if t is compatible with this type.
	// t must be a list of types, and the elements must be
	// pairwise compatible.
}

const char *MochaTypeList::toString()
{
	TypeNode *n;
	char *sz = NULL;
	for ( n = m_head; n != NULL; n = n->GetNext() )
	{
		const char *sz1 = n->GetType()->toString();
		if ( sz == NULL )
		{
			sz = new char[strlen(sz1) + 5];
			sprintf( sz, "( %s", sz1 );
			delete [] sz1;
		}	
		else
		{
			char *oldsz = sz;
			sz = new char[strlen(oldsz) + strlen(sz1) + 5];
			sprintf( sz, "%s, %s", oldsz, sz1 );
			delete [] oldsz;
		}
	}
	sz = strcat( sz, " )" );
	return sz;
}

bool MochaMethodType::IsCompatible( MochaType *t )
{
	// TODO: return true if t is compatible with this type for
	// use in an expression.

	// If t is a method, the return types must match.
	// Otherwise, the t must be compatible with the return type.
}

const char *MochaMethodType::toString()
{
	const char *sz1 = m_rettype->toString();
	const char *sz2;
	if ( m_args != NULL )
		sz2 = m_args->toString();
	else
		sz2 = "";

	char *sz = new char[strlen(sz1) + strlen(sz2) + 3];
	sprintf( sz, "%s(%s)", sz1, sz2 );

	delete [] sz1;
	delete [] sz2;

	return sz;
}

