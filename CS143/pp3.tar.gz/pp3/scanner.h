/*
 * CS143, Summer 2000-01
 * File: scanner.h
 *
 * You should not need to modify this file.  It contains declarations
 * needed by the scanner.
 *
 */


#include "parser.h"
#include "declaration.h"
#include "type.h"
#include "operator.h"

#include "y.tab.h"
#include "attributes.h"

extern struct yyltype yylloc;

void Inityylex();

extern char *yytext;

