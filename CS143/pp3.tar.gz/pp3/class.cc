/*
 * CS143, Summer 2000-01
 * File: class.cc
 *
 * This file contains the implementation of the MochaContainer class
 * and its subclasses, MochaMethod and MochaClass.  These classes hold
 * information about these containers, and provide access to the
 * declarations they contain.
 *
 */

#include <string.h>
#include <stdio.h>
#include "class.h"

extern HashTable GlobalScope;

MochaMethod::MochaMethod( const char *name, MochaType *ret,
	int mods, struct yyltype *l ) : MochaContainer( name, ret, mods, l )
{
}

MochaMethod::~MochaMethod()
{
}

MochaClass::MochaClass( const char *name, MochaClass *s, struct yyltype *l ) :
	MochaContainer( name, NULL, 0, l )
{
    m_super = s;
    m_type = new MochaType( MochaType::TypeReference, this );
}

MochaClass::~MochaClass()
{
}

void MochaMethod::Print()
{
    DisplayModifiers();

    MochaMethodType *mt = (MochaMethodType *) m_type;
    printf( "%s %s", mt->GetReturnType()->toString(), name );
    if ( mt->GetArgTypes() != NULL )
	printf( mt->GetArgTypes()->toString() );
    else
	printf( "()" );
    printf( "\n    {\n" );

    m_Decls->Print( 8 );

    printf( "    }\n" );
}

Declaration *MochaClass::GetMember( const char *name, bool& bInherited )
{
    // TODO: Locate named member within this class.
    // If it is not found, try the base class, if there is one.
    // Set the flag bInherited to true if the member was not found
    // in this class, but within a base class.
    return NULL;
}

void MochaClass::Print()
{
    printf( "class %s ", name );
    if ( m_super != NULL )
	printf( "extends %s ", m_super->GetName() );
    printf( "{\n" );

    m_Decls->Print( 4 );

    printf( "}\n" );
}

bool MochaClass::DerivesFrom( MochaClass *c )
{
    // Returns true if this class is the same class as c, or derives
    // from c
    if ( c == NULL )
	return false;
    if ( !strcmp( GetName(), c->GetName() ) )
	return true;
    if ( m_super == NULL )
	return false;
    return m_super->DerivesFrom( c );
}

