/*
 * CS143, Summer 2000-01
 * File: hashtable.h
 *
 * This file contains the declaration of the HashTable class,
 * which stores all declarations within a scope.
 *
 */

#include <stdio.h>
#ifndef __HASHTABLE_H__
#define __HASHTABLE_H__

#include <stdio.h>
#include <map>
#include "declaration.h"
#include "type.h"

struct ltstr
{
	bool operator()(const char *s1, const char *s2) const
	{
		return strcmp(s1,s2) < 0;
	}
} ;

class HashTable : public map<const char *, class Declaration *, ltstr>
{
public:
	static enum
	{
		Global = 0,
		Class = 1,
		Method = 2,
	} ScopeType;

	static const char *ObjectTypeNames[];
	static const char *ContainerTypeNames[];

	HashTable( int ntype, HashTable *n = NULL )
	{
		m_type = ntype;
		m_parent = n;
	}
	~HashTable()
	{
	}

	class Declaration *Declare( class Declaration *d );
	class Declaration *Lookup( const char *name, bool bFollow = true );

	// These methods are used to build the stack of scopes that
	// is maintained during parsing.
	HashTable *GetParent() { return m_parent; }
	void SetParent( HashTable *h ) { m_parent = h; }

	// This method returns the type of the scope, which is
	// either Global, Class or Method.
	int GetType() { return m_type; }

private:
	HashTable *m_parent;
	int m_type;

} ;

#endif

