/*
 * CS143, Summer 2000-01
 * File: errmsgs.h
 *
 * You should not need to modify this file.  It contains format strings
 * for all of the errors that you must report, using ReportError.  
 * Where a type is named, use the toString() method of MochaType.  In some
 * cases, you will need to pass names of objects such as classes or methods
 * as arguments.
 *
 */

#ifndef __ERRORS_H__
#define __ERRORS_H__

static const char szALREADY_DEFINED[] = "%s %s already defined in this %s";
static const char szINVALID_UNARY_TYPE[] = "Invalid type %s for %s";
static const char szINVALID_BINARY_TYPES[] = "Invalid types (%s, %s) for %s";
static const char szINVALID_SUPER_CLASS[] = "cannot inherit from non-aggregate type %s";
static const char szUNDEFINED_CLASS[] = "undefined class %s";
static const char szNO_RETURN_TYPE[] = "method %s must have a return type";
static const char szINVALID_ASSIGNMENT[] = "incompatible type %s in assignment, %s required";
static const char szTERNARY_NO_BOOLEAN[] = "boolean expression required for ternary operator";
static const char szTERNARY_MISMATCHED_OPERANDS[] = "incompatible types (%s, %s) for ternary operator";
static const char szINVALID_MEMBER_ACCESS[] = "reference to non-aggregate type %s";
static const char szINVALID_ARRAY_REFERENCE[] = "array reference on non-array type";
static const char szTHIS_IN_STATIC[] = "cannot use this within static method";
static const char szUNDECLARED_IDENT[] = "Undeclared identifier %s";
static const char szPRIVATE_MEMBER[] = "cannot access private member %s of class %s";
static const char szUNDEFINED_MEMBER[] = "%s is not a member of %s";
static const char szPROTECTED_MEMBER[] = "cannot access protected member %s of class %s";
static const char szNOT_STATIC_MEMBER[] = "cannot access non-static member %s of %s";
static const char szINVALID_METHOD_CALL[] = "method call on non-method";
static const char szARG_TYPE_MISMATCH[] = "argument type mismatch: expected %s, got %s";
static const char szIF_NO_BOOLEAN[] = "boolean expression required in if statement";
static const char szWHILE_NO_BOOLEAN[] = "boolean expression required in while statement";
static const char szDO_NO_BOOLEAN[] = "boolean expression required in do statement";
static const char szRETURN_TYPE_MISMATCH[] = "incompatible type %s in return, %s expected";
static const char szCASE_NOT_NUMERIC[] = "case expression not numeric";
static const char szVOID_VARIABLE[] = "cannot declare variable of type void";
static const char szARRAY_ELT_MISMATCH[] = "incompatible types %s, %s in array";

#endif

