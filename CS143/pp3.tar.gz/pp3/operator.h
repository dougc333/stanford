/*
 * CS143, Summer 2000-01
 * File: operator.h
 *
 * This file contains the declaration of the operator classes, 
 * which store information about unary and binary operators, and check
 * types of operands for semantic validity.
 *
 */

#ifndef __PREFIX_OP_H__
#define __PREFIX_OP_H__

#include "type.h"

class MochaOp
{
public:
	MochaOp( int code )
	{
		m_code = code;
	}
	~MochaOp()
	{
	}

	virtual const char *toString() = 0;

protected:
	int m_code;
} ;

class PrefixOp : public MochaOp
{
public:
	static enum 
	{
		PrefixOpCast = 0,
		PrefixOpIncr = 1,
		PrefixOpNeg = 2,
		PrefixOpAdd = 3
	} PrefixOpTypes;

	PrefixOp( int code, int attr ) : MochaOp( code )
	{
		m_attr = attr;
	}
	PrefixOp( int code, MochaType *t = NULL ) : MochaOp( code )
	{
		m_type = t;
	}
	~PrefixOp()
	{
	}

	MochaType *CheckType( MochaType *, struct yyltype * );

	const char *toString();

private:
	MochaType *m_type;
	int m_attr;
} ;

class InfixOp : public MochaOp
{
public:
	static enum
	{
		InfixOpInstance = 0,
		InfixOpMul = 1,
		InfixOpAdd = 2,
		InfixOpRel = 3,
		InfixOpEq = 4,
		InfixOpShift = 5,
		InfixOpAnd = 6,
		InfixOpOr = 7,
		InfixOpBitAnd = 8,
		InfixOpBitOr = 9,
	} InfixOpTypes;

	InfixOp( int code, int attr ) : MochaOp( code )
	{
		m_attr = attr;
	}
	~InfixOp()
	{
	}

	MochaType *CheckTypes( MochaType *, MochaType *, struct yyltype * );

	const char *toString();

private:
	MochaType *Promote( MochaType *, MochaType * );

	int m_attr;
} ;

#endif

