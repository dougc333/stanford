/*
 * CS143, Summer 2000-01
 * File: hashtable.cc
 *
 * This file contains the implementation of the HashTable class,
 * which stores all declarations within a scope.
 *
 */

#include <stdio.h>
#include "declaration.h"
#include "operator.h"
#include "parser.h"
#include "hashtable.h"
#include "errmsgs.h"

Declaration *HashTable::Declare( Declaration *d )
{
	// This method declares the object described by d to be
	// of the type included in d, in the current scope represented
	// by this hashtable.  The object must not already be defined
	// in this scope.  If it is, the old declaration is returned.
	Declaration *old = Lookup( d->GetName(), false );
	if ( old != NULL )
	{
		ReportError( d->GetLocation(), szALREADY_DEFINED,
			ObjectTypeNames[m_type], d->GetName(), 
			ContainerTypeNames[m_type] );
		return old;
	}
	else
	{
		insert( make_pair( strdup( d->GetName() ), d ) );
		return d;
	}
}

Declaration *HashTable::Lookup( const char *name, bool bFollow )
{
	// Looks for named declaration in this hashtable.
	// If it is not found, and bFollow is true, try the parent.
	// If not found, return NULL.
	if ( count( name ) == 0 )
	{
		if ( m_parent != NULL && bFollow )
			return m_parent->Lookup( name );
		return NULL;
	}
	iterator itr = find( name );
	return itr->second;
}

const char *HashTable::ObjectTypeNames[] = {
	"class",
	"member",
	"local variable",
} ;

const char *HashTable::ContainerTypeNames[] = {
	"package",
	"class",
	"method",
} ;

