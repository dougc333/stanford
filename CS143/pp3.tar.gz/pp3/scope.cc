/*
 * CS143, Summer 2000-01
 * File: scope.cc
 *
 * This file contains the implementation of the ScopeStack class, 
 * which is used to store all currently active scopes during parsing,
 * thus enabling recognized identifiers to be resolved.  It also
 * provides access to the method and class currently being parsed.
 *
 */

#include "scope.h"
#include "class.h"

ScopeStack::ScopeStack()
{
	// Initializes the scope stack by pushing the global scope
	m_ScopeStack = NULL;
	m_GlobalScope = PushScope( new HashTable( HashTable::Global ) );
}

ScopeStack::~ScopeStack()
{
	PopScope();
}

HashTable *ScopeStack::PushScope( HashTable *h )
{
	// Used for low-level maintance of the scope stack.
	h->SetParent( m_ScopeStack );
	m_ScopeStack = h;
	return h;
}

HashTable *ScopeStack::PopScope()
{
	// Used for low-level maintance of the scope stack.
	HashTable *top = m_ScopeStack;
	m_ScopeStack = top->GetParent();
	top->SetParent( NULL );
	return top;
}

MochaClass *ScopeStack::GetClass( const char *name )
{
	// Looks up the named class in the global scope
	return (MochaClass *) m_GlobalScope->Lookup( name );
}

void ScopeStack::DeclareClass( MochaClass *c )
{
	// Declares class c within the global scope
	HashTable *h = new HashTable( HashTable::Class );
	c->SetScope( h );
	m_GlobalScope->Declare( c );
	PushClass( c );	
	m_Class = c;
}

void ScopeStack::PushClass( MochaClass *c )
{
	// Helper method for DeclareClass
	if ( c != NULL )
	{
		PushClass( c->GetSuperClass() );
		PushScope( c->GetScope() );
	}
}

void ScopeStack::PopClass()
{
	// This should be used instead of PopScope, to maintain
	// the pointer to the current class correctly
	m_Class = NULL;
	while ( m_ScopeStack->GetType() == HashTable::Class )
		PopScope();
}

void ScopeStack::DeclareMethod( MochaMethod *m )
{
	// Declares given method within the class scope
	if ( m_Class != NULL )
	{
		HashTable *h = new HashTable( HashTable::Method );
		PushScope( h );
		m->SetClass( m_Class );
		m->SetScope( h );
		m_Class->GetScope()->Declare( m );
		m_Method = m;
	}
}

void ScopeStack::PopMethod()
{
	// Use this to pop the current method off the scope stack,
	// to maintain the current method pointer properly
	m_Method = NULL;
	PopScope();
}

void ScopeStack::DeclareLocal( Declaration *d )
{
	// Declares a variable within method or class scope, as appropriate
	m_ScopeStack->Declare( d );
	d->SetMethod( m_Method );
	d->SetClass( m_Class );
}

