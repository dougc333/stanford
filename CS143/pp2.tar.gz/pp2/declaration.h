/*
 * CS143, Summer 2000-01
 * File: declaration.h
 *
 * You should not need to modify this file.  It contains the declaration
 * of the Declaration class, used to store attributes of an identifier.
 *
 */

#ifndef __DECLARATION_H__
#define __DECLARATION_H__

class Declaration
{
public:
	Declaration( const char *_name, int _FirstLine );
	virtual ~Declaration();

	void Print();
	void IncrementOccurrences();

private:
	char *name;
	int FirstLine;
	int NumOccurrences;

} ;

#endif

