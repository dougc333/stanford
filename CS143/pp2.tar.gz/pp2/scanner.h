/*
 * CS143, Summer 2000-01
 * File: scanner.h
 *
 * You should not need to modify this file.  It contains declarations
 * needed by the scanner.
 *
 */

#include "declaration.h"

#include "y.tab.h"
#include "attributes.h"

extern struct yyltype yylloc;

int yylex();
void yyerror(char *msg);
void ReportError( yyltype *ploc, const char *fmt, ... );

void Inityylex();

extern char *yytext;

