int yylex( void );
void yyerror( char *msg );

int yyparse( void );

void Inityyparse();
