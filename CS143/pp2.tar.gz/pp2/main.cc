/*
 * CS143, Summer 2000-01
 * File: main.cc
 *
 * You should not need to modify this file.  It contains a driver
 * function, main, as well as some utility functions.
 *
 */

#include <stdio.h>
#include <stdarg.h>
#include "scanner.h"
#include "parser.h"


int main( int argc, char **argv )
{
	Inityylex();	
	Inityyparse();
	yyparse();
}

void yyerror( char *msg )
{
	ReportError( &yylloc, msg );
}

void ReportError( yyltype *ploc, const char *fmt, ... )
{
	fprintf( stderr, "*** Error line %d column %d: ", 
		ploc->first_line, ploc->first_column );
	va_list arglist;
	va_start( arglist, fmt );
	vfprintf( stderr, fmt, arglist );
	fprintf( stderr, "\n" );
	va_end( arglist );
}

