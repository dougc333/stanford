
#include <stdio.h>
#include "hashtable.h"

Declaration *HashTable::Add( const char *name, int line )
{
	Declaration *d = Lookup( name );
	if ( d == NULL )
	{
		d = new Declaration( name, line );
		insert( make_pair( strdup(name), d ) );
	}
	else
		d->IncrementOccurrences();
	return d;	
}

Declaration *HashTable::Lookup( const char *name )
{
	if ( count( name ) == 0 )
		return NULL;
	iterator itr = find( name );
	return itr->second;
}

