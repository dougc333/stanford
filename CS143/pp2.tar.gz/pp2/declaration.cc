/*
 * CS143, Summer 2000-01
 * File: declaration.h
 *
 * This file contains the implementation of the Declaration class, 
 * which is used to store attributes of an identifier.
 *
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "declaration.h"


Declaration::Declaration( const char *_name, int _firstline )
{
	name = strdup( _name );
	FirstLine = _firstline;
	NumOccurrences = 1;
}

Declaration::~Declaration()
{
	free( name );
}

void Declaration::IncrementOccurrences()
{
	NumOccurrences++;
}

void Declaration::Print()
{
	printf( "(%s seen %d time(s), first on line %d)", name, NumOccurrences, FirstLine );
}

