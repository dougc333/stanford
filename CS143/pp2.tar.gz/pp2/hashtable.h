
#ifndef __HASHTABLE_H__
#define __HASHTABLE_H__

#include <stdio.h>
#include <map>
#include "declaration.h"

struct ltstr
{
	bool operator()(const char *s1, const char *s2) const
	{
		return strcmp(s1,s2) < 0;
	}
} ;

class HashTable : public map<const char *, Declaration *, ltstr>
{
public:

	Declaration *Add( const char *name, int line );
	Declaration *Lookup( const char *name );
} ;

#endif
