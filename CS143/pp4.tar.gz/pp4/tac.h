/*
 * CS143, Summer 2000-01
 * File: tac.h
 *
 * You should not need to modify this file.  It contains the declaration
 * of the TacStmt class, as well as derived and helper classes.  They
 * are used to contain and maintain statements of intermediate code,
 * ensuring proper sequencing and backpatching.
 *
 */

#ifndef __TAC_H__
#define __TAC_H__

#define OP_NOOP		0
#define OP_LOAD		1
#define OP_STORE	2
#define OP_ALOAD	3
#define OP_ASTORE	4
#define OP_GETFIELD	5
#define OP_PUTFIELD	6
#define OP_GETSTATIC	7
#define OP_PUTSTATIC	8
#define OP_INVOKE	9
#define OP_INVSTATIC	10
#define OP_NEW		11
#define OP_NEWARRAY	12
#define OP_CONST	13
#define OP_INCR		14
#define OP_DECR		15
#define OP_NEG		16
#define OP_NOT		17
#define OP_CAST		18
#define OP_ADD		19
#define OP_SUB		20
#define OP_MUL		21
#define OP_DIV		22
#define OP_REM		23
#define OP_LT		24
#define OP_LE		25
#define OP_GT		26
#define OP_GE		27
#define OP_EQ		28
#define OP_NEQ		29
#define OP_AND		30
#define OP_OR		31
#define OP_XOR		32
#define OP_SHL		33
#define OP_SHR		34
#define OP_INST		35
#define OP_JUMP		36
#define OP_JFALSE	37
#define OP_SWITCH	38
#define OP_RETURN	39
#define OP_VRETURN	40
#define OP_DUP		41
#define OP_DUP2		42
#define OP_POP		43

class TacStmt {

public:
	TacStmt( int OpCode, int Arg = -1, int Arg2 = -1 )
	{
		m_op = OpCode;
		m_arg = Arg;
		m_arg2 = Arg2;
		m_index = NextStmt();
		m_next = NULL;
	}
	virtual ~TacStmt()
	{
		delete m_next;
	}

	static void InitCode() { m_nextindex = 0; }
	static int NextStmt() { return m_nextindex++; }

	static const char *OpNames[];
	
	void SetArg( int Arg ) { m_arg = Arg; }
	int GetArg() { return m_arg; }

	void SetOp( int Op ) { m_op = Op; }
	int GetOp() { return m_op; }

	int GetIndex() { return m_index; }

	void Clear() { m_op = OP_NOOP; m_arg = -1; m_arg2 = -1; }

	virtual void Print();

	class TacStmt *GetNext() { return m_next; }
	void SetNext( class TacStmt *n ) { m_next = n; }

protected:
	int		m_op;
	int		m_arg;
	class TacStmt	*m_next;
	int		m_index;
	int		m_arg2;

public:
	static int	m_nextindex;
} ;

class CaseStmt {

public:
	CaseStmt( int Value, int Label )
	{
		m_next = NULL;
		m_value = Value;
		m_label = Label;
	}
	~CaseStmt()
	{
		delete m_next;
	}

	void Print();

	void Append( CaseStmt *c ) { m_next = c; }
	CaseStmt *GetNext() { return m_next; }

private:
	int m_value;
	int m_label;
	class CaseStmt *m_next;

} ;

class SwitchCases {

public:
	SwitchCases()
	{
		m_head = m_tail = NULL;
		m_count = 0;
	}
	~SwitchCases()
	{
		delete m_head;
	}

	void Print();

	void AddCase( int Value, int Label )
	{
		CaseStmt *n = new CaseStmt( Value, Label );
		AddCase( n );
	}	
	void AddCase( CaseStmt *n )
	{
		if ( m_head == NULL )
			m_head = n;
		else
			m_tail->Append( n );
		m_tail = n;
		m_count++;
	}

	int GetCount() { return m_count; }

	CaseStmt *GetHead() { return m_head; }

private:
	CaseStmt *m_head;
	CaseStmt *m_tail;

	int m_count;
} ;

class SwitchStmt : public TacStmt {

public:
	SwitchStmt() : TacStmt( OP_SWITCH )
	{
		m_default = -1;
	}
	~SwitchStmt()
	{
	}

	void AddCase( CaseStmt *c )
	{
		m_Cases.AddCase( c );
	}
	void AddCase( int Value, int Label )
	{
		m_Cases.AddCase( Value, Label );
	}

	void Print();

	void SetDefault( int d ) { m_default = d; }

private:
	SwitchCases m_Cases;
	int m_default;
} ;

class TacStmts {

public:
	TacStmts()
	{
		m_head = m_tail = NULL;
	}
	~TacStmts()
	{
		delete m_head;
	}

	void Print();

	void Add( class TacStmt *s )
	{
		if ( s == NULL )
			return;
		if ( m_head == NULL )
			m_head = s;
		else
			m_tail->SetNext( s );
		m_tail = s;
	}

	class TacStmt *GetHead() { return m_head; }
	class TacStmt *GetLastStmt() { return m_tail; }
	class TacStmt *SetTail( class TacStmt *s ) { m_tail = s; }

private:
	class TacStmt *m_head;
	class TacStmt *m_tail;
} ;

class PatchNode
{
public:
	PatchNode( TacStmt *s )
	{
		m_stmt = s;
		m_next = NULL;
	}
	~PatchNode()
	{
	}

	TacStmt *GetStmt() { return m_stmt; }
	void SetStmt( TacStmt *s ) { m_stmt = s; }

	PatchNode *GetNext() { return m_next; }
	void SetNext( PatchNode *n ) { m_next = n; }

private:
	TacStmt *m_stmt;
	PatchNode *m_next;
};

class PatchList
{
public:
	PatchList()
	{
		m_head = m_tail = NULL;
	}
	~PatchList()
	{
	}

	void Add( PatchNode *n )
	{
		if ( m_head == NULL )
			m_head = n;
		else
			m_tail->SetNext( n );
		m_tail = n;
	}
	void Add( TacStmt *s )
	{
		PatchNode *n = new PatchNode( s );
		Add( n );
	}

	void Backpatch( int Label );

	static class PatchList *Merge( PatchList *l1, PatchList *l2 );

	PatchNode *GetHead() { return m_head; }	

private:
	PatchNode *m_head;
	PatchNode *m_tail;
} ;

#endif

