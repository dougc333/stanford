/*
 * CS143, Summer 2000-01
 * File: operator.cc
 *
 * This file contains the implementation of the operator classes, 
 * which store information about unary and binary operators, and check
 * types of operands for semantic validity.
 *
 */

#include <stdio.h>
#include "operator.h"
#include "attributes.h"
#include "parser.h"
#include "errmsgs.h"
#include "scope.h"
#include "tac.h"

extern ScopeStack *Scopes;

MochaType *PrefixOp::CheckType( MochaType *t, struct yyltype *loc )
{
	// TODO: return the type of the result of the application of
	// this operator to an operand of type t.  If the operand is
	// not of a valid type, report an error and return nullType.
	return MochaType::nullType;
}

const char *PrefixOp::toString()
{
	switch( m_code )
	{
	case PrefixOpIncr:
		if ( m_attr == A_add )
			return "++";
		else
			return "--";
	case PrefixOpNeg:
		if ( m_attr == A_not )
			return "!";
		else
			return "~";
	case PrefixOpAdd:
		if ( m_attr == A_add )
			return "+";
		else
			return "-";
	case PrefixOpCast:
		return "cast";
	}
	return "";
}

void PrefixOp::Emit()
{
	int op = OP_NOOP;
	switch( m_code )
	{
	case PrefixOpIncr:
		if ( m_attr == A_add )
			op = OP_INCR;
		else
			op = OP_DECR;
		break;
	case PrefixOpNeg:
		if ( m_attr == A_not )
			op = OP_NOT;
		else
			op = OP_NOT;
		break;
	case PrefixOpAdd:
		if ( m_attr == A_add )
			op = OP_NOOP;
		else
			op = OP_NEG;
		break;
	case PrefixOpCast:
		op = OP_CAST;
	}
	TacStmt *s = new TacStmt( op );
	Scopes->AddStmt( s );
}

MochaType *InfixOp::CheckTypes( MochaType *t1, MochaType *t2, struct yyltype *loc )
{
	// TODO: return the type of the result of the application
	// of this operator to operands of type t1 and t2.  If the
	// operands are not of valid types, report an error and return
	// nullType.
	return MochaType::nullType;
}

MochaType *InfixOp::Promote( MochaType *t1, MochaType *t2 )
{
	// TODO: return the type of an arithmetic expression applied
	// to operands of type t1 and t2.  This is useful for your
	// implementation of CheckType.
	return MochaType::nullType;
}

const char *InfixOp::toString()
{
	switch( m_code )
	{
	case InfixOpAdd:
		if ( m_attr == A_add )
			return "+";
		else
			return "-";
	case InfixOpMul:
		if ( m_attr == A_mul )
			return "*";
		else
			return "/";
	case InfixOpRel:
		if ( m_attr == A_lt )
			return "<";
		else if ( m_attr == A_gt )
			return ">";
		else if ( m_attr == A_leq )
			return "<=";
		else
			return ">=";
	case InfixOpEq:
		if ( m_attr == A_eq )
			return "==";
		else
			return "!=";
	case InfixOpShift:
		if ( m_attr == A_lsh )
			return "<<";
		else
			return ">>";
	case InfixOpAnd:
		return "&&";
	case InfixOpOr:
		return "||";
	case InfixOpBitAnd:
		return "&";
	case InfixOpBitOr:
		if ( m_attr == A_or )
			return "|";
		else
			return "^";
	case InfixOpInstance:
		return "instance";
	}
	return "";
}

void InfixOp::Emit()
{
	int op = OP_NOOP;
	switch( m_code )
	{
	case InfixOpAdd:
		if ( m_attr == A_add )
			op = OP_ADD;
		else
			op = OP_SUB;
		break;
	case InfixOpMul:
		if ( m_attr == A_mul )
			op = OP_MUL;
		else
			op = OP_DIV;
		break;
	case InfixOpRel:
		if ( m_attr == A_lt )
			op = OP_LT;
		else if ( m_attr == A_gt )
			op = OP_GT;
		else if ( m_attr == A_leq )
			op = OP_LE;
		else
			op = OP_GE;
		break;
	case InfixOpEq:
		if ( m_attr == A_eq )
			op = OP_EQ;
		else
			op = OP_NEQ;
		break;
	case InfixOpShift:
		if ( m_attr == A_lsh )
			op = OP_SHL;
		else
			op = OP_SHR;
		break;
	case InfixOpBitAnd:
		op = OP_AND;
		break;
	case InfixOpBitOr:
		if ( m_attr == A_or )
			op = OP_OR;
		else
			op = OP_XOR;
		break;
	case InfixOpInstance:
		op = OP_INST;
		break;
	}
	TacStmt *s = new TacStmt( op );
	Scopes->AddStmt( s );
}

