/*
 * CS143, Summer 2000-01
 * File: type.h
 *
 * This file contains the declaration of the Type class and its
 * subclasses.  These classes store information about types for
 * compatibility checking.
 *
 */

#ifndef __TYPE_H__
#define __TYPE_H__

#define OpMul		100
#define OpAdd		101
#define OpRel		102
#define OpEq		103
#define OpShift		104
#define OpInstance	105

class MochaType
{
public:
	static enum
	{
		TypeNone = 0,	// for internal use only
		TypeNull = 1,
		TypeVoid = 2,
		TypeByte = 3,
		TypeChar = 4,
		TypeShort = 5,
		TypeInt = 6,
		TypeLong = 7,
		TypeFloat = 8,
		TypeDouble = 9,
		TypeBoolean = 10,
		TypeArray = 11,
		TypeReference = 12,
		TypeList = 13,
		TypeMethod = 14
	} TypeCodes;

	MochaType( int flag, class MochaClass *cls = NULL )
	{
		m_Flag = flag;
		m_class = cls;
		m_bCreator = false;
		m_index = -1;
	}
	virtual ~MochaType()
	{
	}

	virtual class MochaType *Copy();

	static void InitBasicTypes();
	static class MochaType *intType;
	static class MochaType *charType;
	static class MochaType *longType;
	static class MochaType *byteType;
	static class MochaType *voidType;
	static class MochaType *doubleType;
	static class MochaType *floatType;
	static class MochaType *shortType;
	static class MochaType *booleanType;
	static class MochaType *nullType;
	static class MochaType *noneType;

	int GetTypeCode() { return m_Flag; }

	// PP4: each type is assigned an index in the global scope.
	// Declarations corresponding to the basic types are inserted
	// into the global scope for you.  This method returns the
	// type's index for use in new or newarray statements.
	int GetIndex();

	bool IsNumeric();
	bool IsIntegral();
	bool IsBoolean() { return m_Flag == TypeBoolean; }
	bool IsReference() { return m_Flag == TypeReference; }
	bool IsNull() { return m_Flag == TypeNull; }
	bool IsCreator() { return m_bCreator; }
	bool IsList() { return m_Flag == TypeList; }
	bool IsArray() { return m_Flag == TypeArray; }

	bool IsMethod() { return m_Flag == TypeMethod; }
	virtual bool IsCompatible( MochaType *t );
	virtual int GetDimensions() { return 0; }
	virtual MochaType *GetBaseType() { return NULL; }
	virtual MochaType *GetReturnType() { return NULL; }
	virtual class TypeNode *GetHead() { return NULL; }
	virtual class MochaTypeList *GetArgTypes() { return NULL; }

	class MochaClass *GetClass() { return m_class; }

	// The SetCreator method, in conjunction with IsCreator, is used
	// to keep track of whether an object is being created using
	// the new operator.  A valid creator expression is the
	// new operator, followed by a type, followed by zero or
	// more expressions in square brackets.  You need to keep
	// track of whether a type expression is a creator, so that
	// expressions in square brackets are interpreted properly:
	// they can be used to create an array, or access an array
	// element.  When new is involved, the first interpretation
	// is the correct one.  Once a creator expression is used
	// in another expression, such as with member access or an
	// infix or prefix operator, it is no longer a creator
	// expression.
	//
	// Example: in the code
	// class Stuff a[] = (new class Stuff[4][5])[2];
	// the expression "new Stuff[4][5]" is a creator expression,
	// where as the subscript [6] outside of the parentheses is
	// an array element access.  Therefore the above assignment
	// is valid.

	void SetCreator( bool bval ) { m_bCreator = bval; }

	virtual const char *toString();

protected:
	int m_Flag;
	class MochaClass *m_class;
	bool m_bCreator;
	int m_index;
} ;

class ArrayType : public MochaType
{
public:
	ArrayType( MochaType *t, int dims = 0 ) : MochaType( TypeArray )
	{
		m_dims = dims;
		m_base = t;
	}
	~ArrayType()
	{
	}

	class MochaType *Copy();

	bool IsCompatible( MochaType *t );

	void AddDimension() { m_dims++; }
	void Dereference() { m_dims--; }
	int GetDimensions() { return m_dims; }
	MochaType *GetBaseType() { return m_base; }

	const char *toString();

private:
	int m_dims;
	MochaType *m_base;
} ;

class TypeNode
{
public:
	TypeNode( MochaType *t )
	{
		m_t = t;
		m_next = NULL;
	}
	~TypeNode()
	{
	}

	MochaType *GetType() { return m_t; }

	TypeNode *GetNext() { return m_next; }
	void SetNext( TypeNode *n ) { m_next = n; }

private:
	MochaType *m_t;
	TypeNode *m_next;
} ;

class MochaTypeList : public MochaType
{
public:
	MochaTypeList() : MochaType( TypeList )
	{
		m_head = m_tail = NULL;
		m_Flag = TypeList;
	}
	~MochaTypeList()
	{
	}

	MochaTypeList *Add( MochaType *t );

	bool IsCompatible( MochaType *t );

	TypeNode *GetHead() { return m_head; }

	const char *toString();
	
private:
	TypeNode *m_head;
	TypeNode *m_tail;
} ;

class MochaMethodType : public MochaType
{
public:
	MochaMethodType( MochaType *ret, MochaTypeList *args ) : MochaType( TypeMethod )
	{
		m_rettype = ret;
		m_args = args;
	}
	~MochaMethodType()
	{
	}

	bool IsCompatible( MochaType *t );

	MochaType *GetReturnType() { return m_rettype; }
	MochaTypeList *GetArgTypes() { return m_args; }

	const char *toString();

private:
	MochaType *m_rettype;
	MochaTypeList *m_args;
} ;

#endif

