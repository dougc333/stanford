/*
 * CS143, Summer 2000-01
 * File: declaration.h
 *
 * You should not need to modify this file.  It contains the declaration
 * of the Declaration class, used to store attributes of an identifier.
 *
 */

#ifndef __DECLARATION_H__
#define __DECLARATION_H__


#include "type.h"
#include "parser.h"

class Declaration
{
public:
	Declaration( const char *_name, MochaType *t, int mods, struct yyltype *l );
	virtual ~Declaration();

	static const char *ModifierNames[];

	virtual void Print();
	void DisplayModifiers();

	// This method returns the type of this declaration
	class MochaType *GetType() { return m_type; }

	char *GetName() { return name; }
	struct yyltype *GetLocation() { return m_loc; }

	// These methods maintain the index of the declaration
	// within the current scope.  This index is used as an
	// argument to various instructions to easily identify
	// an object.
	int GetIndex() { return m_index; }
	void SetIndex( int i ) { m_index = i; }	

	// This method assigns a given modifier to the declaration
	void Modify( int val ) { m_Modifiers = val; } 

	bool IsStatic() { return ( m_Modifiers & M_static ) != 0; }
	bool IsPublic() { return ( m_Modifiers & M_public ) != 0; }
	bool IsProtected() { return ( m_Modifiers & M_protected ) != 0; }
	bool IsPrivate() { return ( m_Modifiers & M_private ) != 0; }
	bool IsFinal() { return ( m_Modifiers & M_final ) != 0; }

	// These methods return the object's containing class
	// or method, where applicable.
	class MochaMethod *GetMethod() { return m_method; }
	class MochaClass *GetClass() { return m_class; }

	// These methods associate this object with an enclosing
	// class or method.
	void SetClass( class MochaClass *c ) { m_class = c; }
	void SetMethod( class MochaMethod *m ) { m_method = m; }

	int GetModifiers() { return m_Modifiers; }

protected:
	char *name;

	class MochaType *m_type;
	class MochaMethod *m_method;
	class MochaClass *m_class;

	struct yyltype *m_loc;
	
	int m_Modifiers;

	int m_index;
} ;

class DeclNode
{
public:
	DeclNode( Declaration *d )
	{
		m_decl = d;
		m_next = NULL;
	}
	~DeclNode()
	{
	}

	DeclNode *GetNext() { return m_next; }
	void SetNext( DeclNode *n ) { m_next = n; }

	Declaration *GetDecl() { return m_decl; }

private:
	DeclNode *m_next;
	Declaration *m_decl;
} ;

class DeclList
{
public:
	DeclList()
	{
		m_head = NULL;
		m_tail = NULL;
	}
	~DeclList()
	{
	}

	DeclList *Add( Declaration *d );
	DeclNode *GetHead() { return m_head; }

	void Print( int nIndent );

private:
	DeclNode *m_head;
	DeclNode *m_tail;
} ;


#endif

