
#define M_public	0x1
#define M_private	0x2
#define M_protected	0x4
#define M_static	0x8
#define M_final		0x10

void ReportError( struct yyltype *, const char *, ... );

int yylex( void );
void yyerror( char *msg );

int yyparse( void );

void Inityyparse();
