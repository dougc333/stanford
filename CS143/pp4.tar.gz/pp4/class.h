/*
 * CS143, Summer 2000-01
 * File: class.h
 *
 * This file contains the declarations of the MochaContainer class
 * and its subclasses, MochaMethod and MochaClass.  These classes hold
 * information about these containers, and provide access to the
 * declarations they contain.
 *
 */

#ifndef __CLASS_H__
#define __CLASS_H__

#include "type.h"
#include "declaration.h"
#include "hashtable.h"
#include "tac.h"

#define CG_MODE_CLASS	0
#define CG_MODE_METHOD	1

class MochaContainer : public Declaration
{
 public:
    MochaContainer( const char *name, MochaType *ret, int mods, struct yyltype *l ) :
	Declaration( name, ret, mods, l )
	{
	    m_Decls = new DeclList;
	    m_code = new TacStmts;
	}
    virtual ~MochaContainer()
	{
	    delete m_Decls;
	    delete m_code;
	}

    // These methods work with the HashTable associated with this
    // container, where declarations are stored and accessed during parsing
    void SetScope( HashTable *h ) { m_scope = h; }
    HashTable *GetScope() { return m_scope; }
    
    // This method returns the list of declarations contained
    // within this scope (members for a class, local variables for a method).
    // This list is updated upon a contained object's declaration and
    // is used for output.  Unlike the Hashtable m_scope, this list
    // preserves the order in which objects are declared.
    DeclList *GetDeclList() { return m_Decls; }

    // PP4: these statements are used to work with the code held within
    // this container
    virtual void AddStmt( class TacStmt *s );
    virtual class TacStmt *GetLastStmt();

 protected:
    DeclList *m_Decls;
    HashTable *m_scope;
    class TacStmts *m_code;
} ;

class MochaMethod : public MochaContainer
{
 public:
    MochaMethod( const char *name, MochaType *ret, int mods, struct yyltype *l );
    ~MochaMethod();
   
    // When the method is declared, the formal parameters haven't yet
    // been parsed.  This method is used to associate the arguments
    // with the method when they have been recognized.
    void AddArguments( MochaTypeList *args ) 
	{
	    m_type = new MochaMethodType( m_type, args );
	}
    
    void Print();
} ;

class MochaClass : public MochaContainer
{
 public:
    MochaClass( const char *name, class MochaClass *s, struct yyltype *l );
    ~MochaClass();

    // These methods access the class' members and its base class,
    // or NULL if there is no base class, or the member isn't found.
    // bInherit is true if the member is inherited from a base class.
    Declaration *GetMember( const char *, bool &bInherit );
    MochaClass *GetSuperClass() { return m_super; }
    
    void Print();
   
    bool DerivesFrom( class MochaClass *c );
 
    // PP4: these methods override the base class methods
    // to ensure static code is properly maintained
    virtual void AddStmt( class TacStmt *s );
    virtual class TacStmt *GetLastStmt();
    void SetCodegenMode( int m ) { m_cgmode = m; }

 private:
    MochaClass *m_super;
    class TacStmts *m_clinit;
    int m_cgmode;
} ;

#endif

