/*
 * CS143, Summer 2000-01
 * File: attributes.h
 *
 * You should not need to modify this file.  It contains definitions
 * of constants used to denote attributes for operators and boolean
 * literals.
 *
 */

#define A_add		257
#define A_sub		258
#define A_mul		259
#define A_div		260
#define A_mod		261
#define A_eq		262
#define A_neq		262
#define A_lt		263
#define A_gt		264
#define A_leq		265
#define A_geq		266
#define A_lsh		267
#define A_rsh		268
#define A_true		269
#define A_false		270
#define A_or		271
#define A_xor		272
#define A_not		273
#define A_bit		274
#define A_and		275

