
#include <stdio.h>
#include <stdlib.h>
#include "tac.h"

const char *TacStmt::OpNames[] = {
  "noop",
  "load",
  "store",
  "aload",
  "astore",
  "getfield",
  "putfield",
  "getstatic",
  "putstatic",
  "invoke",
  "invokestatic",
  "new",
  "newarray",
  "ldc",
  "incr",
  "decr",
  "neg",
  "lneg",
  "cast",
  "add",
  "sub",
  "mul",
  "div",
  "rem",
  "lt",
  "le",
  "gt",
  "ge",
  "eq",
  "neq",
  "and",
  "or",
  "xor",
  "shl",
  "shr",
  "instanceof",
  "jump",
  "jfalse",
  "lookupswitch",
  "return",
  "return",
  "dup",
  "dup2",
  "pop"
} ;

void TacStmt::Print()
{
	printf( "%3d %s", m_index, OpNames[m_op] );
	if ( m_arg != -1 )
		printf( " %d", m_arg );
	printf( "\n" );
}

void CaseStmt::Print()
{
	printf( "case: %d %d\n", m_value, m_label );
}

void SwitchCases::Print()
{
	CaseStmt *n;
	for ( n = m_head; n != NULL; n = n->GetNext() )
	{
		n->Print();
	}
}

void SwitchStmt::Print()
{
	printf( "%3d lookupswitch %d %d\n", m_index, m_default, 
		m_Cases.GetCount() );
	m_Cases.Print();
}

void TacStmts::Print()
{
	TacStmt *n;
	for ( n = m_head; n != NULL; n = n->GetNext() )
	{
		n->Print();
	}
}

void PatchList::Backpatch( int Label )
{
	PatchNode *n;
	for ( n = m_head; n != NULL; n = n->GetNext() )
	{
		n->GetStmt()->SetArg( Label );
	}
}

PatchList *PatchList::Merge( PatchList *s1, PatchList *s2 )
{
	if ( s1 == NULL )
		return s2;
	if ( s2 == NULL )
		return s1;
	PatchNode *n;
	for ( n = s2->GetHead(); n != NULL; n = n->GetNext() )
	{
		s1->Add( n );
	}
	return s1;
}

