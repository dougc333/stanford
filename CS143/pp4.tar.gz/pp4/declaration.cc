/*
 * CS143, Summer 2000-01
 * File: declaration.cc
 *
 * This file contains the implementation of the Declaration class, 
 * which is used to store attributes of an identifier.
 *
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "declaration.h"
#include "type.h"
#include "operator.h"
#include "tac.h"
#include "y.tab.h"

Declaration::Declaration( const char *_name, MochaType *t, int mods, struct yyltype *l )
{
    name = strdup( _name );
    m_type = t;
    m_loc = l;
    m_Modifiers = mods;
    m_class = NULL;
    m_method = NULL;
    m_index = -1;
}

Declaration::~Declaration()
{
    free( name );
    free( m_loc );
}

void Declaration::Print()
{
    DisplayModifiers();
    printf( "%s %s;\n", m_type->toString(), name );
}

DeclList *DeclList::Add( Declaration *d )
{
    DeclNode *n = new DeclNode( d );
    if ( m_head == NULL )
    {
	m_head = n;
    }
    else
    {
	m_tail->SetNext( n );
    }
    m_tail = n;
    return this;
}

void DeclList::Print( int nIndent )
{
    DeclNode *n;
    for ( n = GetHead(); n != NULL; n = n->GetNext() )
    {
	int j;
	for ( j = 0; j < nIndent; j++ )
	    printf( " " );
	n->GetDecl()->Print();
	printf( "\n" );
    }
}

void Declaration::DisplayModifiers()
{
    int j;
    for ( j = 0; j < 5; j++ )
    {
	int nVal = 1 << j;
	if ( ( m_Modifiers & nVal ) != 0 )
	    printf( "%s ", ModifierNames[j] );
    }
}

const char *Declaration::ModifierNames[] = 
{
    "public",
    "private",
    "protected",
    "static",
    "final"
} ;

