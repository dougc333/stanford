/*
 * CS143, Summer 2000-01
 * File: scope.h
 *
 * This file contains the declaration of the ScopeStack class, 
 * which is used to store all currently active scopes during parsing,
 * thus enabling recognized identifiers to be resolved.  It also
 * provides access to the method and class currently being parsed.
 *
 */

#ifndef __SCOPES_H__
#define __SCOPES_H__

#include "hashtable.h"

class ScopeStack
{
public:
	ScopeStack();
	~ScopeStack();

	HashTable *PushScope( HashTable *h );
	HashTable *PopScope();
	class MochaClass *GetClass( const char *name );

	// These methods maintain the declaration of a class on
	// the scope stack.
	void DeclareClass( class MochaClass *c );
	void PushClass( class MochaClass *c );
	void PopClass();

	// These methods maintain the declaration of a method on
	// the scope stack.
	void DeclareMethod( class MochaMethod *m );
	void PopMethod();

	// This method adds a variable declaration to the current scope.
	void DeclareLocal( class Declaration *d );

	// These methods return the currently active class or method
	// declaration.
	class MochaClass *GetCurrentClass() { return m_Class; }
	class MochaMethod *GetCurrentMethod() { return m_Method; }

	// PP4: these are used to help route statements to the
	// proper container.
	HashTable *GetGlobalScope() { return m_GlobalScope; }
	class MochaContainer *GetCurrentContainer();
	void AddStmt( class TacStmt *s );
	class TacStmt *GetLastStmt();

	// This method returns the scope currently on top of the stack.
	HashTable *GetScope() { return m_ScopeStack; }
 
private:
	HashTable *m_GlobalScope;
	HashTable *m_ScopeStack;

	class MochaClass *m_Class;
	class MochaMethod *m_Method;
} ;

#endif

